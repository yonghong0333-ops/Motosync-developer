const { contextBridge, ipcRenderer } = require("electron");

// 開放一個安全、範圍很小的介面給網頁端（renderer.js）呼叫：
// 網頁端只能「請求開始 Google 登入」，其他 Node.js / 系統層級的能力
// 完全不會開放出去，符合 contextIsolation 的安全設計。
contextBridge.exposeInMainWorld("electronAPI", {
  getShopFirebaseConfig: () => ipcRenderer.invoke("get-shop-firebase-config"),
  loginWithGoogle: () => ipcRenderer.invoke("google-login"),
  offlineLogin: () => ipcRenderer.invoke("offline-login"),
  checkLicense: () => ipcRenderer.invoke("check-app-license"),
  readOfflineQueue: () => ipcRenderer.invoke("offline-queue-read"),
  writeOfflineQueue: (queue) => ipcRenderer.invoke("offline-queue-write", queue),
  readLocalCache: () => ipcRenderer.invoke("local-cache-read"),
  writeLocalCache: (data) => ipcRenderer.invoke("local-cache-write", data),
  clearLocalCache: () => ipcRenderer.invoke("local-cache-clear"),
  getLocalCacheInfo: () => ipcRenderer.invoke("local-cache-info"),
  getDiskSpace: () => ipcRenderer.invoke("get-disk-space"),
  openLocalDataFolder: () => ipcRenderer.invoke("open-local-data-folder"),
  pickAccessFile: () => ipcRenderer.invoke("access-import-pick-file"),
  readAccessFile: (filePath) =>
    ipcRenderer.invoke("access-import-read-file", filePath),
  generateEstimateDocx: (payload) =>
    ipcRenderer.invoke("generate-estimate-docx", payload),
  generateEstimatePdf: (payload) =>
    ipcRenderer.invoke("generate-estimate-pdf", payload),
  printEstimate: (payload) => ipcRenderer.invoke("print-estimate", payload),
  quitApp: () => ipcRenderer.invoke("quit-app"),
  // 視窗改成 frame: false（不用 Windows 原生外框）之後，最小化／關閉
  // 這兩顆按鈕要自己畫、自己送 IPC 給殼（main.js）處理。
  minimizeWindow: () => ipcRenderer.send("window:minimize"),
  closeWindow: () => ipcRenderer.send("window:close"),
  getWifiStrength: () => ipcRenderer.invoke("get-wifi-strength"),
  getNetworkDiagnostics: () => ipcRenderer.invoke("get-network-diagnostics"),
  sendPasswordResetCode: (recipientEmail, purpose) =>
    ipcRenderer.invoke("send-password-reset-code", recipientEmail, purpose),
  verifyPasswordResetCode: (code) =>
    ipcRenderer.invoke("verify-password-reset-code", code),
  onWifiStrength: (callback) =>
    ipcRenderer.on("wifi-strength-update", (_event, percent) => callback(percent)),
  getBatteryInfo: () => ipcRenderer.invoke("get-battery-info"),
  onBatteryUpdate: (callback) =>
    ipcRenderer.on("battery-update", (_event, info) => callback(info)),
  setFullScreen: (shouldBeFullScreen) =>
    ipcRenderer.invoke("set-fullscreen", !!shouldBeFullScreen),
  // 啟動驗證：bootloader 切版之後會等這個 ping，30 秒內沒收到就自動
  // 判定「這個版本壞掉了」退回舊版本（見 renderer.js 的
  // checkAppLicenseOnStartup()，通過授權檢查後會呼叫這個）。
  notifyStartupVerified: () => ipcRenderer.invoke("update:startup-verify-ping"),
});
