import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {
  getAuth,
  setPersistence,
  browserLocalPersistence,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithCredential,
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
  getDatabase,
  ref,
  get,
  push,
  set,
  update,
  remove,
  onValue,
  runTransaction,
  query,
  limitToLast,
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";

// 永鑫機車專案 Firebase 設定
const firebaseConfig = {
  apiKey: "AIzaSyAfuys0XJM8Pf8MB3b0fbwhTqifV7Cek8M",
  authDomain: "motorcycle-yongxin.firebaseapp.com",
  databaseURL:
    "https://motorcycle-yongxin-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "motorcycle-yongxin",
  storageBucket: "motorcycle-yongxin.firebasestorage.app",
  messagingSenderId: "318839288308",
  appId: "1:318839288308:web:c657ee7f72a06a36d489a1",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
const db = getDatabase(app);

// 🔒 系統白名單列表
const allowedEmails = ["yonghong0333@gmail.com", "r81882@gmail.com"];

// 0. 整套系統的授權門檻
// 一開機就檢查有沒有合法的授權金鑰（.app），不管等一下要用 Google 登入
// 還是離線登入都一樣要通過這一關，沒有金鑰的話畫面上只會看到鎖定訊息，
// 連登入按鈕都碰不到（login_mask 被蓋在下面，點不到）。
(async function checkAppLicenseOnStartup() {
  const lockScreen = document.getElementById("license_lock_screen");
  try {
    const result = await window.electronAPI.checkLicense();
    if (result.ok) {
      lockScreen.classList.add("hidden");
      // 走到這裡代表：畫面渲染出來了、preload/IPC 橋接正常、
      // main.js（連同它 require 的 docx / mdb-reader 等套件）
      // 沒有在載入時就整個炸掉、授權金鑰也讀取驗證成功——
      // 符合 bootloader 啟動驗證要確認的條件，回報「這個版本沒問題」，
      // 不用等使用者真的登入完成（Google 登入需要使用者操作，
      // 時間不固定，不適合拿來當 30 秒逾時的判斷依據）。
      window.electronAPI.notifyStartupVerified().catch(() => {});
    } else {
      showLicenseLocked(result.reason);
    }
  } catch (error) {
    showLicenseLocked(error.message || "未知錯誤");
  }
})();

function showLicenseLocked(reason) {
  document.getElementById("license_lock_title").textContent =
    "此電腦尚未授權使用本系統";
  document.getElementById("license_lock_message").innerHTML =
    `請將授權金鑰檔案（.app）放進本程式安裝目錄下的<br/>` +
    `<span class="text-yellow-300 font-mono">offline-license</span> 資料夾，` +
    `然後重新開啟本程式。<br/><br/>` +
    `<span class="text-gray-600 text-xs">錯誤訊息：${reason}</span>`;
}

// 🏭 是否執行過原廠設定：預設「沒有」，只有原廠設定真的跑完才會被寫成 true，
// 開機（登入成功）時讀一次伺服器上的狀態，單純提供判斷用，不影響其他功能。
let systemHasFactoryReset = false;

async function checkFactoryResetStateOnBoot() {
  try {
    const snap = await get(ref(db, "appSettings/hasFactoryReset"));
    systemHasFactoryReset = snap.exists() ? !!snap.val() : false;
    console.log(
      "原廠設定狀態：",
      systemHasFactoryReset ? "這套系統已經執行過原廠設定" : "這套系統尚未執行過原廠設定"
    );
  } catch (err) {
    console.error("開機檢查原廠設定狀態失敗：", err);
  }
}

// 1. 監聽狀態
onAuthStateChanged(auth, (user) => {
  const mask = document.getElementById("login_mask");
  const system = document.getElementById("main_system");

  if (user) {
    if (!allowedEmails.includes(user.email)) {
      showAppAlert(`您的 Google 帳號 (${user.email}) 沒有此店頭系統的存取權限！`);
      auth.signOut();
      return;
    }
    mask.classList.add("hidden");
    system.classList.remove("hidden");
    console.log("驗證通過，當前登入帳號：", user.email);
    setupPendingMileageListener();
    setupAppSettingsListener();
    setupItemStockListener();
    setupMailboxCatalogListener();
    setupRecentSearchesListener();
    checkFactoryResetStateOnBoot(); // 開機時檢查一次「是否執行過原廠設定」
    migrateItemStockIfNeeded(); // 只會真的執行一次：把舊制各分類的庫存依名稱加總合併
    syncFullRecordsToLocalDisk(); // 登入成功就把完整資料庫同步存一份到硬碟，離線時才有資料可查

    // 如果剛剛是靠離線金鑰進來的，現在正式用 Google 帳號登入成功了，
    // 代表已經恢復網路且完成驗證，關閉離線模式並把暫存的資料同步回 Firebase
    if (window.isOfflineMode) {
      window.isOfflineMode = false;
      hideOfflineModeBadge();
      updateResumeLoginPrompt();
      syncOfflineQueue();
    }
  } else {
    mask.classList.remove("hidden");
    system.classList.add("hidden");
  }
});

// ⚙️ 隱藏設定（F12，只在搜尋首頁生效才會打開）：目前有「分類選單一頁幾個品項」
// 這一項，存在 Firebase 的 appSettings/pickerPageSize，全店共用、即時同步，
// 之後要加別的設定項目，都可以照這個模式放進同一個 appSettings 底下。
let appPickerPageSize = 6; // 預設值，Firebase 還沒讀到之前先用這個
// 智慧鍵盤：開著時（預設）首頁搜尋框／顧客電話欄位會自動判斷車牌／電話／卡號、
// 自動補橫線、跳出 04-049／08-089 這種區碼選單。關掉之後純數字部分改成
// 原樣顯示、不加橫線、不跳選單，方便某些不想被自動格式化打斷的情況。
let appSmartKeyboardEnabled = true;
// 車牌上限字元（不含橫線）：首頁搜尋框車牌模式最多能打幾個字元。
let appPlateMaxLength = 7;
// 📦 進貨系統設定：庫存數字要低到多少才顯示紅色（缺貨）、多少才顯示黃色
// （偏低），以及低到多少才會出現在通知信箱裡提醒補貨。紅色門檻預設 0
// （庫存見底才算缺貨），黃色門檻預設 3，通知門檻預設也是 3（跟黃色一致，
// 亦即偏低就會提醒），三個都可以在「設定 → 一般 → 進貨系統設定」裡各自調整。
let appStockRedThreshold = 0;
let appStockYellowThreshold = 3;
let appStockNotifyThreshold = 3;
let appSettingsUnsubscribe = null;

function setupAppSettingsListener() {
  if (appSettingsUnsubscribe) appSettingsUnsubscribe();
  appSettingsUnsubscribe = onValue(ref(db, "appSettings/pickerPageSize"), (snap) => {
    const val = snap.val();
    if (typeof val === "number" && val > 0) {
      appPickerPageSize = val;
    }
  });
  onValue(ref(db, "appSettings/smartKeyboardEnabled"), (snap) => {
    const val = snap.val();
    if (typeof val === "boolean") {
      appSmartKeyboardEnabled = val;
    }
  });
  onValue(ref(db, "appSettings/plateMaxLength"), (snap) => {
    const val = snap.val();
    if (typeof val === "number" && val > 0) {
      appPlateMaxLength = val;
    }
  });
  onValue(ref(db, "appSettings/stockRedThreshold"), (snap) => {
    const val = snap.val();
    if (typeof val === "number" && val >= 0) {
      appStockRedThreshold = val;
      refreshStockThresholdDependentUI();
    }
  });
  onValue(ref(db, "appSettings/stockYellowThreshold"), (snap) => {
    const val = snap.val();
    if (typeof val === "number" && val >= 0) {
      appStockYellowThreshold = val;
      refreshStockThresholdDependentUI();
    }
  });
  onValue(ref(db, "appSettings/stockNotifyThreshold"), (snap) => {
    const val = snap.val();
    if (typeof val === "number" && val >= 0) {
      appStockNotifyThreshold = val;
      refreshStockThresholdDependentUI();
    }
  });
}

// 紅／黃／通知門檻改變時（不管是自己存的、還是別台電腦存的即時同步過來），
// 通知信箱的紅點跟清單要立刻反映新門檻，不用重開 App。品項卡片上的顏色
// 標籤本來就是每次重畫時才算顏色，不用特別處理。
function refreshStockThresholdDependentUI() {
  if (typeof updateMailboxBadge === "function") updateMailboxBadge();
  const mailboxOverlay = document.getElementById("mailbox_overlay");
  if (
    mailboxOverlay &&
    !mailboxOverlay.classList.contains("hidden") &&
    typeof renderMailboxList === "function"
  ) {
    renderMailboxList();
  }
}
window.isOfflineMode = false;

window.loginOffline = async function () {
  try {
    const result = await window.electronAPI.offlineLogin();

    window.isOfflineMode = true;

    const mask = document.getElementById("login_mask");
    const system = document.getElementById("main_system");
    mask.classList.add("hidden");
    system.classList.remove("hidden");

    showOfflineModeBadge(result.shop);
    updateResumeLoginPrompt();
    console.log("離線登入成功，授權店家：", result.shop);
  } catch (error) {
    console.error("離線登入失敗，詳細錯誤：", error);
    showAppAlert(`離線登入失敗：${error.message}`);
  }
};

function showOfflineModeBadge(shopName) {
  if (document.getElementById("offline_mode_badge")) return;
  const badge = document.createElement("div");
  badge.id = "offline_mode_badge";
  badge.className =
    "fixed top-2 right-2 z-40 bg-yellow-400 text-gray-900 text-xs font-bold px-3 py-1 rounded-full shadow";
  badge.textContent = `離線模式${shopName ? "・" + shopName : ""}（部分需要網路的功能可能無法使用）`;
  document.body.appendChild(badge);
}

function hideOfflineModeBadge() {
  const badge = document.getElementById("offline_mode_badge");
  if (badge) badge.remove();
}

// 離線模式下，一旦偵測到網路恢復，顯示一個「補登入」提示按鈕：
// 按下去會用 Google 帳號正式登入（這時候有網路了，不會再被 Google 擋），
// 登入成功後會自動把離線期間暫存的維修紀錄同步回 Firebase。
function updateResumeLoginPrompt() {
  const existing = document.getElementById("resume_login_prompt");
  if (window.isOfflineMode && navigator.onLine) {
    if (existing) return;
    const btn = document.createElement("button");
    btn.id = "resume_login_prompt";
    btn.type = "button";
    btn.className =
      "fixed top-10 right-2 z-40 bg-blue-600 text-white text-xs font-bold px-3 py-2 rounded-lg shadow hover:bg-blue-500 transition";
    btn.textContent = "已恢復網路，點此補登入並同步離線資料";
    btn.onclick = () => window.resumeOnlineLogin();
    document.body.appendChild(btn);
  } else if (existing) {
    existing.remove();
  }
}

// 補登入：其實就是正式跑一次 Google 登入流程，登入成功後
// onAuthStateChanged 會偵測到目前是離線模式，自動關閉離線模式、
// 補傳暫存的資料回 Firebase。
window.resumeOnlineLogin = async function () {
  await window.loginWithGoogle();
};

// 登出：離線模式直接回登入畫面；正常 Google 登入則呼叫 Firebase 登出，
// 畫面切換交給上面的 onAuthStateChanged 監聽自動處理。
window.logoutSystem = async function () {
  if (window.isOfflineMode) {
    window.isOfflineMode = false;
    document.getElementById("main_system").classList.add("hidden");
    document.getElementById("login_mask").classList.remove("hidden");
    hideOfflineModeBadge();
    updateResumeLoginPrompt();
    return;
  }
  try {
    await auth.signOut();
  } catch (error) {
    console.error("登出失敗：", error);
  }
};

// 關閉系統：登入畫面上的「關閉系統」按鈕。確認提醒改由作業系統原生的
// 訊息框處理（見 main.js 的 quit-app），這裡只要負責呼叫就好。
window.quitSystem = async function () {
  await window.electronAPI.quitApp();
};

// 📶 網路狀態：整個應用程式視窗右下角的訊號格圖示。
// 主程式（main.js）會定時量測 PING 值、並判斷目前是不是用 WiFi
// 連線，透過 IPC 推播過來（見 main.js 的 startWifiStrengthBroadcast）。
// - PING 值決定格數（越快格數越多），格數再決定顏色：
//   4 格＝綠色（最好）、3 格＝黃色、2 格＝橘色、1 格＝紅色（最差）。
//   PING < 15ms 屬於「4 格裡最好的那一種」，額外在圖示右上角多顯示一個
//   綠色「+」徽章，跟一般的 4 格（15~29ms）做出區別。
// - 是 WiFi 連線就顯示 WiFi 圖示（一圈一圈的訊號弧線），是有線網路
//   就顯示訊號格圖示，兩種畫面已經先畫在 index.html 裡，這裡只負責
//   切換顯示哪一個、以及每一格/每一段弧線要不要點亮、點亮要用什麼
//   顏色——WiFi 跟有線網路套用「同一套」PING 門檻跟顏色規則。
// - 完全沒有網路（ping 不到）就把當下該顯示的圖示直接劃掉（紅色斜線），
//   這部分維持原本的畫面不變，「+」徽章也會跟著隱藏。
const WIFI_INACTIVE_COLOR = "#d1d5db";
const WIFI_GREEN_COLOR = "#16a34a"; // 4 格（最好）
const WIFI_YELLOW_COLOR = "#eab308"; // 3 格
const WIFI_ORANGE_COLOR = "#f97316"; // 2 格
const WIFI_RED_COLOR = "#dc2626"; // 1 格（最差）

// PING 值（毫秒）換算成 1~4 格：數字越小代表網路越快、格數越多。
// 門檻：<15 / <30 → 4 格，<60 → 3 格，<90 → 2 格，其餘（含 >119）→ 1 格。
// 只要還在線上，最少都會顯示 1 格，不會顯示 0 格；完全離線是另外用
// 「劃掉圖示」表示，不是靠格數。
function pingMsToBars(pingMs) {
  if (pingMs === null || pingMs === undefined) return 0;
  if (pingMs < 30) return 4;
  if (pingMs < 60) return 3;
  if (pingMs < 90) return 2;
  return 1;
}

// PING < 15ms 屬於「4 格中最好的」，圖示右上角要多顯示一個「+」徽章。
function isSuperFastPing(pingMs) {
  return typeof pingMs === "number" && pingMs < 15;
}

// 格數換算成顏色：4 格＝綠色、3 格＝黃色、2 格＝橘色、1 格＝紅色。
// WiFi 跟有線網路共用這套規則。
function barsToColor(bars) {
  if (bars >= 4) return WIFI_GREEN_COLOR;
  if (bars === 3) return WIFI_YELLOW_COLOR;
  if (bars === 2) return WIFI_ORANGE_COLOR;
  return WIFI_RED_COLOR; // 1 格或 0 格（但仍在線上，只是慢到快等於沒網路）
}

let lastWifiStatus = null; // 記住最後一次主程式推播的狀態，離線/上線事件觸發時可以馬上重畫一次

function updateWifiStrengthIndicator(status) {
  if (status) lastWifiStatus = status;
  const current = lastWifiStatus;

  const wrap = document.getElementById("wifi_strength_indicator");
  const wifiIcon = document.getElementById("wifi_icon_wifi");
  const barsIcon = document.getElementById("wifi_icon_bars");
  if (!wrap || !wifiIcon || !barsIcon) return;

  const isWifi = !!(current && current.isWifi);
  const pingMs = current ? current.pingMs : null;
  const offline = !navigator.onLine || pingMs === null || pingMs === undefined;
  const activeBars = offline ? 0 : pingMsToBars(pingMs);
  const activeColor = offline ? WIFI_INACTIVE_COLOR : barsToColor(activeBars);

  // 「+」徽章：只有還在線上、而且 PING < 15ms 的時候才顯示。
  const superFastBadge = document.getElementById("wifi_super_fast_badge");
  if (superFastBadge) {
    superFastBadge.style.display = !offline && isSuperFastPing(pingMs) ? "block" : "none";
  }

  // 依連線方式切換要顯示哪一種圖示
  wifiIcon.style.display = isWifi ? "block" : "none";
  barsIcon.style.display = isWifi ? "none" : "block";
  const activeIcon = isWifi ? wifiIcon : barsIcon;
  const activeSlash = document.getElementById(
    isWifi ? "wifi_icon_wifi_slash" : "wifi_icon_bars_slash"
  );

  activeIcon.querySelectorAll("[data-bar]").forEach((el) => {
    const isActive = Number(el.dataset.bar) <= activeBars;
    const color = isActive ? activeColor : WIFI_INACTIVE_COLOR;
    if (el.tagName.toLowerCase() === "path") {
      el.setAttribute("stroke", color);
    } else {
      el.setAttribute("fill", color);
    }
  });
  if (activeSlash) activeSlash.style.display = offline ? "block" : "none";

  const tooltipText = offline
    ? "目前沒有連上網路"
    : `PING：${pingMs}ms（${isWifi ? "WiFi" : "有線網路"}）`;
  const tooltip = document.getElementById("wifi_ping_tooltip");
  if (tooltip) tooltip.textContent = tooltipText;
}

// 滑鼠移到 WIFI／網路圖示區塊時，立刻顯示自訂的 PING 值提示框
// （不用等瀏覽器原生 title 提示框那種要等一秒左右才跳出來的延遲）。
(function setupWifiPingTooltipHover() {
  const wrap = document.getElementById("wifi_strength_indicator");
  const tooltip = document.getElementById("wifi_ping_tooltip");
  if (!wrap || !tooltip) return;
  wrap.addEventListener("mouseenter", () => {
    tooltip.style.display = "block";
  });
  wrap.addEventListener("mouseleave", () => {
    tooltip.style.display = "none";
  });
})();

// 網路線插拔、WiFi 斷線重連這類「連上/斷線」的變化，瀏覽器會直接
// 觸發這兩個事件，順便重新整理一次圖示（不用等下一次定時推播）。
window.addEventListener("online", () => updateWifiStrengthIndicator(null));
window.addEventListener("offline", () => updateWifiStrengthIndicator(null));

if (window.electronAPI && window.electronAPI.onWifiStrength) {
  window.electronAPI.onWifiStrength(updateWifiStrengthIndicator);
}
if (window.electronAPI && window.electronAPI.getWifiStrength) {
  window.electronAPI.getWifiStrength().then(updateWifiStrengthIndicator);
}

// 🖥️ 設備狀態圖示：訊號格圖示左邊那一顆，用來分辨這台電腦是「桌上型
// 電腦」還是「筆記型電腦」。
// - 桌上型電腦（沒有電池）：顯示電腦圖示，依照現在有沒有網路切換
//   desktop.png（有網路）／deskoperror.png（沒網路），點一下會彈出
//   「桌上型電腦」的小提示框。
// - 筆記型電腦（查得到電池）：改顯示電池格圖示，格子裡的填色比例
//   代表目前電量百分比，正在充電的話中間會多一個閃電符號，點一下
//   會彈出「電量 XX%（充電中／未充電）」的小提示框。
let lastDeviceStatus = { hasBattery: false }; // 記住主程式最後一次推播的狀態

function updateDeviceStatusIndicator(info) {
  if (info) lastDeviceStatus = info;
  const current = lastDeviceStatus;

  const desktopIcon = document.getElementById("device_icon_desktop");
  const laptopIcon = document.getElementById("device_icon_laptop");
  if (!desktopIcon || !laptopIcon) return;

  if (current && current.hasBattery) {
    // 筆記型電腦：畫電池格圖示
    desktopIcon.style.display = "none";
    laptopIcon.style.display = "block";

    const level =
      typeof current.level === "number"
        ? Math.max(0, Math.min(100, current.level))
        : null;
    const fill = document.getElementById("device_battery_fill");
    const bolt = document.getElementById("device_battery_bolt");
    const maxWidth = 15.4; // 電池格內部可以填色的最大寬度（配合 SVG 外框）
    if (fill) {
      const w = level === null ? maxWidth : (level / 100) * maxWidth;
      fill.setAttribute("width", w.toFixed(2));
      let color = WIFI_GREEN_COLOR;
      if (level !== null && level <= 20) color = WIFI_RED_COLOR;
      else if (level !== null && level <= 50) color = WIFI_ORANGE_COLOR;
      fill.setAttribute("fill", current.charging ? WIFI_GREEN_COLOR : color);
    }
    if (bolt) bolt.style.display = current.charging ? "block" : "none";
  } else {
    // 桌上型電腦：依照現在有沒有網路切換圖示
    laptopIcon.style.display = "none";
    desktopIcon.style.display = "block";
    desktopIcon.src = navigator.onLine
      ? "assets/desktop.png"
      : "assets/deskoperror.png";
  }
}

// 滑鼠移到設備圖示上面，顯示小提示框（桌上型電腦顯示「桌上型電腦」；
// 筆記型電腦顯示電量百分比跟是否正在充電），滑鼠移開就收起來，
// 平常只留圖示在角落，不佔畫面。
function refreshDeviceStatusTooltipText() {
  const tooltip = document.getElementById("device_status_tooltip");
  if (!tooltip) return;
  const current = lastDeviceStatus;
  if (current && current.hasBattery) {
    const level = typeof current.level === "number" ? `${current.level}%` : "未知";
    tooltip.textContent = `筆記型電腦：電量 ${level}（${
      current.charging ? "充電中" : "未充電"
    }）`;
  } else {
    tooltip.textContent = "桌上型電腦";
  }
}

(function setupDeviceStatusTooltipHover() {
  const wrap = document.getElementById("device_status_indicator");
  const tooltip = document.getElementById("device_status_tooltip");
  if (!wrap || !tooltip) return;
  wrap.addEventListener("mouseenter", () => {
    refreshDeviceStatusTooltipText();
    tooltip.style.display = "block";
  });
  wrap.addEventListener("mouseleave", () => {
    tooltip.style.display = "none";
  });
})();

// 有網路／沒網路的瞬間（網路線插拔、WiFi 斷線重連），順便重畫一次
// 設備圖示（只有桌上型電腦那個圖示會跟著網路狀態變化）。
window.addEventListener("online", () => updateDeviceStatusIndicator(null));
window.addEventListener("offline", () => updateDeviceStatusIndicator(null));

if (window.electronAPI && window.electronAPI.onBatteryUpdate) {
  window.electronAPI.onBatteryUpdate(updateDeviceStatusIndicator);
}
if (window.electronAPI && window.electronAPI.getBatteryInfo) {
  window.electronAPI.getBatteryInfo().then(updateDeviceStatusIndicator);
} else {
  updateDeviceStatusIndicator({ hasBattery: false });
}


// 2. 登入功能
// 不再用 App 內嵌視窗彈出登入（Google 會擋），改成：
// 呼叫系統瀏覽器完成登入 → 拿到結果 → 換成 Firebase 認得的憑證登入。
window.loginWithGoogle = async function () {
  try {
    await setPersistence(auth, browserLocalPersistence);

    // 這一步會在使用者平常用的瀏覽器（Chrome/Edge...）開一個分頁
    // 讓他登入，App 這邊會等在背景，登入完成後自動拿到結果。
    const { idToken, accessToken } = await window.electronAPI.loginWithGoogle();

    const credential = GoogleAuthProvider.credential(idToken, accessToken);
    await signInWithCredential(auth, credential);
  } catch (error) {
    console.error("Google 登入失敗，詳細錯誤：", error);
    if (error && error.message !== "no_code_returned") {
      showAppAlert(`Google 登入失敗（${error.code || error.message}），請稍後再試！`);
    }
  }
};


// -----------------------------------------------------------------
// 💬 自製提示 / 確認視窗：取代瀏覽器原生的 alert() / confirm()。
// 原生對話框在 iframe 預覽（例如 xxx.csb.app 的內嵌頁面）裡會顯示成
// 「OO.csb.app 的內嵌頁面說」這種瀏覽器樣式，跟系統整體風格不搭，
// 所以全部改成用同一套跟系統一致的自製 modal。
// 這裡動態把 modal 的 DOM 結構插入 <body>，不需要另外修改 HTML 檔案。
// -----------------------------------------------------------------

function ensureAppDialogRoot() {
  let root = document.getElementById("app_dialog_root");
  if (root) return root;

  root = document.createElement("div");
  root.id = "app_dialog_root";
  // ⚠️ 這幾個屬性直接用行內樣式寫死，不依賴 Tailwind 的 class（例如 z-[9999] 這種
  // 方括號自訂數值語法，若專案的 Tailwind 編譯流程沒有把它編譯進最終 CSS，視窗就會
  // 失去「蓋滿全螢幕、疊在最上層」的效果，變成像插入頁面裡的一般區塊）。
  // 行內樣式的優先權最高，也完全不需要仰賴任何 CSS 檔案是否有正確編譯，最保險。
  root.style.cssText = [
    "display: none",
    "position: fixed",
    "top: 0",
    "left: 0",
    "right: 0",
    "bottom: 0",
    "z-index: 2147483647", // CSS 合法的最大 z-index，保證疊在任何其他畫面（含 detail_page、各種 modal）最上層
    "align-items: center",
    "justify-content: center",
    "background-color: rgba(0, 0, 0, 0.5)",
    "padding: 16px",
    "box-sizing: border-box",
  ].join("; ");
  root.innerHTML = `
    <div style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.4); width: 100%; max-width: 24rem; padding: 24px; box-sizing: border-box;">
      <div id="app_dialog_message" style="font-size: 1.125rem; color: #1f2937; white-space: pre-line; margin-bottom: 24px;"></div>
      <div id="app_dialog_buttons" style="display: flex; justify-content: flex-end; gap: 12px;"></div>
    </div>
  `;
  document.body.appendChild(root);
  return root;
}

function isAppDialogOpen() {
  const root = document.getElementById("app_dialog_root");
  return !!root && root.style.display !== "none";
}

// 判斷目前是不是在「搜尋車牌／卡號」首頁（沒有開任何視窗/彈窗/詳細資料頁）。
// F12 開設定、F12+Insert 開匯入舊系統資料，這兩個隱藏快捷鍵都只在這個狀態下生效，
// 避免使用者在別的畫面（例如正在編輯維修資料）不小心按到而誤觸。
function isHomeSearchScreenActive() {
  if (isAppDialogOpen()) return false;
  const guardedIds = [
    "unsaved_changes_modal",
    "repair_notes_modal",
    "edit_plate_modal",
    "estimate_choice_modal",
    "item_picker_overlay",
    "stock_in_overlay",
    "detail_page",
    "access_import_modal",
    "hidden_settings_modal",
    "boss_terminal_modal",
    "boss_revenue_modal",
    "boss_quickaccess_modal",
    "boss_forgot_password_modal",
  ];
  for (const id of guardedIds) {
    const el = document.getElementById(id);
    if (el && !el.classList.contains("hidden")) return false;
  }
  return true;
}

function closeAppDialog() {
  const root = document.getElementById("app_dialog_root");
  if (!root) return;
  root.style.display = "none";
}

let appDialogEscHandler = null; // 目前開著的 modal 對應的「取消／關閉」動作，供全域鍵盤監聽呼叫

const APP_DIALOG_BTN_BASE_STYLE =
  "padding: 10px 20px; font-size: 0.875rem; font-weight: 700; border-radius: 6px; border: none; cursor: pointer; box-shadow: 0 1px 2px rgba(0,0,0,0.1);";

// 取代 alert()：顯示訊息，按「確定」關閉。回傳 Promise，但大部分呼叫端不需要 await。
function showAppAlert(message) {
  return new Promise((resolve) => {
    const root = ensureAppDialogRoot();
    document.getElementById("app_dialog_message").textContent = message;
    const buttonsEl = document.getElementById("app_dialog_buttons");
    buttonsEl.innerHTML = `
      <button id="app_dialog_ok_btn"
        style="${APP_DIALOG_BTN_BASE_STYLE} background-color: #0f766e; color: #ffffff;">
        確定
      </button>
    `;
    root.style.display = "flex";

    const finish = () => {
      closeAppDialog();
      appDialogEscHandler = null;
      resolve();
    };
    document.getElementById("app_dialog_ok_btn").onclick = finish;
    appDialogEscHandler = finish;

    setTimeout(() => document.getElementById("app_dialog_ok_btn")?.focus(), 0);
  });
}

// 取代 confirm()：顯示訊息與「取消／確定」兩個按鈕，回傳 Promise<boolean>。
function showAppConfirm(message) {
  return new Promise((resolve) => {
    const root = ensureAppDialogRoot();
    document.getElementById("app_dialog_message").textContent = message;
    const buttonsEl = document.getElementById("app_dialog_buttons");
    buttonsEl.innerHTML = `
      <button id="app_dialog_cancel_btn"
        style="${APP_DIALOG_BTN_BASE_STYLE} background-color: #f3f4f6; color: #4b5563;">
        取消
      </button>
      <button id="app_dialog_confirm_btn"
        style="${APP_DIALOG_BTN_BASE_STYLE} background-color: #dc2626; color: #ffffff;">
        確定
      </button>
    `;
    root.style.display = "flex";

    const finish = (result) => {
      closeAppDialog();
      appDialogEscHandler = null;
      resolve(result);
    };
    document.getElementById("app_dialog_confirm_btn").onclick = () => finish(true);
    document.getElementById("app_dialog_cancel_btn").onclick = () => finish(false);
    appDialogEscHandler = () => finish(false); // Esc 視同取消

    setTimeout(
      () => document.getElementById("app_dialog_confirm_btn")?.focus(),
      0
    );
  });
}

// 3. ⌨️ 虛擬與真實鍵盤核心狀態機
let rawSearchQuery = "";
let historyNavIndex = -1; // -1 代表目前是使用者自己打的內容，不是用上下鍵選出來的歷史紀錄

// 🖱️ 打字游標位置（在 rawSearchQuery 裡的 index）。
// null = 游標在最後面（預設狀態，跟以前的行為一樣：打字永遠加在最後面、
// 退格永遠刪最後一個字）。點畫面上某個打錯的字，游標就會移到那個字上面，
// 接下來打的字會直接「覆蓋」掉它，不用先按退格刪掉再重打；退格則還是
// 正常運作，可以刪掉游標前面的字（用來縮短內容）。
let searchCursorPos = null;

// 📥 最近紀錄（全店共用）：存在 Firebase 的 recentSearches/ 底下，即時同步，
// 任何一台電腦查詢或補登，其他電腦也會馬上看到同一份最近 50 筆清單。
// 每筆結構：{ query: "ASD-1234", at: 時間戳 }，依 at 由新到舊排序。
const RECENT_SEARCHES_LIMIT = 50;
let recentSearches = []; // 目前畫面上看到的清單（由 Firebase 監聽即時同步過來，由新到舊）
let recentSearchesUnsubscribe = null;

// 登入驗證通過後才掛上監聽，避免還沒登入時因為 Firebase 規則擋下讀取而一直跳權限錯誤
function setupRecentSearchesListener() {
  if (recentSearchesUnsubscribe) return; // 已經掛過就不要重複掛
  recentSearchesUnsubscribe = onValue(
    ref(db, "recentSearches"),
    (snap) => {
      const data = snap.exists() ? snap.val() : {};
      recentSearches = Object.entries(data)
        .map(([key, v]) => ({ key, query: (v && v.query) || "", at: (v && v.at) || 0 }))
        .filter((item) => item.query)
        .sort((a, b) => b.at - a.at); // 新的在前面
      updateHistoryUI();
    },
    (err) => {
      console.error("讀取最近紀錄失敗：", err);
    }
  );
}

// 新增一筆最近紀錄：同樣的車牌/卡號如果已經在清單裡，先把舊的移除，
// 避免同一台車重複出現；寫入後只留最新 50 筆，多出來的（最舊的）一併刪除。
// 多台電腦同時查詢時，大家都是加進同一份 Firebase 清單，靠時間戳排序合併，
// 不會互相蓋掉彼此的紀錄。
async function addRecentSearch(query) {
  const q = String(query || "").trim();
  if (!q) return;
  try {
    const duplicates = recentSearches.filter((item) => item.query === q);
    const keep = recentSearches.filter((item) => item.query !== q);

    const updates = {};
    duplicates.forEach((item) => {
      updates["recentSearches/" + item.key] = null;
    });

    const newKey = push(ref(db, "recentSearches")).key;
    updates["recentSearches/" + newKey] = { query: q, at: Date.now() };

    // 加上這一筆之後，如果會超過上限，把最舊的幾筆一起刪掉
    if (keep.length + 1 > RECENT_SEARCHES_LIMIT) {
      keep
        .sort((a, b) => b.at - a.at)
        .slice(RECENT_SEARCHES_LIMIT - 1)
        .forEach((item) => {
          updates["recentSearches/" + item.key] = null;
        });
    }

    await update(ref(db), updates);
  } catch (err) {
    console.error("寫入最近紀錄失敗：", err);
  }
}

// 車牌變更時，把最近紀錄裡對應的舊車牌文字換成新的（全店共用，直接改 Firebase 上的節點）
async function renameRecentSearch(oldQuery, newQuery) {
  const matches = recentSearches.filter((item) => item.query === oldQuery);
  if (matches.length === 0) return;
  try {
    const updates = {};
    matches.forEach((item) => {
      updates["recentSearches/" + item.key + "/query"] = newQuery;
    });
    await update(ref(db), updates);
  } catch (err) {
    console.error("更新最近紀錄車牌失敗：", err);
  }
}

function updateHistoryUI() {
  const historyListEl = document.getElementById("history_list");
  if (!historyListEl) return;

  if (recentSearches.length === 0) {
    historyListEl.innerHTML = `<span class="text-gray-400 text-sm italic">暫無近期紀錄</span>`;
    return;
  }

  historyListEl.innerHTML = recentSearches
    .map(
      (item) => `
    <button
      onclick="loadFromHistory('${escapeAttr(item.query)}')"
      class="bg-blue-50 hover:bg-blue-100 text-blue-800 font-bold px-3 py-1 text-sm rounded-md border border-blue-200 transition active:scale-95 shadow-sm text-left w-full"
    >
      ${escapeAttr(item.query)}
    </button>
  `
    )
    .join("");
}

// 🟢 點擊歷史標籤：回填搜尋框，並直接開啟該筆資料（沿用快取，不重打 Firebase）
window.loadFromHistory = function (recordText) {
  historyNavIndex = -1;
  rawSearchQuery = recordText.replace(/-/g, "");
  searchCursorPos = null;
  updateSearchDisplay();
  processSearch();
};

// ⬆️⬇️ 上下鍵切換搜尋框內容為最近的歷史紀錄。direction: 1 = 上一筆（較舊）、-1 = 下一筆（較新）。
function navigateSearchHistory(direction) {
  if (recentSearches.length === 0) return;

  const nextIndex = historyNavIndex + direction;

  if (nextIndex < 0) {
    // 已經回到最新，上下鍵再往下按就清空，回到還沒選取歷史紀錄的狀態
    historyNavIndex = -1;
    rawSearchQuery = "";
    searchCursorPos = null;
    updateSearchDisplay();
    return;
  }

  if (nextIndex >= recentSearches.length) return; // 已經是最舊的一筆，不再繼續

  historyNavIndex = nextIndex;
  rawSearchQuery = recentSearches[nextIndex].query.replace(/-/g, "");
  searchCursorPos = null;
  updateSearchDisplay();
}

// -----------------------------------------------------------------
// ⚠️ 待補里程：技師忘記量里程數時，可以先用「里程晚點補登」按鈕儲存其他
// 維修資料，系統會把這台車記錄到全店共用的 pendingMileage 清單，並顯示
// 在搜尋畫面鍵盤下方，方便任何一台裝置都能看到、點一下就直接載入去補登。
// 只要之後用正常的「儲存維修資料」幫同一台車存入一筆有效里程，這筆提醒
// 就會自動消失；也可以按提示標籤上的「✕」手動關閉提醒。
// -----------------------------------------------------------------

function escapeAttrForBadge(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function renderPendingMileageList(data) {
  const container = document.getElementById("pending_mileage_container");
  const listEl = document.getElementById("pending_mileage_list");
  if (!container || !listEl) return;

  const entries = Object.entries(data || {});

  if (entries.length === 0) {
    container.classList.add("hidden");
    container.classList.remove("flex");
    listEl.innerHTML = "";
    return;
  }

  container.classList.remove("hidden");
  container.classList.add("flex");

  // 依儲存時間排序，最早忘記補的排前面，比較不容易被漏掉
  entries.sort((a, b) => (a[1]?.savedAt || 0) - (b[1]?.savedAt || 0));

  listEl.innerHTML = entries
    .map(([key, item]) => {
      const label = escapeAttrForBadge((item && item.query) || key);
      return `
      <span class="flex items-center justify-between w-full bg-orange-100 hover:bg-orange-200 text-orange-800 font-bold rounded-lg border-2 border-orange-300 transition shadow-sm overflow-hidden">
        <button onclick="loadPendingMileageRecord('${escapeAttrForBadge(
          key
        )}', '${label}')" class="flex-1 min-w-0 text-left px-3 py-2 truncate">${label}</button>
        <button onclick="dismissPendingMileage('${escapeAttrForBadge(
          key
        )}')" title="移除這則提醒"
          class="flex-shrink-0 px-2 py-2 text-orange-400 hover:text-orange-700 hover:bg-orange-200 font-black border-l-2 border-orange-300">✕</button>
      </span>`;
    })
    .join("");
}

let pendingMileageUnsubscribe = null;

// 登入驗證通過後才掛上監聽，避免還沒登入時因為 Firebase 規則擋下讀取而一直跳權限錯誤
function setupPendingMileageListener() {
  if (pendingMileageUnsubscribe) return; // 已經掛過就不要重複掛
  pendingMileageUnsubscribe = onValue(
    ref(db, "pendingMileage"),
    (snap) => {
      renderPendingMileageList(snap.exists() ? snap.val() : null);
    },
    (err) => {
      console.error("讀取待補里程清單失敗：", err);
    }
  );
}

// 手動移除單一筆「待補里程」提醒（不影響已經存進去的維修紀錄本身）
window.dismissPendingMileage = async function (key) {
  try {
    await remove(ref(db, "pendingMileage/" + key));
  } catch (err) {
    console.error("移除待補里程提醒失敗：", err);
    showAppAlert(`移除提醒失敗：${err.code || err.message || "未知錯誤"}`);
  }
};

// 🟠 點擊「待補里程」標籤：key 就是 records/ 底下的實際路徑（車牌／卡號正規化後的值），
// 不需要再重新解析文字或格式化，直接用這把 key 開啟資料頁，比透過搜尋框繞一圈更準確、更快。
// 資料載入完成後，會自動找出這台車「里程晚點補登」還沒填的那一筆，直接把內容帶回表單，
// 讓使用者只要專心填里程再存檔——存檔時是更新這筆既有紀錄，不會又跑出一筆新紀錄。
window.loadPendingMileageRecord = async function (key, queryLabel) {
  rawSearchQuery = "";
  searchCursorPos = null;
  updateSearchDisplay();
  await openDetailPage(queryLabel, key);

  const cached = recordCache.get(key);
  const repairsObj = (cached && cached.repairs) || {};
  const pendingEntries = Object.entries(repairsObj)
    .filter(([, r]) => r && r.mileageMissing)
    .sort((a, b) => (b[1].datetime || "").localeCompare(a[1].datetime || ""));

  if (pendingEntries.length > 0) {
    const [repairId, repairData] = pendingEntries[0];
    prefillRepairFormForPendingMileage(repairId, repairData);
  } else {
    console.warn(
      "在這台車的紀錄裡找不到任何 mileageMissing 的維修紀錄，可能資料已經被補上或提醒已過期。"
    );
  }

  // 同步一份到最近紀錄（全店共用），方便之後還能用歷史紀錄快速找回來
  addRecentSearch(queryLabel);
};

// 渲染與智慧車牌格式化更新
function updateSearchDisplay() {
  const displayEl = document.getElementById("search_display");
  const placeholderEl = document.getElementById("placeholder");

  // 先依目前輸入內容同步電話草稿／04-049、08-089 選單（純數字才會有東西）；
  // 智慧鍵盤關掉時就不產生電話草稿、不跳選單。
  if (appSmartKeyboardEnabled) {
    syncPhoneDraftFromSearchQuery();
  } else if (homePhoneDraft.number || homePhoneDraft.areaChoice) {
    homePhoneDraft = { number: "", areaChoice: undefined };
    const choiceSelect = document.getElementById("home_phone_area_choice");
    if (choiceSelect) choiceSelect.classList.add("hidden");
  }

  let formattedText = rawSearchQuery;

  if (isPlateModeQuery(rawSearchQuery)) {
    // 含英文字母 → 100% 車牌，照原本車牌格式化規則（不受智慧鍵盤開關影響）
    if (/^([A-Z]+)([0-9]+)/.test(rawSearchQuery)) {
      formattedText = rawSearchQuery.replace(/^([A-Z]+)([0-9]+)/, "$1-$2");
    } else if (/^([0-9]+)([A-Z]+)/.test(rawSearchQuery)) {
      formattedText = rawSearchQuery.replace(/^([0-9]+)([A-Z]+)/, "$1-$2");
    }
  } else if (appSmartKeyboardEnabled) {
    // 純數字 → 比照電話格式化（找不到對得上的區碼就當卡號，原樣顯示）
    formattedText = formatDigitsForSearchDisplay(rawSearchQuery);
  }
  // 智慧鍵盤關掉時純數字原樣顯示，不加橫線

  // 游標永遠是相對「原始字串（沒有橫線）」的位置，所以每個顯示出來的字元
  // （橫線除外）都要標上它在 rawSearchQuery 裡對應的 index，點擊時才能
  // 準確換算回游標該落在哪裡。橫線本身不能點，點了沒意義。
  let rawIndex = 0;
  const charsHtml = formattedText
    .split("")
    .map((ch) => {
      if (ch === "-") {
        return `<span class="pointer-events-none">-</span>`;
      }
      const idx = rawIndex;
      rawIndex += 1;
      return `<span onclick="event.stopPropagation(); window.setSearchCursorPos(${idx})" class="cursor-text">${ch}</span>`;
    })
    .join("");

  const cursorHtml =
    '<span class="bg-blue-600 w-1 h-7 ml-0.5 inline-block align-middle animate-blink"></span>';

  const hasValidCursor =
    typeof searchCursorPos === "number" &&
    searchCursorPos >= 0 &&
    searchCursorPos < rawSearchQuery.length;

  if (!hasValidCursor) {
    // 游標在最後面（預設狀態）
    searchCursorPos = null;
    displayEl.innerHTML = charsHtml + cursorHtml;
  } else {
    // 把游標插進去它對應的那個字元前面。因為橫線會讓「顯示字串」跟
    // 「原始字串」的字元數不一樣，這裡要重新算一次橫線在哪裡插入。
    let insertAtChar = searchCursorPos;
    if (
      formattedText.includes("-") &&
      searchCursorPos >= formattedText.indexOf("-")
    ) {
      insertAtChar += 1; // 游標落在橫線之後的字元，要多跳過橫線那一格
    }
    const chars = charsHtml.match(/<span[^>]*>[^<]*<\/span>/g) || [];
    chars.splice(insertAtChar, 0, cursorHtml);
    displayEl.innerHTML = chars.join("");
  }

  if (formattedText.length > 0) {
    placeholderEl.classList.add("hidden");
  } else {
    placeholderEl.classList.remove("hidden");
  }
}

// 🖱️ 點擊顯示區裡的某個字元：把游標移到那個字元前面
window.setSearchCursorPos = function (rawIndex) {
  searchCursorPos = rawIndex;
  updateSearchDisplay();
};

// 🖱️ 點擊輸入框空白處（沒點到任何字元）：游標回到最後面，跟以前行為一樣
window.handleSearchScreenClick = function () {
  searchCursorPos = null;
  updateSearchDisplay();
};

// 虛擬鍵盤點擊輸入
// 游標在最後面（預設）：照舊，直接接在後面。
// 游標被點到某個字元上：在游標位置「插入」新字元，後面的字往右推一格
// （不是覆蓋，不會蓋掉原本的字），打完游標自動往右移一格，方便連續補打
// 好幾個漏打的字；打到最後面就自動回到「最後面」模式。
window.typeKey = function (char) {
  historyNavIndex = -1;
  const upperChar = char.toUpperCase();

  let prospective;
  let nextCursorPos;
  if (searchCursorPos === null || searchCursorPos >= rawSearchQuery.length) {
    prospective = rawSearchQuery + upperChar;
    nextCursorPos = null;
  } else {
    const pos = searchCursorPos;
    prospective =
      rawSearchQuery.slice(0, pos) + upperChar + rawSearchQuery.slice(pos);
    nextCursorPos = pos + 1 >= prospective.length ? null : pos + 1;
  }

  // 車牌模式（含英文字母）最多 appPlateMaxLength 個字元（不含橫線，橫線只是顯示用，
  // rawSearchQuery 本來就不含橫線，不受智慧鍵盤開關影響）；純數字（電話／卡號）模式，
  // 智慧鍵盤開著時才會在打到區碼對應的碼數上限時忽略這次按鍵，關掉就自由輸入。
  if (isPlateModeQuery(prospective)) {
    if (prospective.length > appPlateMaxLength) return;
  } else if (appSmartKeyboardEnabled && isDigitInputOverLimit(prospective)) {
    return;
  }

  rawSearchQuery = prospective;
  searchCursorPos = nextCursorPos;
  updateSearchDisplay();
};

// 全部清除
window.clearSearch = function () {
  historyNavIndex = -1;
  rawSearchQuery = "";
  searchCursorPos = null;
  updateSearchDisplay();
};

// -----------------------------------------------------------------
// 📞 車牌／電話／卡號「合一」輸入框：不再另外開一個電話欄位，同一個搜尋框
// 打完之後，系統自己判斷這次打的到底是車牌、卡號、還是電話：
//
//   • 只要出現任何英文字母 → 100% 是車牌（因為電話跟卡號都是純數字），
//     直接照原本的車牌格式化 / 搜尋邏輯走，完全不會被當成電話。
//   • 純數字 → 照舊當「車牌／卡號」去搜尋（跟以前行為一樣，不影響搜尋結果），
//     同時「順便」比照顧客資訊電話欄位一樣的格式化／04-049 判斷邏輯，
//     把這串數字也存成一份電話草稿，開啟資料後如果這台車還沒有這支電話，
//     就自動帶進顧客資訊、切成編輯模式，讓使用者確認沒問題再按「儲存」。
//
// 這樣「查資料」跟「順便留電話」共用同一個輸入框跟同一套動作，不用重複打兩次。
// -----------------------------------------------------------------
let homePhoneDraft = { number: "", areaChoice: undefined };

// 判斷目前搜尋框內容是不是「車牌模式」：只要含有任何英文字母就一定是車牌
function isPlateModeQuery(str) {
  return /[A-Z]/.test(str || "");
}

// 每次搜尋框內容變動時呼叫：純數字才會產生電話草稿並顯示 04/049 選單；
// 車牌模式或空字串就把電話草稿清掉、選單收起來。
function syncPhoneDraftFromSearchQuery() {
  const choiceSelect = document.getElementById("home_phone_area_choice");

  if (isPlateModeQuery(rawSearchQuery) || rawSearchQuery.length === 0) {
    homePhoneDraft = { number: "", areaChoice: undefined };
    if (choiceSelect) choiceSelect.classList.add("hidden");
    return;
  }

  const digits = rawSearchQuery; // 車牌模式已排除，這裡一定是純數字
  const ambiguous = isAmbiguousAreaPrefix(digits);

  if (ambiguous) {
    if (!homePhoneDraft.areaChoice) {
      homePhoneDraft.areaChoice = defaultAreaChoiceFor(digits);
    }
  } else {
    homePhoneDraft.areaChoice = undefined;
  }

  const forcedPrefix = ambiguous ? homePhoneDraft.areaChoice : undefined;
  homePhoneDraft.number = formatTaiwanPhoneNumber(digits, forcedPrefix);

  if (choiceSelect) {
    choiceSelect.classList.toggle("hidden", !ambiguous);
    if (ambiguous) {
      choiceSelect.innerHTML = areaChoiceOptionsHtml(digits, homePhoneDraft.areaChoice);
      choiceSelect.value = homePhoneDraft.areaChoice;
    }
  }
}

// 使用者手動點選 04／049：只影響電話草稿跟搜尋框「顯示」時的橫線位置，
// 不影響實際的搜尋內容（去掉橫線後的數字完全一樣，搜尋結果不受影響）。
window.handleSearchPhoneAreaChoice = function (choice) {
  homePhoneDraft.areaChoice = choice;
  homePhoneDraft.number = formatTaiwanPhoneNumber(rawSearchQuery, choice);
  updateSearchDisplay();
};

// 純數字（電話／卡號）模式下，判斷再打一碼會不會超過區碼對應的碼數上限。
// 前 4 碼還看不出來是哪種區碼，先不限制；對不到任何已知區碼的（例如較長的
// 卡號），視為卡號，同樣不限制長度，維持原本可以打任意長度卡號的彈性。
function isDigitInputOverLimit(digits) {
  if (digits.length <= 4) return false;

  if (digits.startsWith("09")) return digits.length > 10;

  let area = null;
  if (homePhoneDraft.areaChoice && digits.startsWith(homePhoneDraft.areaChoice)) {
    area = PHONE_AREA_CODES.find((a) => a.prefix === homePhoneDraft.areaChoice);
  }
  if (!area) {
    area = PHONE_AREA_CODES.find((a) => digits.startsWith(a.prefix));
  }
  if (!area) return false;

  return digits.length > area.maxDigits - 1;
}

// 純數字時，把搜尋框要「顯示」的文字，比照電話號碼的方式補上橫線
// （只補一個橫線，邏輯跟車牌格式化一樣：只是插入符號，不會增減字元數量，
// 這樣游標定位那套邏輯才不用另外處理）。
function formatDigitsForSearchDisplay(digits) {
  if (digits.length <= 4) return digits;

  if (digits.startsWith("09")) return digits; // 手機號碼不加橫線

  let area = null;
  if (homePhoneDraft.areaChoice) {
    area = PHONE_AREA_CODES.find(
      (a) => a.prefix === homePhoneDraft.areaChoice && digits.startsWith(a.prefix)
    );
  }
  if (!area) {
    area = PHONE_AREA_CODES.find((a) => digits.startsWith(a.prefix));
  }
  if (!area) return digits; // 對不到任何區碼，當純卡號處理，不加橫線

  const rest = digits.slice(area.prefix.length);
  return rest ? `${area.prefix}-${rest}` : area.prefix;
}

// 資料頁打開、讀到最新的顧客資料後呼叫：如果首頁順便打了電話、而且這支電話
// 還不在這台車現有的電話清單裡，就自動把它加進去、切成編輯模式，
// 讓使用者一打開顧客資訊分頁就看到這筆電話已經填好，按「儲存」就完成了。
// 如果那支電話本來就已經存在，就不動作，避免造成重複或不必要地跳出編輯模式。
function applyHomePhoneDraftToCustomer(data) {
  const digits = homePhoneDraft.number
    ? String(homePhoneDraft.number).replace(/\D/g, "")
    : "";
  if (!digits) return;

  const c = (data && data.customer) || {};
  const existingPhones = getCustomerPhoneList(c);
  const alreadyExists = existingPhones.some(
    (p) => String(p.number || "").replace(/\D/g, "") === digits
  );

  if (!alreadyExists) {
    customerEditPhones = [
      ...existingPhones,
      {
        type: phoneTypeForDigits(digits),
        number: homePhoneDraft.number,
        areaChoice: homePhoneDraft.areaChoice,
      },
    ];
    customerEditMode = true;
    renderCustomerPanel(data);
  }

  homePhoneDraft = { number: "", areaChoice: undefined };
  const choiceSelect = document.getElementById("home_phone_area_choice");
  if (choiceSelect) choiceSelect.classList.add("hidden");
}

// 退格鍵：游標在最後面就刪最後一個字（跟以前一樣）；
// 游標在中間，就刪「游標前面那個字」，游標跟著往前移一格。
window.backspaceKey = function () {
  historyNavIndex = -1;
  if (searchCursorPos === null || searchCursorPos >= rawSearchQuery.length) {
    rawSearchQuery = rawSearchQuery.slice(0, -1);
    searchCursorPos = null;
  } else if (searchCursorPos > 0) {
    rawSearchQuery =
      rawSearchQuery.slice(0, searchCursorPos - 1) +
      rawSearchQuery.slice(searchCursorPos);
    searchCursorPos -= 1;
  }
  updateSearchDisplay();
};

// -----------------------------------------------------------------
// 📄 詳細資料頁：維修資料 / 顧客資訊 / 歷史維修紀錄
// -----------------------------------------------------------------

// 🧠 記憶體快取：同一次使用期間，同一把 key 只跟 Firebase 要一次資料，
// 避免重複查詢浪費流量／額度。
const recordCache = new Map();

let currentTab = "repair";
let currentRecordKey = null;

function setDetailLoading(isLoading) {
  document
    .getElementById("detail_loading")
    .classList.toggle("hidden", !isLoading);
}

// 只抓一次、單一路徑，一次把三個分頁需要的資料全部拿回來，
// 用「一次讀取」取代三次個別查詢，最省流量。
async function fetchRecord(key) {
  if (recordCache.has(key)) {
    return recordCache.get(key);
  }
  const snap = await get(ref(db, "records/" + key));
  const data = snap.exists() ? snap.val() : null;
  recordCache.set(key, data);
  return data;
}

// -----------------------------------------------------------------
// 📶 離線支援：斷網時新增的維修紀錄不會嘗試連線、也不會卡住等待逾時，
// 而是直接存進磁碟上的資料夾（%APPDATA%\...\offline-data\
// pending-repairs.json）當作佇列，畫面上先用「尚未上傳」標記讓使用者
// 安心；恢復網路連線後會自動依序把佇列裡的紀錄補傳到 Firebase，
// 成功一筆才從佇列移除一筆，確保就算店裡網路不穩定、甚至應用程式或
// 電腦重開機，離線期間存的資料也不會不見。
// -----------------------------------------------------------------

let offlineQueue = [];
let isOnline = navigator.onLine;
let isSyncing = false;
let lastFullSyncAt = null; // 上次把完整資料庫同步存到硬碟的時間，null 代表這次開機還沒同步過
let isFullSyncing = false;
let localPageAutoSyncTask = null; // 「本機空間」子頁一打開自動觸發同步用的防重入旗標（見下面 triggerLocalPageAutoSync）

async function saveOfflineQueue() {
  try {
    await window.electronAPI.writeOfflineQueue(offlineQueue);
    return true;
  } catch (err) {
    console.error("寫入離線佇列檔案失敗：", err);
    return false;
  }
}

async function loadOfflineQueue() {
  try {
    offlineQueue = await window.electronAPI.readOfflineQueue();
  } catch (err) {
    console.error("讀取離線佇列檔案失敗，視為空佇列：", err);
    offlineQueue = [];
  }
}

// -----------------------------------------------------------------
// 💾 完整資料硬碟快取：跟上面的「離線佇列」是兩件不同的事——離線佇列只
// 存「離線時新增、還沒上傳」的紀錄；這裡則是把 Firebase 上「已經存在」的
// 完整車籍／維修紀錄資料庫，整份鏡像存一份到硬碟（records-cache.json）。
//
// 用途：不管這台電腦有沒有在這次開機期間查過某筆車籍，只要曾經在有網路
// 時完整同步過一次，之後突然斷網、甚至換了一顆全新硬碟重灌本程式，只要
// 再連得上網路完整同步一次，接下來離線時一樣查得到所有車籍資料。
// -----------------------------------------------------------------

// 把 Firebase 上完整的車籍／維修紀錄資料庫抓下來，寫一份到硬碟，同時灌進
// 記憶體快取讓畫面立刻反映最新資料。失敗只記錄錯誤、不影響其他功能——
// 原本「查一筆抓一筆」的 fetchRecord() 還是照常運作。
// ============================================================
// 🚦「設定 > 儲存空間」背景工作
//
// 原本「本機完整同步」跟「遠端空間估算」是同一頁、同時（並行）觸發，
// 兩邊都要把整個資料庫讀進記憶體、同步處理，資料量一大就容易同時卡爆
// 記憶體跟主執行緒，導致系統當掉。
//
// 現在「儲存空間」拆成「本機空間」「遠端空間」兩個獨立子頁，使用者打開
// 哪一頁才觸發哪一邊的背景工作，不會兩邊同時搶記憶體；算尺寸的重計算
// 一樣搬到 Web Worker 做（見下面 computeJsonByteSizeOffMainThread），
// 不會卡住畫面主執行緒。
// ============================================================
// ============================================================
// 🧵 把「算資料大小」這種重計算丟到背景執行緒（Web Worker）做，
// 不要卡在主執行緒——JSON.stringify 一大包資料、再包成 Blob 量大小，
// 是同步操作，資料量一大就會讓整個畫面卡頓、點不動。丟給 Worker 算，
// 只把最後算出來的「位元組數」丟回來，主畫面全程都能正常滑動、點擊。
// ============================================================
let jsonByteSizeWorker = null;
let jsonByteSizeWorkerNextId = 1;
const jsonByteSizeWorkerPending = new Map();

function getJsonByteSizeWorker() {
  if (jsonByteSizeWorker) return jsonByteSizeWorker;
  const workerSource = `
    self.onmessage = function (e) {
      const { id, value } = e.data;
      try {
        const size = new Blob([JSON.stringify(value ?? null)]).size;
        self.postMessage({ id, size });
      } catch (err) {
        self.postMessage({ id, error: String(err && err.message ? err.message : err) });
      }
    };
  `;
  const blob = new Blob([workerSource], { type: "application/javascript" });
  jsonByteSizeWorker = new Worker(URL.createObjectURL(blob));
  jsonByteSizeWorker.onmessage = (e) => {
    const { id, size, error } = e.data || {};
    const pending = jsonByteSizeWorkerPending.get(id);
    if (!pending) return;
    jsonByteSizeWorkerPending.delete(id);
    if (error) pending.reject(new Error(error));
    else pending.resolve(size);
  };
  return jsonByteSizeWorker;
}

// 傳一份資料進去，回傳它轉成 JSON 後的位元組數——實際計算在背景執行緒跑，
// 不會擋住畫面。萬一這台電腦的瀏覽器環境不支援 Web Worker（理論上不會，
// 但還是留一手），退回原本直接在主執行緒算的做法，至少功能還能動。
function computeJsonByteSizeOffMainThread(value) {
  try {
    const worker = getJsonByteSizeWorker();
    const id = jsonByteSizeWorkerNextId++;
    return new Promise((resolve, reject) => {
      jsonByteSizeWorkerPending.set(id, { resolve, reject });
      worker.postMessage({ id, value });
    });
  } catch (err) {
    console.error("建立背景計算執行緒失敗，改用主執行緒計算：", err);
    return Promise.resolve(new Blob([JSON.stringify(value ?? null)]).size);
  }
}

async function syncFullRecordsToLocalDisk() {
  if (isFullSyncing || !isOnline) return false;
  isFullSyncing = true;
  try {
    const snap = await get(ref(db, "records"));
    const allRecords = snap.exists() ? snap.val() : {};

    // 記憶體先更新——這樣別的頁面（查車籍、看歷史維修）立刻就能用到
    // 最新資料，不用等硬碟寫完。硬碟只是拿來做「離線持久化」的備份，
    // 慢一點、晚一點寫完沒關係，不該卡住畫面上其他正在做的事。
    Object.keys(allRecords).forEach((key) => recordCache.set(key, allRecords[key]));
    if (typeof settingsCurrentPage !== "undefined" && settingsCurrentPage === "storage_local") {
      renderHiddenSettingsBody();
    }

    // 硬碟寫入交給 main process 背景執行緒處理（見 main.js 的
    // local-cache-write），不會卡住其他頁面同時在做的 IPC 操作
    // （例如列印、存檔、開啟對話框）。
    await window.electronAPI.writeLocalCache(allRecords);
    lastFullSyncAt = Date.now();
    if (typeof settingsCurrentPage !== "undefined" && settingsCurrentPage === "storage_local") {
      renderHiddenSettingsBody();
    }
    return true;
  } catch (err) {
    console.error("同步完整資料到本機硬碟失敗：", err);
    return false;
  } finally {
    isFullSyncing = false;
  }
}

// 開機時：先把上次存在硬碟裡的完整資料快取讀進記憶體。這樣就算這次還沒
// 連上網路、還沒查過任何一筆車籍，只要之前完整同步過，離線時一樣查得到。
async function loadLocalDiskCacheIntoMemory() {
  try {
    const cached = await window.electronAPI.readLocalCache();
    if (cached && typeof cached === "object") {
      Object.keys(cached).forEach((key) => {
        if (!recordCache.has(key)) recordCache.set(key, cached[key]);
      });
    }
  } catch (err) {
    console.error("讀取本機硬碟資料快取失敗：", err);
  }
}

function generateTempId() {
  return `offline_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function updateNetworkBanner() {
  const banner = document.getElementById("network_banner");
  if (!banner) return;

  if (!isOnline) {
    banner.textContent =
      offlineQueue.length > 0
        ? `目前離線，已有 ${offlineQueue.length} 筆維修紀錄暫存在本機，恢復網路後會自動上傳`
        : `目前離線，新增的維修紀錄會先存在本機，恢復網路後自動上傳`;
    banner.className =
      "fixed top-0 left-0 right-0 z-50 text-center py-2 text-sm font-bold shadow-lg bg-red-600 text-white";
    return;
  }

  if (isSyncing || offlineQueue.length > 0) {
    banner.textContent = `正在補傳 ${offlineQueue.length} 筆離線維修紀錄...`;
    banner.className =
      "fixed top-0 left-0 right-0 z-50 text-center py-2 text-sm font-bold shadow-lg bg-blue-600 text-white";
    return;
  }

  banner.className = "hidden";
  banner.textContent = "";
}

// 把離線紀錄放進畫面上的本地快取，讓歷史紀錄分頁能立刻看到（標記尚未上傳）
function addPendingRecordToCache(key, tempId, record) {
  const cached = recordCache.get(key) || {};
  cached.repairs = cached.repairs || {};
  cached.repairs[tempId] = { ...record, _pending: true };
  recordCache.set(key, cached);
  if (currentRecordKey === key) {
    renderHistoryPanel(cached);
  }
}

// 補傳成功後，把本機暫存那一筆換成正式的 Firebase 資料（拿掉「尚未上傳」標記）
function replacePendingRecordInCache(key, tempId, realKey, record) {
  const cached = recordCache.get(key);
  if (!cached || !cached.repairs) return;
  delete cached.repairs[tempId];
  cached.repairs[realKey] = record;
  recordCache.set(key, cached);
  if (currentRecordKey === key) {
    renderHistoryPanel(cached);
  }
}

// 把一筆維修紀錄放進離線佇列並寫入硬碟，同時更新畫面顯示。
// 這裡刻意用 async/await 把「寫進硬碟」這件事等到真的完成才返回——
// 不管電腦之後是正常關機、被強制關機、還是突然斷電，只要使用者已經看到
// 「維修紀錄已儲存」的提示，這筆資料就一定已經真的寫進硬碟了，不會是
// 「畫面顯示存好了，但其實還在等寫入」的空窗期。
async function queueOfflineRecord(key, record, queryLabel) {
  const tempId = generateTempId();
  offlineQueue.push({
    tempId,
    key,
    record,
    queryLabel: queryLabel || key,
    createdAt: Date.now(),
  });
  const savedToDisk = await saveOfflineQueue();
  addPendingRecordToCache(key, tempId, record);
  updateNetworkBanner();
  return savedToDisk;
}

// 依序把佇列裡的離線紀錄補傳到 Firebase，一筆一筆處理；
// 只要有一筆失敗（例如網路又斷了、或其實根本沒連上真正的網路），就停下來，
// 剩下的留到下一次 online 事件或定時重試再繼續，已成功的不會重複上傳。
async function syncOfflineQueue() {
  if (isSyncing || !isOnline || offlineQueue.length === 0) return;
  isSyncing = true;
  updateNetworkBanner();

  while (offlineQueue.length > 0 && isOnline) {
    const item = offlineQueue[0];
    try {
      const newRef = push(ref(db, "records/" + item.key + "/repairs"));
      await set(newRef, item.record);
      deductStockForRepairItems(item.record.itemsDetail); // 離線紀錄補傳成功後才扣庫存

      // 待補里程清單也要等這筆紀錄真的上傳成功才同步，避免紀錄還在本機
      // 硬碟排隊，Firebase 上卻已經顯示補登過了的不一致狀況。
      try {
        if (item.record.mileageMissing) {
          await set(ref(db, "pendingMileage/" + item.key), {
            query: item.queryLabel || item.key,
            savedAt: Date.now(),
          });
        } else {
          await remove(ref(db, "pendingMileage/" + item.key));
        }
      } catch (err) {
        // 待補里程清單只是輔助提醒，同步失敗不影響這筆維修紀錄本身已經上傳成功
        console.error("同步待補里程清單失敗：", err);
      }

      replacePendingRecordInCache(
        item.key,
        item.tempId,
        newRef.key,
        item.record
      );

      offlineQueue.shift();
      saveOfflineQueue();
      updateNetworkBanner();
    } catch (err) {
      console.error("補傳離線維修紀錄失敗，稍後會自動重試：", err);
      break;
    }
  }

  isSyncing = false;
  updateNetworkBanner();
}

window.addEventListener("online", () => {
  isOnline = true;
  updateNetworkBanner();
  updateResumeLoginPrompt();
  if (!window.isOfflineMode) {
    syncOfflineQueue();
    syncFullRecordsToLocalDisk(); // 恢復連線就重新把最新資料整份存回硬碟，保持離線快取新鮮
  }
});

window.addEventListener("offline", () => {
  isOnline = false;
  updateNetworkBanner();
  updateResumeLoginPrompt();
});

// 保險機制：有些情況瀏覽器不會正確觸發 online 事件（例如連上一個沒有真正
// 網路的 WiFi），所以每隔一段時間還是會主動檢查一次佇列並嘗試補傳。
// 離線模式（還沒正式登入 Firebase）不會自動嘗試，避免一直寫入失敗，
// 而是顯示補登入按鈕，等使用者按下去正式登入後才會同步。
setInterval(() => {
  if (isOnline && offlineQueue.length > 0 && !window.isOfflineMode) {
    syncOfflineQueue();
  }
}, 20000);

// -----------------------------------------------------------------
// ✍️ 維修資料：這個分頁的工作是「列清單、輸入項目、儲存寫入伺服器」，
// 不是讀取顯示用的，所以是一張可以新增項目的表單。
// -----------------------------------------------------------------

let repairRowSeq = 0;
let lastMileageValue = 0; // 上次里程數，讀不到時補 0
let repairNotesValue = ""; // 目前這筆維修紀錄的備註內容（在全螢幕備註畫面編輯）
let pendingRepairEditKey = null; // 目前是否正在「補登里程」某一筆既有紀錄（records/{key}/repairs/{此ID}），null 代表全新輸入模式
let editingHistoryRepairId = null; // 目前是否正在「編輯」歷史維修紀錄裡的某一筆（records/{key}/repairs/{此ID}），null 代表全新輸入模式；跟 pendingRepairEditKey 不同，這個是使用者從「歷史維修紀錄」點進來修改內容，存檔時要覆蓋原本那筆，不是新增
let loadedEstimateSourceId = null; // 目前表單上的品項是不是從「載入估價」帶進來的，記著那筆估價的 id（records/{key}/estimates/{此ID}），存檔成功後要把這筆來源估價刪掉，避免同一筆估價一直留在「載入估價」清單裡；null 代表不是從估價帶進來的
let currentDailyCustomerCode = ""; // 目前顯示的「當日客戶編號」（yyyymmddxxx）：查詢一開始只是預覽下一號，直到真的存檔成功才會變成正式領到的號碼

function todayStr() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function nowTimeStr() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// -----------------------------------------------------------------
// 🔢 當日客戶編號：yyyymmddxxx，xxx 是「今天全店共用」的流水號，第幾個
// 客戶就是幾號，從 001 開始。
//
// 只是「打開」一台車的查詢還不算數——這時只會用目前的計數「預覽」接下來
// 會是幾號，不會真的去佔用這個號碼；如果沒存檔就跳出去查別台車，看到的
// 還是同一個預覽號碼。真正「儲存」成功的那一刻，才會用 runTransaction
// 跟 Firebase 領走一個真正屬於這次查詢的號碼（同一次查詢期間如果存了不只
// 一次，例如里程晚點補登完成、或存完接著加下一筆，也只會領一次，不會
// 重複跳號）。用 transaction 保證多台裝置同時存檔時不會搶到同一個號碼。
// -----------------------------------------------------------------
let dailyCustomerCodeCommitted = false; // 這次查詢是否已經「真的」存檔領到號碼了

function todayDayKey() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
}

// 開啟一筆新查詢時呼叫：只預覽下一號長什麼樣子，不佔用。
async function previewDailyCustomerCode() {
  dailyCustomerCodeCommitted = false;
  currentDailyCustomerCode = "";
  updateDailyCustomerCodeLabel();

  const dayKey = todayDayKey();

  try {
    const snap = await get(ref(db, "dailyCustomerCounters/" + dayKey));
    const current = snap.exists() ? Number(snap.val()) || 0 : 0;
    if (dailyCustomerCodeCommitted) return; // 預覽還沒回來，存檔就已經搶到真編號了，不要用預覽值蓋掉
    currentDailyCustomerCode = `${dayKey}${String(current + 1).padStart(3, "0")}`;
    updateDailyCustomerCodeLabel();
  } catch (err) {
    console.error("預覽當日客戶編號失敗：", err);
    // 讀取失敗（例如 Firebase 規則還沒開放 dailyCustomerCounters 這個節點），
    // 顯示「?」讓使用者知道這裡本來應該有編號、只是抓不到，而不是整個消失
    // 讓人以為功能沒生效，方便回報問題。
    if (!dailyCustomerCodeCommitted) {
      currentDailyCustomerCode = "?";
      updateDailyCustomerCodeLabel();
    }
  }
}

// 存檔成功時呼叫：真正跟 Firebase 領一個號碼。這次查詢已經領過的話直接
// 沿用，不會再跳號。
async function commitDailyCustomerCode() {
  if (dailyCustomerCodeCommitted && currentDailyCustomerCode) {
    return currentDailyCustomerCode;
  }
  const dayKey = todayDayKey();
  try {
    const result = await runTransaction(
      ref(db, "dailyCustomerCounters/" + dayKey),
      (current) => (current || 0) + 1
    );
    if (result && result.committed) {
      const seq = result.snapshot.val();
      currentDailyCustomerCode = `${dayKey}${String(seq).padStart(3, "0")}`;
      dailyCustomerCodeCommitted = true;
      updateDailyCustomerCodeLabel();
    }
  } catch (err) {
    console.error("領取當日客戶編號失敗：", err);
  }
  return currentDailyCustomerCode;
}

function updateDailyCustomerCodeLabel() {
  const el = document.getElementById("daily_customer_code_label");
  if (!el) return;
  el.textContent = currentDailyCustomerCode;
  const isError = currentDailyCustomerCode === "?";
  el.classList.toggle("text-gray-500", !isError);
  el.classList.toggle("text-red-600", isError);
  el.classList.toggle("font-bold", isError);
  el.classList.toggle("text-sm", isError);
  el.classList.toggle("text-xs", !isError);
  el.title = isError
    ? "抓不到當日客戶編號，可能是 Firebase 規則沒開放 dailyCustomerCounters 這個節點"
    : "";
}

// 從快取資料算出「上次里程數」：抓最新一筆維修紀錄的里程，
// 沒有維修紀錄就退回車輛基本資料的里程，都沒有就是 0。
function computeLastMileage(data) {
  const repairs = (data && data.repairs) || {};
  const list = Object.values(repairs)
    .filter((r) => r.mileage != null)
    .sort((a, b) =>
      (b.datetime || b.date || "").localeCompare(a.datetime || a.date || "")
    );
  if (list.length > 0) return Number(list[0].mileage) || 0;
  if (data && data.vehicle && data.vehicle.mileage != null) {
    return Number(data.vehicle.mileage) || 0;
  }
  return 0;
}

// -----------------------------------------------------------------
// 🔧 保養提醒：混合兩種比對方式。
// 「機油、輪胎、齒輪油」這三項因為容易混淆（例如機油/齒輪油品項名稱相近），
// 用「保養項目」下拉選單精準標記比對，不解析文字，不會因為打字方式不同而誤判。
// 其餘項目（大小海綿、積碳藥水、火星塞、節流閥、煞車油/水箱精、傳動、電池、
// 煞車皮）沿用關鍵字比對，直接在品項名稱裡找符合的字詞。
// 純粹是前端根據既有資料做的判斷，不會寫入任何新資料到 Firebase。
// -----------------------------------------------------------------

// 保養項目標籤清單：新增/編輯維修項目時可選擇的「保養項目」下拉選單選項，
// 只列出用「標籤精準比對」的這幾項；其餘項目改用關鍵字比對，不需要標記。
const MAINTENANCE_TYPES = [
  { key: "none", label: "不追蹤" },
  { key: "oil", label: "機油" },
  { key: "gear_oil", label: "齒輪油" },
  { key: "tire", label: "輪胎" },
];

// 每條規則的 key 對應 MAINTENANCE_TYPES 裡的 key（僅 matchType: "tag" 需要）；
// intervalDays 用天數週期，intervalKm / intervalKmMin+intervalKmMax 用里程週期，
// 兩者最多只會設定一種。這幾個週期數字都是預設值，之後要調整店裡實際的保養
// 週期，直接改這裡的數字即可。
const MAINTENANCE_RULES = [
  { key: "oil", label: "機油", matchType: "tag", intervalKm: 1000 },
  { key: "gear_oil", label: "齒輪油", matchType: "tag", intervalKm: 2000 },
  { key: "tire", label: "輪胎", matchType: "tag", intervalKm: 5000 },
  {
    key: "sponge",
    label: "大小海綿（空濾）",
    matchType: "keyword",
    keywords: ["海綿", "空濾"],
    intervalKm: 5000,
  },
  {
    key: "carbon",
    label: "積碳藥水",
    matchType: "keyword",
    keywords: ["積碳"],
    intervalKmMin: 2000,
    intervalKmMax: 3000,
  },
  {
    key: "spark_plug",
    label: "火星塞（蓋）",
    matchType: "keyword",
    keywords: ["火星塞"],
    intervalKm: 10000,
  },
  {
    key: "throttle",
    label: "節流閥清洗",
    matchType: "keyword",
    keywords: ["節流閥"],
    intervalKm: 10000,
  },
  {
    key: "brake_fluid",
    label: "煞車油／水箱精",
    matchType: "keyword",
    keywords: ["煞車油", "水箱精", "水箱"],
    intervalDays: 365,
  },
  {
    key: "drive",
    label: "傳動（皮帶／普利／油封）",
    matchType: "keyword",
    keywords: ["皮帶", "普利", "油封"],
    intervalKm: 20000,
  },
  {
    key: "battery",
    label: "電池",
    matchType: "keyword",
    keywords: ["電池"],
    intervalKm: 10000,
  },
  {
    key: "brake_pad",
    label: "煞車皮",
    matchType: "keyword",
    keywords: ["煞車皮"],
    intervalKm: 5000,
  },
];

// 依日期新到舊排序過的維修紀錄清單中，找出第一筆符合這條規則的紀錄。
// matchType === "tag"：比對 itemsDetail 裡每個品項的 maintenanceType 欄位（精準標記）。
// matchType === "keyword"：在品項名稱文字裡找關鍵字（沿用原本的關鍵字比對方式）。
function findLastMaintenance(repairsList, rule) {
  for (const r of repairsList) {
    const items = r.itemsDetail || [];

    if (rule.matchType === "tag") {
      if (items.some((it) => it.maintenanceType === rule.key)) {
        return r;
      }
      continue;
    }

    // 關鍵字模式：優先比對每個品項各自的名稱，沒有明細資料時退回舊格式的 items 文字
    const itemNames = items.map((it) => it.name || "");
    const combinedText = itemNames.length ? itemNames.join(" ") : r.items || "";
    if (rule.keywords.some((kw) => combinedText.includes(kw))) {
      return r;
    }
  }
  return null;
}

function formatDateOnly(dateLike) {
  if (!(dateLike instanceof Date) || isNaN(dateLike.getTime())) return "-";
  const pad = (n) => String(n).padStart(2, "0");
  return `${dateLike.getFullYear()}-${pad(dateLike.getMonth() + 1)}-${pad(
    dateLike.getDate()
  )}`;
}

// 判斷單一保養項目目前狀態：overdue（該換了）／soon（快到了）／ok（還可以）／
// info（沒有週期資料，僅顯示上次紀錄）／none（尚無任何紀錄，或缺少計算所需資訊）
function computeReminderStatus(rule, lastRecord, currentMileage) {
  if (!lastRecord) {
    return { status: "none", text: "尚無紀錄" };
  }

  // 以天數為週期
  if (rule.intervalDays) {
    const dateStr = (lastRecord.datetime || lastRecord.date || "").split(
      "T"
    )[0];
    const lastDate = new Date(dateStr);
    if (isNaN(lastDate.getTime())) {
      return { status: "none", text: "尚無紀錄" };
    }
    const diffDays = Math.floor(
      (Date.now() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
    );
    const remaining = rule.intervalDays - diffDays;
    const lastInfo = `上次：${formatDateOnly(lastDate)}`;
    if (remaining <= 0) {
      return {
        status: "overdue",
        text: `已超過建議週期 ${Math.abs(
          remaining
        )} 天，建議更換（${lastInfo}）`,
      };
    }
    if (remaining <= 30) {
      return {
        status: "soon",
        text: `還剩 ${remaining} 天即到期（${lastInfo}）`,
      };
    }
    return { status: "ok", text: `還剩約 ${remaining} 天（${lastInfo}）` };
  }

  // 以里程為週期（含固定週期與區間週期兩種）
  if (rule.intervalKm || rule.intervalKmMin) {
    if (currentMileage == null || isNaN(currentMileage)) {
      return {
        status: "none",
        text: `請先輸入本次里程（上次：${lastRecord.mileage} km）`,
      };
    }
    const lastMileage = Number(lastRecord.mileage) || 0;
    const diff = currentMileage - lastMileage;
    const intervalMin = rule.intervalKmMin || rule.intervalKm;
    const intervalMax = rule.intervalKmMax || rule.intervalKm;
    const lastInfo = `上次：${lastMileage} km`;

    if (diff >= intervalMax) {
      return {
        status: "overdue",
        text: `已行駛 ${diff} km，建議更換／保養（${lastInfo}）`,
      };
    }
    if (diff >= intervalMin) {
      return {
        status: "soon",
        text: `已行駛 ${diff} km，接近建議保養里程（${lastInfo}）`,
      };
    }
    const remainKm = intervalMin - diff;
    if (remainKm <= Math.max(intervalMin * 0.1, 100)) {
      return {
        status: "soon",
        text: `還可行駛約 ${remainKm} km（${lastInfo}）`,
      };
    }
    return { status: "ok", text: `還可行駛約 ${remainKm} km（${lastInfo}）` };
  }

  // 沒有設定週期（例如輪胎、車體、轉向系統、其他），僅顯示上次紀錄供參考
  const lastLabel =
    lastRecord.mileage != null
      ? `${lastRecord.mileage} km`
      : (lastRecord.datetime || lastRecord.date || "-").split("T")[0];
  return {
    status: "info",
    text: `上次紀錄：${lastLabel}（無固定週期，僅供參考）`,
  };
}

const REMINDER_STYLE = {
  overdue: {
    box: "bg-red-100 border-2 border-red-400 text-red-800",
  },
  soon: {
    box: "bg-yellow-100 border-2 border-yellow-400 text-yellow-800",
  },
  ok: {
    box: "bg-green-50 border-green-300 text-green-700",
  },
  info: {
    box: "bg-gray-50 border-gray-300 text-gray-600",
  },
  none: {
    box: "bg-gray-50 border-gray-200 text-gray-400",
  },
};

// 重新渲染「總金額」下方的保養提醒區塊。currentMileageRaw 是目前表單上
// 「本次里程」輸入框的字串值（可能是空字串）。
function renderMaintenanceReminders(currentMileageRaw) {
  const panel = document.getElementById("maintenance_reminder_panel");
  if (!panel) return;

  const cached = currentRecordKey ? recordCache.get(currentRecordKey) : null;
  const repairsObj = (cached && cached.repairs) || {};
  const repairsList = Object.values(repairsObj).sort((a, b) =>
    (b.datetime || b.date || "").localeCompare(a.datetime || a.date || "")
  );

  // 「本次里程」欄位一開始是空的，但保養提醒不應該等使用者先打字才跳出來——
  // 沒填之前，先用這台車最後一次已知的里程（上次里程）來判斷，這樣一開啟
  // 紀錄就能立刻看到已經逾期的項目；等使用者實際輸入本次里程後，就會改用
  // 那個更準確的數字重新計算。
  const currentMileage =
    currentMileageRaw === "" || currentMileageRaw == null
      ? Number.isFinite(lastMileageValue)
        ? lastMileageValue
        : null
      : Number(currentMileageRaw);

  const rows = MAINTENANCE_RULES.map((rule) => {
    const lastRecord = findLastMaintenance(repairsList, rule);
    const statusObj = computeReminderStatus(rule, lastRecord, currentMileage);
    return { rule, statusObj };
  }).filter(
    ({ statusObj }) =>
      statusObj.status === "overdue" || statusObj.status === "soon"
  );

  // 沒有任何項目達到「快到了／已逾期」的門檻，就整塊隱藏，不佔畫面空間；
  // 有才跳出來提醒，逾期用紅底、快到了用黃底，一眼就能分辨輕重緩急。
  if (rows.length === 0) {
    panel.innerHTML = "";
    return;
  }

  panel.innerHTML = `
    <div class="border-t border-gray-200 pt-4">
      <h3 class="text-sm font-bold text-gray-500 mb-3">
        保養提醒（依歷史維修紀錄的品項分類與本次里程自動判斷，僅供參考）
      </h3>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
        ${rows
          .map(({ rule, statusObj }) => {
            const style = REMINDER_STYLE[statusObj.status];
            return `
          <div class="flex items-start gap-2 border rounded-lg px-3 py-2 ${style.box}">
            <div class="flex-1 min-w-0">
              <div class="font-bold text-sm">${rule.label}</div>
              <div class="text-xs">${statusObj.text}</div>
            </div>
          </div>`;
          })
          .join("")}
      </div>
    </div>
  `;
}

function renderRepairPanel() {
  repairRowSeq = 0;
  repairNotesValue = ""; // 每次開新的一筆維修紀錄，備註內容重置
  pendingRepairEditKey = null; // 每次重新渲染都先當作全新輸入，補登模式由 prefillRepairFormForPendingMileage() 另外設定
  editingHistoryRepairId = null; // 同上，編輯歷史紀錄模式由 loadHistoryRecordToRepairTab() 另外設定
  loadedEstimateSourceId = null; // 同上，從估價帶入的模式由 loadEstimateIntoForm() 另外設定

  // 重置分頁按鈕文字（如果上一筆是用「載入維修資料」看歷史紀錄，文字會被改成
  // 「維修資料(歷史紀錄)」，這裡先還原成預設，避免混淆）
  const repairTabBtn = document.querySelector(
    '.detail_tab_btn[data-tab="repair"]'
  );
  if (repairTabBtn) repairTabBtn.textContent = "維修資料";
  document.getElementById("panel_repair").innerHTML = `
    <div class="flex items-center justify-between mb-6">
      <h2 class="text-xl font-bold text-gray-700">新增維修紀錄</h2>
      <div class="flex items-center gap-2">
        <span id="daily_customer_code_label" class="text-xs text-gray-500 font-mono tracking-wide"></span>
        <button id="repair_notes_btn" type="button" onclick="openNotesModal()"
          class="bg-gray-100 text-gray-600 px-3 py-1.5 text-sm font-bold rounded-full border border-gray-300 hover:bg-gray-200 shadow-sm transition">
          備註
        </button>
      </div>
    </div>

    <div class="grid grid-cols-3 gap-6 mb-6">
      <div class="flex flex-col">
        <label class="text-sm text-gray-400 font-bold mb-1">日期</label>
        <input id="repair_date" type="date" value="${todayStr()}"
          class="border border-gray-300 rounded px-3 py-3 text-lg" />
      </div>
      <div class="flex flex-col">
        <label class="text-sm text-gray-400 font-bold mb-1">時間（24 小時制）</label>
        <input id="repair_time" type="time" lang="en-GB" step="60" value="${nowTimeStr()}"
          class="border border-gray-300 rounded px-3 py-3 text-lg" />
      </div>
      <div class="flex flex-col">
        <label class="text-sm text-gray-400 font-bold mb-1">技師 <span class="text-red-500">*</span></label>
        <select id="repair_mechanic_select" onchange="onMechanicSelectChange()"
          class="border border-gray-300 rounded px-3 py-3 text-lg bg-white">
          <option value="" disabled selected>請選擇技師</option>
          <option value="阿翰">阿翰</option>
          <option value="明松">明松</option>
          <option value="__custom__">自行輸入...</option>
        </select>
        <input id="repair_mechanic_custom" type="text" placeholder="輸入技師姓名（可用鍵盤打字）"
          class="hidden border border-gray-300 rounded px-3 py-3 text-lg mt-2" />
      </div>
    </div>

    <div class="grid grid-cols-3 gap-6 mb-8">
      <div class="flex flex-col">
        <label class="text-sm text-gray-400 font-bold mb-1">上次里程 (km)</label>
        <input id="repair_last_mileage" type="text" readonly value="${lastMileageValue}"
          class="border border-gray-300 rounded px-3 py-3 text-lg bg-gray-50 text-gray-500" />
      </div>
      <div class="flex flex-col">
        <label class="text-sm text-gray-400 font-bold mb-1">本次里程 (km)</label>
        <input id="repair_mileage" type="number" min="0" placeholder="例如 12500" oninput="updateDistanceDisplay()"
          class="border border-gray-300 rounded px-3 py-3 text-lg" />
      </div>
      <div class="flex flex-col">
        <label class="text-sm text-gray-400 font-bold mb-1">行駛里程 (km)</label>
        <input id="repair_distance" type="text" readonly value="-"
          class="border border-gray-300 rounded px-3 py-3 text-lg bg-gray-50 text-gray-500" />
      </div>
    </div>

    <div class="flex items-center justify-between mb-2">
      <span class="text-sm text-gray-400 font-bold">維修項目</span>
      <button type="button" onclick="openItemPicker()"
        class="bg-blue-600 text-white px-5 py-2 text-sm font-bold rounded-full hover:bg-blue-500 active:bg-blue-700 shadow-sm hover:shadow transition">
        點選輸入項目
      </button>
    </div>

    <table class="w-full text-left border-collapse mb-2">
      <thead>
        <tr class="border-b-2 border-gray-200 text-gray-500 text-sm">
          <th class="py-2 pr-2">品項</th>
          <th class="py-2 pr-2 w-28">分類</th>
          <th class="py-2 pr-2 w-32">保養項目</th>
          <th class="py-2 pr-2 w-24">數量</th>
          <th class="py-2 pr-2 w-28">單價</th>
          <th class="py-2 pr-2 w-28 text-right">小計</th>
          <th class="py-2 pl-2 w-10"></th>
        </tr>
      </thead>
      <tbody id="repair_items_body"></tbody>
    </table>

    <div class="flex gap-4 mb-6">
      <button onclick="addRepairItemRow()"
        class="bg-blue-50 text-blue-700 border border-blue-200 font-bold px-4 py-2 rounded hover:bg-blue-100 shadow-sm transition">手動新增項目</button>
    </div>

    <div class="flex justify-between items-center mb-6 text-lg">
      <div class="flex gap-2">
        <button id="repair_generate_estimate_btn" type="button" onclick="generateEstimateFromCurrentForm()"
          class="bg-white text-teal-700 border-2 border-teal-600 px-4 py-2.5 text-sm font-bold rounded hover:bg-teal-50 shadow-sm transition">
          產生估價單
        </button>
        <button id="repair_load_estimate_btn" type="button" onclick="openLoadEstimateModal()"
          class="hidden bg-white text-purple-700 border-2 border-purple-600 px-4 py-2.5 text-sm font-bold rounded hover:bg-purple-50 shadow-sm transition">
          載入估價
        </button>
      </div>
      <div class="flex items-center">
        <span class="text-gray-500 font-bold mr-2">總金額：</span>
        <span id="repair_total" class="text-2xl font-bold text-gray-800">$0</span>
      </div>
    </div>

    <div id="maintenance_reminder_panel" class="mb-6"></div>

    <div class="flex gap-3">
      <button id="repair_save_btn" onclick="saveRepairRecord(false)"
        style="background-color: #0f766e; color: #ffffff"
        class="px-6 py-4 text-lg font-bold rounded hover:opacity-90 shadow transition flex-1">
        儲存維修資料
      </button>
      <button id="repair_save_pending_btn" type="button" onclick="saveRepairRecord(true)"
        title="本次里程數還不知道，先存其他資料，稍後在搜尋畫面點提醒補登"
        class="bg-orange-100 text-orange-700 border-2 border-orange-300 px-4 py-4 text-base font-bold rounded hover:bg-orange-200 shadow transition flex-shrink-0">
        里程晚點補登
      </button>
      <button id="repair_save_estimate_btn" type="button" onclick="saveEstimateRecord()"
        title="把目前打好的品項存成估價，留底在伺服器上，不會出現在歷史維修紀錄"
        class="bg-purple-100 text-purple-700 border-2 border-purple-300 px-4 py-4 text-base font-bold rounded hover:bg-purple-200 shadow transition flex-shrink-0">
        儲存估價
      </button>
    </div>
  `;
  updateNotesButtonLabel();
  updateDailyCustomerCodeLabel();
  renderMaintenanceReminders(
    document.getElementById("repair_mileage")?.value ?? ""
  );
  window.updateLoadEstimateButtonVisibility();
}

// 備註按鈕的樣式跟著有沒有內容變化，讓使用者一眼看出這筆有沒有填備註
function updateNotesButtonLabel() {
  const btn = document.getElementById("repair_notes_btn");
  if (!btn) return;
  const hasNotes = repairNotesValue.trim().length > 0;
  btn.textContent = hasNotes ? "備註 ✓" : "備註";
  btn.classList.toggle("bg-yellow-100", hasNotes);
  btn.classList.toggle("border-yellow-400", hasNotes);
  btn.classList.toggle("text-yellow-800", hasNotes);
  btn.classList.toggle("bg-gray-100", !hasNotes);
  btn.classList.toggle("border-gray-300", !hasNotes);
  btn.classList.toggle("text-gray-600", !hasNotes);
}

// 點小小的「📝 備註」按鈕：開啟全螢幕備註輸入畫面
window.openNotesModal = function () {
  const modal = document.getElementById("repair_notes_modal");
  const textarea = document.getElementById("repair_notes_fullscreen");
  textarea.value = repairNotesValue;
  modal.classList.remove("hidden");
  modal.classList.add("flex");
  setTimeout(() => textarea.focus(), 0);
};

// 關閉全螢幕備註畫面。save 為 true（按「確認」）才會把內容存回去，
// 按「取消」則捨棄這次編輯，保留原本的備註內容。
window.closeNotesModal = function (save) {
  const modal = document.getElementById("repair_notes_modal");
  if (save) {
    repairNotesValue = document
      .getElementById("repair_notes_fullscreen")
      .value.trim();
    updateNotesButtonLabel();
  }
  modal.classList.add("hidden");
  modal.classList.remove("flex");
};

// 行駛里程 = 本次里程 - 上次里程，即時計算顯示；負值時標紅提醒（存檔時仍會被攔截）。
window.updateDistanceDisplay = function () {
  const mileageInput = document.getElementById("repair_mileage");
  const distanceEl = document.getElementById("repair_distance");
  if (!mileageInput || !distanceEl) return;

  // 里程數不能是負的：打到「-」或貼上負數的當下就直接擋掉，不等存檔才發現。
  if (mileageInput.value !== "" && Number(mileageInput.value) < 0) {
    mileageInput.value = "0";
  }

  if (mileageInput.value === "") {
    distanceEl.value = "-";
    distanceEl.classList.remove("text-red-600");
    distanceEl.classList.add("text-gray-500");
    renderMaintenanceReminders("");
    return;
  }

  const diff = Number(mileageInput.value) - lastMileageValue;
  distanceEl.value = diff;
  distanceEl.classList.toggle("text-red-600", diff < 0);
  distanceEl.classList.toggle("text-gray-500", diff >= 0);

  renderMaintenanceReminders(mileageInput.value);
};

// 技師下拉選單：選「自行輸入...」才會跳出文字框，讓實體鍵盤可以直接打字。
window.onMechanicSelectChange = function () {
  const select = document.getElementById("repair_mechanic_select");
  const customInput = document.getElementById("repair_mechanic_custom");
  if (select.value === "__custom__") {
    customInput.classList.remove("hidden");
    customInput.focus();
  } else {
    customInput.classList.add("hidden");
  }
};

function getMechanicName() {
  const select = document.getElementById("repair_mechanic_select");
  if (select.value === "__custom__") {
    return document.getElementById("repair_mechanic_custom").value.trim();
  }
  return select.value;
}

// 「儲存項目」：把目前這一列品項鎖起來（防止手滑再被改動）。
// 這只是把項目列確認進清單，真正寫入 Firebase 仍是按「儲存維修資料」才會發生。
// 若要再新增下一筆，請按「+ 手動新增項目」或「點選輸入項目」。
window.saveItemRow = function () {
  const rows = document.querySelectorAll("#repair_items_body tr");
  if (rows.length === 0) return;
  const lastRow = rows[rows.length - 1];
  const nameInput = lastRow.querySelector(".repair_item_name");

  if (!nameInput.value.trim()) {
    showAppAlert("請先輸入品項名稱再儲存！");
    nameInput.focus();
    return;
  }

  if (!lastRow.classList.contains("opacity-70")) {
    [".repair_item_name", ".repair_item_qty", ".repair_item_price"].forEach(
      (cls) => {
        lastRow.querySelector(cls).readOnly = true;
      }
    );
    lastRow.classList.add("bg-green-50", "opacity-70");
  }

  recalcRepairTotal();
};

// 手動新增項目的預設分類（沒特別選就先當「其他」，方便快速輸入，
// 但這樣會讓保養提醒歸類到「其他」，建議還是實際選一下正確分類）
const DEFAULT_MANUAL_ITEM_CATEGORY = "其他";
const DEFAULT_MAINTENANCE_TYPE = "none"; // 預設「不追蹤」，不計入任何保養提醒

// 依「分類」名稱自動推算對應的「保養項目」標籤：分類文字剛好跟某個保養項目
// 的名稱一樣（目前只有「輪胎」符合），就自動帶入該項目；其餘分類（例如「油品」
// 涵蓋機油與齒輪油兩種，無法判斷是哪一種）就維持「不追蹤」，讓使用者自己選。
function deriveMaintenanceTypeFromCategory(category) {
  const match = MAINTENANCE_TYPES.find((t) => t.label === category);
  return match ? match.key : DEFAULT_MAINTENANCE_TYPE;
}

// 產生「保養項目」下拉選單的 HTML，手動新增／預填列共用同一份選項。
// 這個標籤跟「分類」是分開的兩件事，只用來讓保養提醒能精準比對，不套用分類選單的分類。
function buildMaintenanceTypeSelect(selectedKey) {
  const resolved = selectedKey || DEFAULT_MAINTENANCE_TYPE;
  return `
    <select class="repair_item_maintenance border border-gray-300 rounded px-2 py-1.5 w-full text-sm bg-white"
      onchange="this.closest('tr').dataset.maintenanceType = this.value">
      ${MAINTENANCE_TYPES.map(
        (t) =>
          `<option value="${t.key}" ${t.key === resolved ? "selected" : ""}>${
            t.label
          }</option>`
      ).join("")}
    </select>
  `;
}

// 手動新增項目列的「分類」改變時呼叫：如果新分類剛好對應到某個保養項目
// （目前只有「輪胎」），就自動幫「保養項目」下拉選單也切過去，省得重選一次；
// 使用者事後仍可以自己手動改回其他選項，不會被強制鎖住。
window.syncMaintenanceSelectFromCategory = function (categorySelectEl) {
  const row = categorySelectEl.closest("tr");
  if (!row) return;
  row.dataset.category = categorySelectEl.value;

  const maintSelect = row.querySelector(".repair_item_maintenance");
  if (!maintSelect) return; // 鎖定列沒有這個下拉選單，不需要同步

  const derived = deriveMaintenanceTypeFromCategory(categorySelectEl.value);
  maintSelect.value = derived;
  row.dataset.maintenanceType = derived;
};

window.addRepairItemRow = function () {
  repairRowSeq += 1;
  const rowId = `r${repairRowSeq}`;
  const tbody = document.getElementById("repair_items_body");
  const row = document.createElement("tr");
  row.id = `row_${rowId}`;
  row.className = "border-b border-gray-100";
  row.dataset.category = DEFAULT_MANUAL_ITEM_CATEGORY;
  row.dataset.maintenanceType = deriveMaintenanceTypeFromCategory(
    DEFAULT_MANUAL_ITEM_CATEGORY
  );
  row.innerHTML = `
    <td class="py-1 pr-2">
      <input type="text" placeholder="例如：機油、皮帶"
        class="repair_item_name border border-gray-300 rounded px-2 py-1.5 w-full" />
    </td>
    <td class="py-1 pr-2">
      <select class="repair_item_category border border-gray-300 rounded px-2 py-1.5 w-full text-sm bg-white"
        onchange="syncMaintenanceSelectFromCategory(this)">
        ${ITEM_CATEGORIES.map(
          (c) =>
            `<option value="${c}" ${
              c === DEFAULT_MANUAL_ITEM_CATEGORY ? "selected" : ""
            }>${c}</option>`
        ).join("")}
      </select>
    </td>
    <td class="py-1 pr-2">${buildMaintenanceTypeSelect(
      row.dataset.maintenanceType
    )}</td>
    <td class="py-1 pr-2">
      <input type="number" value="1" min="0"
        class="repair_item_qty border border-gray-300 rounded px-2 py-1.5 w-full"
        oninput="recalcRepairTotal()" />
    </td>
    <td class="py-1 pr-2">
      <input type="number" value="0" min="0"
        class="repair_item_price border border-gray-300 rounded px-2 py-1.5 w-full"
        oninput="recalcRepairTotal()" />
    </td>
    <td class="py-1 pr-2 text-right repair_item_subtotal font-bold text-gray-700">$0</td>
    <td class="py-1 pl-2 text-center">
      <button onclick="removeRepairItemRow('${rowId}')"
        class="text-red-500 hover:text-red-700 font-bold">✕</button>
    </td>
  `;
  tbody.appendChild(row);
  recalcRepairTotal();
};

window.removeRepairItemRow = function (rowId) {
  const row = document.getElementById(`row_${rowId}`);
  if (row) row.remove();
  recalcRepairTotal();
};

window.recalcRepairTotal = function () {
  let total = 0;
  document.querySelectorAll("#repair_items_body tr").forEach((row) => {
    const qty = parseFloat(row.querySelector(".repair_item_qty").value) || 0;
    const price =
      parseFloat(row.querySelector(".repair_item_price").value) || 0;
    const subtotal = qty * price;
    row.querySelector(".repair_item_subtotal").textContent = `$${subtotal}`;
    total += subtotal;
  });
  const totalEl = document.getElementById("repair_total");
  if (totalEl) totalEl.textContent = `$${total}`;
};

// -----------------------------------------------------------------
// 📄「產生估價單」（用目前正在輸入、還沒存檔的維修項目）
//
// 把「維修資料」表單上目前打好的品項、跟這台車已經讀到的顧客資料
// （姓名／電話）、車牌、里程一起整理成一包物件，交給 main.js 那邊
// 用 docx 套件套範本產生真正的 Word 檔，讓使用者選存檔位置。
// 這裡完全不會呼叫 Firebase，純粹只是把畫面上、記憶體裡已經有的資料
// 讀出來而已，不會存檔也不會影響原本「儲存維修資料」的流程。
// -----------------------------------------------------------------
window.generateEstimateFromCurrentForm = async function () {
  if (!currentRecordKey) {
    showAppAlert("請先搜尋並開啟一筆車牌 / 卡號資料，才能產生估價單！");
    return;
  }
  if (!window.electronAPI || !window.electronAPI.generateEstimateDocx) {
    showAppAlert("這個版本的程式還沒有「產生估價單」功能，請先更新到最新版本。");
    return;
  }

  const items = [];
  document.querySelectorAll("#repair_items_body tr").forEach((row) => {
    const name = row.querySelector(".repair_item_name")?.value?.trim() || "";
    const qty = parseFloat(row.querySelector(".repair_item_qty")?.value) || 0;
    const price =
      parseFloat(row.querySelector(".repair_item_price")?.value) || 0;
    if (!name && qty === 0 && price === 0) return; // 整列都空的就不列進估價單
    items.push({ name, amount: qty * price });
  });

  const cached = recordCache.get(currentRecordKey) || {};
  const customer = cached.customer || {};
  const plateLabel =
    document.getElementById("detail_query_label")?.textContent?.trim() ||
    currentRecordKey;
  const entryDate = document.getElementById("repair_date")?.value || todayStr();
  const mileage = document.getElementById("repair_mileage")?.value || "";

  window.openEstimateChoiceModal(
    {
      entryDate,
      quoteDate: todayStr(),
      customerName: customer.name || "",
      phone: customer.phone || "",
      plate: plateLabel,
      mileage,
      notes: repairNotesValue || "",
      items,
    },
    "repair_generate_estimate_btn",
    "產生估價單"
  );
};

// -----------------------------------------------------------------
// 📄「產生估價單」選擇視窗：按下「產生估價單」按鈕後，先跳出這個小視窗
// 讓使用者選要輸出 Word、PDF，還是直接叫出系統列印視窗，而不是直接產生
// Word 檔。三個入口（目前表單／歷史紀錄）都共用這一組函式。
// -----------------------------------------------------------------
let pendingEstimatePayload = null;
let pendingEstimateBtnId = null;
let pendingEstimateBtnLabel = null;

window.openEstimateChoiceModal = function (payload, btnId, btnDefaultLabel) {
  pendingEstimatePayload = payload;
  pendingEstimateBtnId = btnId || null;
  pendingEstimateBtnLabel = btnDefaultLabel || "產生估價單";
  const modal = document.getElementById("estimate_choice_modal");
  if (!modal) return;
  modal.classList.remove("hidden");
  modal.classList.add("flex");
};

window.closeEstimateChoiceModal = function () {
  const modal = document.getElementById("estimate_choice_modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
  pendingEstimatePayload = null;
  pendingEstimateBtnId = null;
  pendingEstimateBtnLabel = null;
};

window.chooseEstimateFormat = async function (format) {
  const payload = pendingEstimatePayload;
  const btnId = pendingEstimateBtnId;
  const btnDefaultLabel = pendingEstimateBtnLabel;
  window.closeEstimateChoiceModal();
  if (!payload) return;
  await runGenerateEstimate(payload, btnId, btnDefaultLabel, format);
};

// 共用的「呼叫 main.js 產生估價單」流程，三個入口（目前表單／歷史紀錄／
// 格式選擇視窗）都會用到，集中處理按鈕的 loading 狀態跟錯誤訊息，
// 避免每種格式各寫一份幾乎一樣的程式碼。
async function runGenerateEstimate(payload, btnId, btnDefaultLabel, format = "word") {
  const btn = btnId ? document.getElementById(btnId) : null;
  const loadingLabel = format === "print" ? "列印中..." : "產生中...";
  if (btn) {
    btn.disabled = true;
    btn.textContent = loadingLabel;
  }
  try {
    let result;
    if (format === "pdf") {
      result = await window.electronAPI.generateEstimatePdf(payload);
    } else if (format === "print") {
      result = await window.electronAPI.printEstimate(payload);
    } else {
      result = await window.electronAPI.generateEstimateDocx(payload);
    }
    if (result && result.ok) {
      if (result.truncated) {
        showAppAlert(
          "項目超過 30 筆，估價單只列出前 30 筆，其餘請自行手寫補充！"
        );
      }
    } else if (result && !result.canceled) {
      const verb = format === "print" ? "列印估價單失敗" : "產生估價單失敗";
      showAppAlert(`${verb}：${result.error || "未知錯誤"}`);
    }
  } catch (err) {
    console.error("產生估價單失敗：", err);
    showAppAlert(`產生估價單失敗：${err.message || err}`);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = btnDefaultLabel;
    }
  }
}

// 加入一列「已鎖定」的品項列（來自分類選單挑選的項目），
// 樣式與手動輸入後按「儲存項目」鎖定的列一致，品項名稱／數量不能誤觸修改；
// 「單價」開放直接點進去修改，方便加入後才發現這次價錢不一樣時現場調整。
// 分類是選購當下就已經確定的（來自哪個分類選單就是哪個分類），所以用文字顯示、不能再改；
// 「保養項目」不顯示下拉選單（只有手動新增的項目才需要選），改成依分類自動推算
// （目前只有分類「輪胎」會自動被標記為保養提醒的「輪胎」項目，其餘一律不追蹤）。
function addLockedRepairItemRow(name, qty, price, category) {
  repairRowSeq += 1;
  const rowId = `r${repairRowSeq}`;
  const tbody = document.getElementById("repair_items_body");
  if (!tbody) return;
  const resolvedCategory = category || DEFAULT_MANUAL_ITEM_CATEGORY;
  const derivedMaintenanceType =
    deriveMaintenanceTypeFromCategory(resolvedCategory);
  const trackedLabel =
    MAINTENANCE_TYPES.find((t) => t.key === derivedMaintenanceType)?.label ||
    "";
  const row = document.createElement("tr");
  row.id = `row_${rowId}`;
  row.className = "border-b border-gray-100 bg-green-50 opacity-70";
  row.dataset.category = resolvedCategory;
  row.dataset.maintenanceType = derivedMaintenanceType;
  row.innerHTML = `
    <td class="py-1 pr-2">
      <input type="text" value="${name}" readonly
        class="repair_item_name border border-gray-300 rounded px-2 py-1.5 w-full" />
    </td>
    <td class="py-1 pr-2">
      <span class="inline-block bg-teal-100 text-teal-800 text-xs font-bold px-2 py-1.5 rounded border border-teal-300">${resolvedCategory}</span>
    </td>
    <td class="py-1 pr-2 text-xs text-gray-400">${
      derivedMaintenanceType !== DEFAULT_MAINTENANCE_TYPE
        ? `<span class="text-teal-700 font-bold">${trackedLabel}</span>`
        : "-"
    }</td>
    <td class="py-1 pr-2">
      <input type="number" value="${qty}" min="0" readonly
        class="repair_item_qty border border-gray-300 rounded px-2 py-1.5 w-full" />
    </td>
    <td class="py-1 pr-2">
      <input type="number" value="${price}" min="0"
        oninput="recalcRepairTotal()"
        class="repair_item_price border-2 border-gray-300 rounded px-2 py-1.5 w-full bg-white focus:border-blue-500 focus:outline-none" />
    </td>
    <td class="py-1 pr-2 text-right repair_item_subtotal font-bold text-gray-700">$${
      qty * price
    }</td>
    <td class="py-1 pl-2 text-center">
      <button onclick="removeRepairItemRow('${rowId}')"
        class="text-red-500 hover:text-red-700 font-bold">✕</button>
    </td>
  `;
  tbody.appendChild(row);
}

// 加入一列「可編輯」的品項列，並直接帶入初始值——用於把補登里程時／載入歷史紀錄時
// 既有紀錄的品項帶回表單，讓使用者在填里程之前仍可視需要微調數量/單價/分類/保養項目，
// 跟手動輸入的列一樣可編輯（分類也可以改，避免舊資料分類不準確）。
function addPrefillRepairItemRow(name, qty, price, category, maintenanceType) {
  repairRowSeq += 1;
  const rowId = `r${repairRowSeq}`;
  const tbody = document.getElementById("repair_items_body");
  if (!tbody) return;
  const resolvedCategory = category || DEFAULT_MANUAL_ITEM_CATEGORY;
  const row = document.createElement("tr");
  row.id = `row_${rowId}`;
  row.className = "border-b border-gray-100";
  row.dataset.category = resolvedCategory;
  row.dataset.maintenanceType = maintenanceType || DEFAULT_MAINTENANCE_TYPE;
  row.innerHTML = `
    <td class="py-1 pr-2">
      <input type="text" value="${escapeAttr(name)}"
        class="repair_item_name border border-gray-300 rounded px-2 py-1.5 w-full" />
    </td>
    <td class="py-1 pr-2">
      <select class="repair_item_category border border-gray-300 rounded px-2 py-1.5 w-full text-sm bg-white"
        onchange="this.closest('tr').dataset.category = this.value">
        ${ITEM_CATEGORIES.map(
          (c) =>
            `<option value="${c}" ${
              c === resolvedCategory ? "selected" : ""
            }>${c}</option>`
        ).join("")}
      </select>
    </td>
    <td class="py-1 pr-2">${buildMaintenanceTypeSelect(maintenanceType)}</td>
    <td class="py-1 pr-2">
      <input type="number" value="${qty}" min="0"
        class="repair_item_qty border border-gray-300 rounded px-2 py-1.5 w-full"
        oninput="recalcRepairTotal()" />
    </td>
    <td class="py-1 pr-2">
      <input type="number" value="${price}" min="0"
        class="repair_item_price border border-gray-300 rounded px-2 py-1.5 w-full"
        oninput="recalcRepairTotal()" />
    </td>
    <td class="py-1 pr-2 text-right repair_item_subtotal font-bold text-gray-700">$${
      qty * price
    }</td>
    <td class="py-1 pl-2 text-center">
      <button onclick="removeRepairItemRow('${rowId}')"
        class="text-red-500 hover:text-red-700 font-bold">✕</button>
    </td>
  `;
  tbody.appendChild(row);
}

// -----------------------------------------------------------------
// ⏳ 補登里程：點擊搜尋畫面的「待補里程」標籤後，把該台車那一筆缺里程的
// 既有紀錄（項目／技師／備註等）整個帶回「維修資料」表單，讓使用者只需要
// 專心填本次里程再存檔即可——存檔時是「更新」這筆既有紀錄，而不是又產生
// 一筆新的維修紀錄。
// -----------------------------------------------------------------

function prefillRepairFormForPendingMileage(repairId, repairData) {
  pendingRepairEditKey = repairId;
  loadedEstimateSourceId = null; // 兩種模式互斥，確保不是從估價帶入的模式

  // 日期時間帶回原本填的
  const [datePart, timePart] = (repairData.datetime || "").split("T");
  const dateInput = document.getElementById("repair_date");
  const timeInput = document.getElementById("repair_time");
  if (dateInput && datePart) dateInput.value = datePart;
  if (timeInput && timePart) timeInput.value = timePart;

  // 技師帶回原本選的（不在下拉選單裡的名字就切到「自行輸入」）
  const mechanicSelect = document.getElementById("repair_mechanic_select");
  const customInput = document.getElementById("repair_mechanic_custom");
  const knownMechanics = ["阿翰", "明松"];
  if (mechanicSelect && repairData.mechanic) {
    if (knownMechanics.includes(repairData.mechanic)) {
      mechanicSelect.value = repairData.mechanic;
      if (customInput) customInput.classList.add("hidden");
    } else {
      mechanicSelect.value = "__custom__";
      if (customInput) {
        customInput.classList.remove("hidden");
        customInput.value = repairData.mechanic;
      }
    }
  }

  // 備註帶回原本填的
  repairNotesValue = repairData.notes || "";
  updateNotesButtonLabel();

  // 品項整批帶回（可編輯，方便使用者順便核對／微調，含分類）
  const tbody = document.getElementById("repair_items_body");
  if (tbody) tbody.innerHTML = "";
  repairRowSeq = 0;
  (repairData.itemsDetail || []).forEach((it) => {
    addPrefillRepairItemRow(
      it.name,
      it.qty,
      it.price,
      it.category,
      it.maintenanceType
    );
  });
  recalcRepairTotal();

  // 畫面提示：現在是「補登里程」模式
  const heading = document.querySelector("#panel_repair h2");
  if (heading) heading.textContent = "補登里程（其餘資料已帶回原紀錄）";

  // 補登模式不需要再顯示「里程晚點補登」按鈕，避免又存成第二筆缺里程的紀錄
  const pendingBtn = document.getElementById("repair_save_pending_btn");
  if (pendingBtn) pendingBtn.classList.add("hidden");

  const saveBtn = document.getElementById("repair_save_btn");
  if (saveBtn) saveBtn.textContent = "儲存本次里程";

  const mileageInput = document.getElementById("repair_mileage");
  if (mileageInput) mileageInput.focus();
}

// skipMileage = true 時（「⏳ 里程晚點補登」按鈕），允許本次里程留空先儲存其他資料，
// 這筆會被標記 mileageMissing，並同步寫入全店共用的 pendingMileage 清單，
// 之後任何裝置都會在搜尋畫面看到提醒，點一下就能直接載入回來補登。
window.saveRepairRecord = async function (skipMileage = false) {
  if (!currentRecordKey) return false;

  const items = [];
  document.querySelectorAll("#repair_items_body tr").forEach((row) => {
    const name = row.querySelector(".repair_item_name").value.trim();
    const qty = parseFloat(row.querySelector(".repair_item_qty").value) || 0;
    const price =
      parseFloat(row.querySelector(".repair_item_price").value) || 0;
    const category = row.dataset.category || DEFAULT_MANUAL_ITEM_CATEGORY;
    const maintenanceType =
      row.dataset.maintenanceType || DEFAULT_MAINTENANCE_TYPE;
    if (name) {
      items.push({
        name,
        qty,
        price,
        subtotal: qty * price,
        category,
        maintenanceType,
      });
    }
  });

  if (items.length === 0) {
    showAppAlert("請至少輸入一項維修品項！");
    return false;
  }

  const dateVal = document.getElementById("repair_date").value || todayStr();
  const timeVal = document.getElementById("repair_time").value || nowTimeStr();
  const datetime = `${dateVal}T${timeVal}`;
  const mileageRaw = document.getElementById("repair_mileage").value;
  const mechanic = getMechanicName();
  const notes = repairNotesValue.trim();
  const cost = items.reduce((sum, it) => sum + it.subtotal, 0);

  if (!mechanic) {
    showAppAlert("請選擇技師，才能儲存維修資料！");
    document.getElementById("repair_mechanic_select").focus();
    return false;
  }

  // -----------------------------------------------------------------
  // ⏳ 補登里程模式：目前是從「待補里程」標籤點進來的，此時不是新增一筆
  // 紀錄，而是把既有那筆缺里程的紀錄「更新」成有里程的完整紀錄。
  // -----------------------------------------------------------------
  if (pendingRepairEditKey) {
    const mileageRaw = document.getElementById("repair_mileage").value;

    if (mileageRaw === "") {
      showAppAlert("請輸入本次里程數，才能完成補登！");
      return false;
    }

    const mileage = Number(mileageRaw);
    if (isNaN(mileage)) {
      showAppAlert("請輸入正確的里程數字！");
      return false;
    }
    if (mileage < 0) {
      showAppAlert("里程數不能是負的！");
      return false;
    }
    if (mileage - lastMileageValue < 0) {
      // 里程數比上次小：先提醒一次，使用者按「確定」才繼續存檔，按「取消」就中止這次補登
      const confirmed = await showAppConfirm(
        `提醒：本次里程數 (${mileage} km) 小於上次里程數 (${lastMileageValue} km)，請確認是否正確？\n按「確定」才會存檔。`
      );
      if (!confirmed) return false;
    }

    const key = currentRecordKey;
    const repairId = pendingRepairEditKey;
    const updatedRecord = {
      datetime,
      items: items.map((it) => `${it.name} x${it.qty}`).join("、"),
      itemsDetail: items,
      mileage,
      mileageMissing: false,
      mechanic,
      cost,
      notes,
    };

    const saveBtn = document.getElementById("repair_save_btn");
    const pendingBtn = document.getElementById("repair_save_pending_btn");
    if (saveBtn) {
      saveBtn.disabled = true;
      saveBtn.textContent = "儲存中...";
    }
    if (pendingBtn) pendingBtn.disabled = true;

    try {
      await update(
        ref(db, "records/" + key + "/repairs/" + repairId),
        updatedRecord
      );
      await remove(ref(db, "pendingMileage/" + key));

      const cached = recordCache.get(key) || {};
      cached.repairs = cached.repairs || {};
      cached.repairs[repairId] = updatedRecord;
      recordCache.set(key, cached);
      renderHistoryPanel(cached);

      lastMileageValue = mileage;
      pendingRepairEditKey = null;
      await commitDailyCustomerCode();
      await deleteLoadedEstimateSourceIfAny(key);

      showAppAlert("里程已補登完成！");
      window.closeDetailPage();
      return true;
    } catch (err) {
      console.error("補登里程失敗：", err);
      showAppAlert(`補登失敗：${err.code || err.message || "未知錯誤"}`);
      return false;
    } finally {
      if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.textContent = "儲存維修資料";
      }
      if (pendingBtn) pendingBtn.disabled = false;
    }
  }

  let mileage = null;

  if (mileageRaw === "") {
    // 「里程晚點補登」允許先留空；一般儲存則必須填寫
    if (!skipMileage) {
      showAppAlert("請輸入本次里程數！");
      return false;
    }
  } else {
    mileage = Number(mileageRaw);

    if (isNaN(mileage)) {
      showAppAlert("請輸入正確的里程數字！");
      return false;
    }

    if (mileage < 0) {
      showAppAlert("里程數不能是負的！");
      return false;
    }

    // 本次里程數比上次小：先提醒一次，使用者按「確定」才繼續存檔，按「取消」就中止這次存檔
    if (mileage - lastMileageValue < 0) {
      const confirmed = await showAppConfirm(
        `提醒：本次里程數 (${mileage} km) 小於上次里程數 (${lastMileageValue} km)，請確認是否正確？\n按「確定」才會存檔。`
      );
      if (!confirmed) return false;
    }
  }

  const mileageMissing = mileage === null;

  const record = {
    datetime,
    items: items.map((it) => `${it.name} x${it.qty}`).join("、"),
    itemsDetail: items,
    mileage,
    mileageMissing,
    mechanic,
    cost,
    notes,
  };

  const key = currentRecordKey;
  // 搜尋畫面顯示用的車牌／卡號文字（含橫線），供待補里程清單點擊回填用
  const queryLabel =
    document.getElementById("detail_query_label")?.textContent || key;

  const saveBtn = document.getElementById("repair_save_btn");
  const pendingBtn = document.getElementById("repair_save_pending_btn");
  saveBtn.disabled = true;
  if (pendingBtn) pendingBtn.disabled = true;
  const activeBtn = skipMileage ? pendingBtn : saveBtn;
  if (activeBtn) activeBtn.textContent = "儲存中...";

  // 存完之後同步待補里程清單：有填里程就清掉提醒，沒填就寫入/更新提醒
  async function syncPendingMileageMarker() {
    try {
      if (mileageMissing) {
        await set(ref(db, "pendingMileage/" + key), {
          query: queryLabel,
          savedAt: Date.now(),
        });
      } else {
        await remove(ref(db, "pendingMileage/" + key));
      }
    } catch (err) {
      // 待補里程清單只是輔助提醒，同步失敗不影響這筆維修紀錄本身已經存檔成功
      console.error("同步待補里程清單失敗：", err);
    }
  }

  // -----------------------------------------------------------------
  // ✏️ 編輯歷史維修紀錄模式：從「歷史維修紀錄」點進來修改內容，存檔時要
  // 「覆蓋」原本那一筆（records/{key}/repairs/{editingHistoryRepairId}），
  // 不是新增一筆；日期／時間就是目前表單上的值——載入時已經帶入原本的舊
  // 時間，只要使用者沒有手動去改，就不會自動跳成現在時間。
  // 這裡刻意不呼叫 deductStockForRepairItems()：那些品項的庫存在「第一次」
  // 存這筆紀錄時就已經扣過了，單純編輯內容不應該再扣一次，避免庫存被重複扣。
  // -----------------------------------------------------------------
  if (editingHistoryRepairId) {
    if (!isOnline) {
      showAppAlert("目前離線中，編輯歷史維修紀錄需要連上網路才能存檔，請連上網路後再試一次！");
      saveBtn.disabled = false;
      if (pendingBtn) pendingBtn.disabled = false;
      saveBtn.textContent = "儲存維修資料";
      if (pendingBtn) pendingBtn.textContent = "里程晚點補登";
      return false;
    }

    const repairId = editingHistoryRepairId;

    try {
      await update(ref(db, "records/" + key + "/repairs/" + repairId), record);
      await syncPendingMileageMarker();

      const cached = recordCache.get(key) || {};
      cached.repairs = cached.repairs || {};
      cached.repairs[repairId] = record;
      recordCache.set(key, cached);

      if (!mileageMissing) lastMileageValue = mileage;

      editingHistoryRepairId = null;
      await deleteLoadedEstimateSourceIfAny(key);
      showAppAlert("維修紀錄已更新！");
      renderRepairPanel(); // 清空表單、重置分頁文字，準備輸入下一筆全新紀錄
      renderHistoryPanel(cached);
      window.switchDetailTab("history"); // 存完直接回到歷史維修紀錄，看到更新後的內容
      return true;
    } catch (err) {
      console.error("更新歷史維修紀錄失敗：", err);
      showAppAlert(`更新失敗：${err.code || err.message || "未知錯誤"}`);
      return false;
    } finally {
      saveBtn.disabled = false;
      if (pendingBtn) pendingBtn.disabled = false;
      saveBtn.textContent = "儲存維修資料";
      if (pendingBtn) pendingBtn.textContent = "里程晚點補登";
    }
  }

  // -----------------------------------------------------------------
  // 💾 存檔策略：一律先寫進本機硬碟，穩了以後才嘗試上傳伺服器。
  //
  // 不管當下有沒有網路，都先把這筆紀錄放進硬碟佇列、確定真的寫進硬碟了
  // 才跟使用者說「已儲存」；接著才在背景嘗試連線把它（跟佇列裡其他還沒
  // 上傳的）同步上傳到 Firebase（包含扣庫存、待補里程清單）。就算上傳
  // 失敗、或當下根本沒網路，這筆紀錄也已經穩穩留在硬碟佇列裡，等下次
  // 有網路會自動繼續補傳，不會因為存檔當下的連線狀況而遺失。
  // -----------------------------------------------------------------
  const savedToDisk = await queueOfflineRecord(key, record, queryLabel);

  if (!mileageMissing) lastMileageValue = mileage;
  saveBtn.disabled = false;
  if (pendingBtn) pendingBtn.disabled = false;
  saveBtn.textContent = "儲存維修資料";
  if (pendingBtn) pendingBtn.textContent = "里程晚點補登";

  if (savedToDisk) {
    await commitDailyCustomerCode();
    await syncPendingMileageMarker();
    await deleteLoadedEstimateSourceIfAny(key);
    showAppAlert(
      mileageMissing
        ? "維修紀錄已儲存！里程數還沒填，已加入搜尋畫面上方的「待補里程」提醒。"
        : "維修紀錄已儲存！"
    );
  } else {
    // 寫入硬碟失敗（例如磁碟空間不足、權限問題），資料目前只存在記憶體裡，
    // 這個當下絕對不能關閉程式或關機，否則這筆紀錄就真的會不見。
    showAppAlert(
      "寫入硬碟失敗！這筆紀錄目前只暫存在記憶體中，請先不要關閉程式或關機，" +
        "確認硬碟空間足夠後再試一次儲存。"
    );
  }

  if (skipMileage) {
    window.closeDetailPage(); // 跳回首頁，馬上看到補登提醒
  } else {
    renderRepairPanel(); // 清空表單，準備輸入下一筆
  }

  // 硬碟已經穩了，接下來才是「盡量」把它同步上傳到 Firebase：背景執行、
  // 不用讓使用者乾等網路來回。目前沒網路的話 syncOfflineQueue() 內部
  // 本來就會直接跳過，等真的恢復連線再自動繼續補傳。
  syncOfflineQueue();

  return true;
};

// -----------------------------------------------------------------
// 💰 儲存估價：把目前表單上已經打好的品項存成一筆「估價」，寫進 Firebase
// 的 records/{key}/estimates/ 底下——刻意跟正式維修紀錄的 records/{key}/repairs/
// 分成兩個不同節點，單純留底、方便之後查價或對帳，不會出現在「歷史維修
// 紀錄」分頁（那邊只讀 repairs/），也不會扣庫存、不影響「上次里程」或
// 保養提醒的判斷。跟「里程晚點補登」一樣，只要品項有打好就能先存，不需要
// 填里程、也不強制一定要選技師。
// -----------------------------------------------------------------
// 如果目前表單上的品項是從「載入估價」帶進來的（loadedEstimateSourceId 有值），
// 存檔成功後就把那筆來源估價從 Firebase 刪掉，避免同一筆估價一直留在
// 「載入估價」清單裡、感覺像存了好幾次一樣。純粹是清掉來源那筆，不影響
// 剛剛存檔成功的這筆新紀錄。
async function deleteLoadedEstimateSourceIfAny(key) {
  const sourceId = loadedEstimateSourceId;
  if (!sourceId) return;
  loadedEstimateSourceId = null; // 不管刪除成不成功，都先當作「已經處理過」，避免重複觸發

  try {
    await remove(ref(db, "records/" + key + "/estimates/" + sourceId));
    const cached = recordCache.get(key);
    if (cached && cached.estimates) {
      delete cached.estimates[sourceId];
      recordCache.set(key, cached);
    }
    window.updateLoadEstimateButtonVisibility();
  } catch (err) {
    // 刪除來源估價失敗不影響剛剛存檔成功的紀錄本身，單純下次「載入估價」
    // 清單裡會多看到這一筆舊的，靜默記錄即可。
    console.error("刪除來源估價失敗：", err);
  }
}

window.saveEstimateRecord = async function () {
  if (!currentRecordKey) return false;

  const items = [];
  document.querySelectorAll("#repair_items_body tr").forEach((row) => {
    const name = row.querySelector(".repair_item_name").value.trim();
    const qty = parseFloat(row.querySelector(".repair_item_qty").value) || 0;
    const price =
      parseFloat(row.querySelector(".repair_item_price").value) || 0;
    const category = row.dataset.category || DEFAULT_MANUAL_ITEM_CATEGORY;
    const maintenanceType =
      row.dataset.maintenanceType || DEFAULT_MAINTENANCE_TYPE;
    if (name) {
      items.push({
        name,
        qty,
        price,
        subtotal: qty * price,
        category,
        maintenanceType,
      });
    }
  });

  if (items.length === 0) {
    showAppAlert("請至少輸入一項估價品項！");
    return false;
  }

  if (!isOnline) {
    showAppAlert("目前離線中，儲存估價需要連上網路才能存檔，請連上網路後再試一次！");
    return false;
  }

  const dateVal = document.getElementById("repair_date").value || todayStr();
  const timeVal = document.getElementById("repair_time").value || nowTimeStr();
  const datetime = `${dateVal}T${timeVal}`;
  const mechanic = getMechanicName();
  const notes = repairNotesValue.trim();
  const cost = items.reduce((sum, it) => sum + it.subtotal, 0);

  const key = currentRecordKey;
  const estimate = {
    datetime,
    items: items.map((it) => `${it.name} x${it.qty}`).join("、"),
    itemsDetail: items,
    mechanic,
    cost,
    notes,
    savedAt: Date.now(),
  };

  const estimateBtn = document.getElementById("repair_save_estimate_btn");
  if (estimateBtn) {
    estimateBtn.disabled = true;
    estimateBtn.textContent = "儲存中...";
  }

  try {
    const newRef = push(ref(db, "records/" + key + "/estimates"));
    await set(newRef, estimate);

    const cached = recordCache.get(key) || {};
    cached.estimates = cached.estimates || {};
    cached.estimates[newRef.key] = estimate;
    recordCache.set(key, cached);

    await commitDailyCustomerCode();
    await deleteLoadedEstimateSourceIfAny(key);
    window.updateLoadEstimateButtonVisibility();
    showAppAlert("估價已儲存！（只留底在伺服器上，不會出現在歷史維修紀錄）");
    return true;
  } catch (err) {
    console.error("儲存估價失敗：", err);
    showAppAlert(`儲存估價失敗：${err.code || err.message || "未知錯誤"}`);
    return false;
  } finally {
    if (estimateBtn) {
      estimateBtn.disabled = false;
      estimateBtn.textContent = "儲存估價";
    }
  }
};

// -----------------------------------------------------------------
// 📥 載入估價：把之前用「儲存估價」存下來的品項（records/{key}/estimates/）
// 重新帶回目前的維修資料表單，方便客戶回來要實際維修時不用重打一次品項。
// 純粹是「帶入表單」，不會覆蓋、也不會刪除原本那筆估價，存檔時一樣是
// 新增一筆全新的維修紀錄（或估價），不影響原始估價資料。
// -----------------------------------------------------------------
// -----------------------------------------------------------------
// 「載入估價」按鈕預設是隱藏的：這台車還沒存過任何估價時，按了也只會看到
// 「這台車還沒有存過估價」的空清單，容易讓人誤會。所以改成只有在
// recordCache 裡已經有這台車的估價資料時才顯示，存完第一筆估價後就會自動出現。
// -----------------------------------------------------------------
window.updateLoadEstimateButtonVisibility = function () {
  const btn = document.getElementById("repair_load_estimate_btn");
  if (!btn) return;
  const cached = currentRecordKey ? recordCache.get(currentRecordKey) : null;
  const hasEstimates =
    !!cached && !!cached.estimates && Object.keys(cached.estimates).length > 0;
  btn.classList.toggle("hidden", !hasEstimates);
};

window.openLoadEstimateModal = function () {
  if (!currentRecordKey) return;

  const cached = recordCache.get(currentRecordKey) || {};
  const entries = Object.entries(cached.estimates || {}).sort(
    (a, b) => (b[1]?.savedAt || 0) - (a[1]?.savedAt || 0)
  );

  const bodyEl = document.getElementById("load_estimate_body");
  if (bodyEl) {
    bodyEl.innerHTML =
      entries.length === 0
        ? `<div class="text-center text-gray-400 py-10">這台車還沒有存過估價</div>`
        : entries
            .map(([id, est]) => {
              const dt = (est.datetime || "").replace("T", " ") || "-";
              return `
              <div onclick="window.loadEstimateIntoForm('${escapeAttrForBadge(
                id
              )}')"
                class="flex items-center justify-between border border-gray-200 rounded-lg px-4 py-3 mb-2 hover:bg-purple-50 cursor-pointer transition">
                <div class="min-w-0 mr-3">
                  <div class="font-bold text-gray-700">${dt}</div>
                  <div class="text-sm text-gray-500 truncate max-w-xs">${escapeAttr(
                    est.items || "-"
                  )}</div>
                </div>
                <div class="text-lg font-black text-gray-800 flex-shrink-0">$${
                  est.cost != null ? est.cost : 0
                }</div>
              </div>`;
            })
            .join("");
  }

  const modal = document.getElementById("load_estimate_modal");
  if (modal) {
    modal.classList.remove("hidden");
    modal.classList.add("flex");
  }
};

window.closeLoadEstimateModal = function () {
  const modal = document.getElementById("load_estimate_modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
};

window.loadEstimateIntoForm = function (id) {
  const cached = recordCache.get(currentRecordKey) || {};
  const estimate = (cached.estimates || {})[id];
  window.closeLoadEstimateModal();
  if (!estimate) return;

  // 載入估價只是把品項帶回表單，跟「載入維修資料」不同：存檔時是新增一筆，
  // 不會去覆蓋任何既有紀錄，所以兩種編輯模式都要確保是關閉的。
  editingHistoryRepairId = null;
  pendingRepairEditKey = null;
  loadedEstimateSourceId = id; // 記住來源估價 id，等這筆表單存檔成功後要把這筆估價從「載入估價」清單裡刪掉

  const mechanicSelect = document.getElementById("repair_mechanic_select");
  const customInput = document.getElementById("repair_mechanic_custom");
  const knownMechanics = ["阿翰", "明松"];
  if (mechanicSelect && estimate.mechanic) {
    if (knownMechanics.includes(estimate.mechanic)) {
      mechanicSelect.value = estimate.mechanic;
      if (customInput) customInput.classList.add("hidden");
    } else {
      mechanicSelect.value = "__custom__";
      if (customInput) {
        customInput.classList.remove("hidden");
        customInput.value = estimate.mechanic;
      }
    }
  }

  repairNotesValue = estimate.notes || "";
  updateNotesButtonLabel();

  const tbody = document.getElementById("repair_items_body");
  if (tbody) tbody.innerHTML = "";
  repairRowSeq = 0;
  (estimate.itemsDetail || []).forEach((it) => {
    addPrefillRepairItemRow(
      it.name,
      it.qty,
      it.price,
      it.category,
      it.maintenanceType
    );
  });
  recalcRepairTotal();

  showAppAlert("估價品項已載入，確認無誤後記得儲存維修資料！");
};

// -----------------------------------------------------------------
// ⚠️ 離開前的未儲存確認：判斷目前「維修資料」分頁是否已經填了任何內容
// （里程、品項、備註、技師），如果有但還沒按過儲存，離開前先跳出提示，
// 避免手滑點到「回首頁」把剛輸入的資料弄丟。
// -----------------------------------------------------------------

function hasUnsavedRepairData() {
  const mileageInput = document.getElementById("repair_mileage");
  if (mileageInput && mileageInput.value.trim() !== "") return true;

  const nameInputs = document.querySelectorAll(
    "#repair_items_body .repair_item_name"
  );
  for (const input of nameInputs) {
    if (input.value.trim() !== "") return true;
  }

  if (repairNotesValue && repairNotesValue.trim() !== "") return true;

  const mechanicSelect = document.getElementById("repair_mechanic_select");
  if (mechanicSelect) {
    if (mechanicSelect.value === "__custom__") {
      const customInput = document.getElementById("repair_mechanic_custom");
      if (customInput && customInput.value.trim() !== "") return true;
    } else if (mechanicSelect.value !== "") {
      return true;
    }
  }

  return false;
}

// 按「回首頁」（或 Esc）時呼叫這個函式，取代直接呼叫 closeDetailPage()。
// 有未儲存的內容才會跳出提示，沒有的話就直接離開。
window.requestCloseDetailPage = function () {
  if (!hasUnsavedRepairData()) {
    window.closeDetailPage();
    return;
  }
  const modal = document.getElementById("unsaved_changes_modal");
  modal.classList.remove("hidden");
  modal.classList.add("flex");
};

window.closeUnsavedChangesModal = function () {
  const modal = document.getElementById("unsaved_changes_modal");
  modal.classList.add("hidden");
  modal.classList.remove("flex");
};

// 選「否」：捨棄目前輸入的內容，直接離開
window.discardAndLeave = function () {
  window.closeUnsavedChangesModal();
  window.closeDetailPage();
};

// 選「是」：先嘗試存檔，成功才離開；如果存檔失敗（例如漏填必填欄位），
// saveRepairRecord() 內部已經用 alert 提醒過原因，這裡就留在原畫面讓使用者修正，
// 不會硬把人踢出去。
window.saveAndLeave = async function () {
  window.closeUnsavedChangesModal();
  const saved = await window.saveRepairRecord();
  if (saved) {
    window.closeDetailPage();
  }
};

let customerEditMode = false; // 顧客資訊分頁目前是「檢視」還是「編輯」狀態
let customerEditPhones = []; // 編輯顧客資料時，目前正在編輯的電話清單 [{type, number}]

// 把顧客資料裡的電話統一整理成陣列格式 [{type, number}]。
// 舊資料只有單一 phone 欄位（字串）時，自動包成一筆「行動電話」，
// 這樣不管資料是舊格式還是新格式，畫面都能正常顯示／編輯。
function getCustomerPhoneList(c) {
  if (Array.isArray(c.phones) && c.phones.length > 0) {
    return c.phones.map((p) => {
      const number = (p && p.number) || "";
      return {
        type: phoneTypeForDigits(String(number).replace(/\D/g, "")),
        number,
      };
    });
  }
  if (c.phone) {
    return [
      {
        type: phoneTypeForDigits(String(c.phone).replace(/\D/g, "")),
        number: c.phone,
      },
    ];
  }
  return [];
}

function renderCustomerPanel(data) {
  const c = (data && data.customer) || {};

  if (customerEditMode) {
    renderCustomerEditForm(c);
    return;
  }

  const phoneList = getCustomerPhoneList(c);
  const phoneHtml = phoneList.length
    ? phoneList
        .map(
          (p) =>
            `<div>${escapeAttr(p.type)}：${escapeAttr(
              p.number || "-"
            )}</div>`
        )
        .join("")
    : `<div>-</div>`;

  const otherRows = [
    ["會員卡號", c.memberId || "-"],
    ["地址", c.address || "-"],
    ["備註", c.notes || "-"],
  ];
  document.getElementById("panel_customer").innerHTML = `
    <h2 class="text-xl font-bold text-gray-700 mb-4">顧客資訊</h2>
    <div class="grid grid-cols-2 gap-y-3 gap-x-6">
      <div class="flex flex-col">
        <span class="text-sm text-gray-400 font-bold">姓名</span>
        <span class="text-lg text-gray-800">${escapeAttr(
          c.name || "-"
        )}</span>
      </div>
      <div class="flex flex-col">
        <span class="text-sm text-gray-400 font-bold">電話</span>
        <div class="text-lg text-gray-800">${phoneHtml}</div>
      </div>
      ${otherRows
        .map(
          ([label, value]) => `
        <div class="flex flex-col">
          <span class="text-sm text-gray-400 font-bold">${label}</span>
          <span class="text-lg text-gray-800">${escapeAttr(
            String(value)
          )}</span>
        </div>`
        )
        .join("")}
    </div>
    <div class="flex justify-end mt-6">
      <button onclick="toggleCustomerEditMode()"
        class="bg-blue-600 text-white px-5 py-2.5 text-sm font-bold rounded hover:bg-blue-500 shadow transition">
        編輯
      </button>
    </div>
  `;
}

// 市內電話區碼對照表：要先比對比較長的區碼（4 碼），再比對 3 碼、2 碼，
// 這樣像 0826／0836 這種 4 碼區碼，才不會被 08 這種 2 碼區碼搶先比對到。
// maxDigits 是「含橫線」的總字元數上限（例如 02 最多 11 碼＝「02-」＋8 碼數字）。
const PHONE_AREA_CODES = [
  { prefix: "0826", maxDigits: 10 },
  { prefix: "0836", maxDigits: 10 },
  { prefix: "037", maxDigits: 10 },
  { prefix: "049", maxDigits: 11 },
  { prefix: "082", maxDigits: 10 },
  { prefix: "089", maxDigits: 10 },
  { prefix: "02", maxDigits: 11 },
  { prefix: "03", maxDigits: 10 },
  { prefix: "04", maxDigits: 11 },
  { prefix: "05", maxDigits: 10 },
  { prefix: "06", maxDigits: 10 },
  { prefix: "07", maxDigits: 10 },
  { prefix: "08", maxDigits: 10 },
];

// 電話號碼即時格式化：邊打邊判斷是手機還是市話。
// 前 4 碼還看不出來是哪種區碼（例如 08 有可能後面接成 082、089、0826、0836），
// 所以先不做任何格式化；打超過 4 碼之後才開始判斷——09 開頭當手機看，
// 不加「-」，最多 10 碼；其他就照區碼表在區碼後面自動補「-」，並限制總碼數。
// 04（台中）跟 049（南投）是巢狀區碼，只有打到「049」（第三碼剛好是 9）
// 才真的分不出來——可能是南投的 049 區碼，也可能是台中 04 區碼、
// 本地碼剛好第一碼是 9。只要打到「04」但第三碼不是 9（例如 042、048），
// 就已經確定是台中，不用再跳出來問，讓使用者少按一次選單。
//
// 08（屏東）跟 089（臺東）是同樣的巢狀關係：打到「089」時，可能是臺東的
// 089 區碼，也可能是屏東 08 區碼、本地碼剛好第一碼是 9（例如
// 08-9234567 vs 089-123456，兩種都是合法號碼，光看數字分不出來），
// 所以一樣要跳出來讓使用者自己選長區碼還是短區碼。
const AMBIGUOUS_AREA_GROUPS = [
  {
    trigger: "049",
    defaultChoice: "049",
    options: [
      { value: "04", label: "區碼是 04（台中）" },
      { value: "049", label: "區碼是 049（南投）" },
    ],
  },
  {
    trigger: "089",
    defaultChoice: "08",
    options: [
      { value: "08", label: "區碼是 08（屏東）" },
      { value: "089", label: "區碼是 089（臺東）" },
    ],
  },
];

function findAmbiguousAreaGroup(digits) {
  return AMBIGUOUS_AREA_GROUPS.find((g) => digits.startsWith(g.trigger)) || null;
}

function isAmbiguousAreaPrefix(digits) {
  return !!findAmbiguousAreaGroup(digits);
}

// 使用者還沒手動選之前的預設值：延續原本自動判斷的邏輯（優先當作長區碼）。
function defaultAreaChoiceFor(digits) {
  const group = findAmbiguousAreaGroup(digits);
  return group ? group.defaultChoice : undefined;
}

// 依目前輸入的數字，組出對應那組（04/049 或 08/089）的下拉選單 <option> HTML。
function areaChoiceOptionsHtml(digits, selectedChoice) {
  const group = findAmbiguousAreaGroup(digits);
  if (!group) return "";
  return group.options
    .map(
      (o) =>
        `<option value="${o.value}" ${
          selectedChoice === o.value ? "selected" : ""
        }>${o.label}</option>`
    )
    .join("");
}

// 電話類型「系統自己判斷」：09 開頭當行動電話，其他（市話區碼／還沒打字）當電話。
// 還沒打任何數字時先當行動電話，跟原本新增一列電話的預設值一致。
function phoneTypeForDigits(digits) {
  if (!digits) return "行動電話";
  return digits.startsWith("09") ? "行動電話" : "電話";
}

function formatTaiwanPhoneNumber(raw, forcedPrefix) {
  const digits = String(raw || "").replace(/\D/g, "");
  if (digits.length <= 4) return digits;

  if (digits.startsWith("09")) {
    return digits.slice(0, 10);
  }

  let area = null;
  if (forcedPrefix) {
    area = PHONE_AREA_CODES.find((a) => a.prefix === forcedPrefix) || null;
  }
  if (!area) {
    area = PHONE_AREA_CODES.find((a) => digits.startsWith(a.prefix));
  }
  if (!area) return digits;

  // maxDigits 是「含橫線」的總字元數上限，實際能打的數字碼數要再扣掉橫線這 1 格
  const capped = digits.slice(0, area.maxDigits - 1);
  const rest = capped.slice(area.prefix.length);
  return rest ? `${area.prefix}-${rest}` : area.prefix;
}

// 畫出目前編輯中的電話清單（每一列：類型下拉「行動電話／電話」＋號碼輸入＋刪除按鈕）。
// 打到「04」開頭時，號碼輸入框下面會多一個「04／049」下拉選單讓使用者自己選。
// 資料存在 customerEditPhones 陣列裡，輸入框/選單改變時同步寫回陣列，
// 這樣按「＋ 新增電話」重畫整個清單時，使用者已經打好的號碼才不會不見。
function renderCustomerEditPhoneRows() {
  const wrap = document.getElementById("customer_edit_phones_list");
  if (!wrap) return;
  wrap.innerHTML = customerEditPhones
    .map((p, idx) => {
      const digits = String(p.number || "").replace(/\D/g, "");
      const ambiguous = appSmartKeyboardEnabled && isAmbiguousAreaPrefix(digits);
      if (ambiguous && !p.areaChoice) {
        p.areaChoice = defaultAreaChoiceFor(digits);
      }
      const type = phoneTypeForDigits(digits);
      p.type = type;
      return `
    <div class="flex items-center gap-2">
      <div id="phone_type_badge_${idx}"
        class="border border-gray-200 rounded px-2 py-3 text-lg bg-gray-50 text-gray-600 flex-shrink-0 w-32 text-center select-none">${type}</div>
      <div class="flex flex-col flex-1">
        <input id="phone_number_input_${idx}" type="text" value="${escapeAttr(
        p.number || ""
      )}" placeholder="輸入電話號碼"
          oninput="handleCustomerEditPhoneInput(${idx}, this)"
          class="border border-gray-300 rounded px-3 py-3 text-lg w-full" />
        <select id="phone_area_choice_${idx}"
          onchange="handleCustomerEditPhoneAreaChoice(${idx}, this.value)"
          class="mt-1 border border-orange-300 rounded px-2 py-1 text-sm bg-orange-50 text-orange-700 ${
            ambiguous ? "" : "hidden"
          }">
          ${areaChoiceOptionsHtml(digits, p.areaChoice)}
        </select>
      </div>
      <button type="button" onclick="removeCustomerEditPhoneRow(${idx})"
        title="刪除這組電話"
        class="text-red-500 hover:text-red-700 font-bold px-2 py-2 flex-shrink-0 ${
          customerEditPhones.length <= 1 ? "invisible" : ""
        }">✕</button>
    </div>`;
    })
    .join("");
}

window.updateCustomerEditPhoneField = function (idx, field, value) {
  if (!customerEditPhones[idx]) return;
  customerEditPhones[idx][field] = value;
};

// 電話號碼輸入框的 oninput：邊打邊格式化（自動補「-」、限制碼數）。
// 打到「04」開頭時，同步顯示/更新旁邊的 04／049 下拉選單，並用使用者選的區碼來格式化，
// 不直接整個重畫清單，避免打字打到一半輸入框失焦。
window.handleCustomerEditPhoneInput = function (idx, inputEl) {
  if (!customerEditPhones[idx]) return;
  const digits = String(inputEl.value || "").replace(/\D/g, "");
  const ambiguous = appSmartKeyboardEnabled && isAmbiguousAreaPrefix(digits);

  if (ambiguous) {
    if (!customerEditPhones[idx].areaChoice) {
      customerEditPhones[idx].areaChoice = defaultAreaChoiceFor(digits);
    }
  } else {
    customerEditPhones[idx].areaChoice = undefined;
  }

  const forcedPrefix = ambiguous ? customerEditPhones[idx].areaChoice : undefined;
  const formatted = appSmartKeyboardEnabled
    ? formatTaiwanPhoneNumber(digits, forcedPrefix)
    : digits;
  inputEl.value = formatted;
  window.updateCustomerEditPhoneField(idx, "number", formatted);

  const type = phoneTypeForDigits(digits);
  customerEditPhones[idx].type = type;
  const typeBadge = document.getElementById(`phone_type_badge_${idx}`);
  if (typeBadge) typeBadge.textContent = type;

  const choiceSelect = document.getElementById(`phone_area_choice_${idx}`);
  if (choiceSelect) {
    choiceSelect.classList.toggle("hidden", !ambiguous);
    if (ambiguous) {
      choiceSelect.innerHTML = areaChoiceOptionsHtml(digits, customerEditPhones[idx].areaChoice);
      choiceSelect.value = customerEditPhones[idx].areaChoice;
    }
  }
};

// 使用者在「04／049」下拉選單手動選擇時：直接用選到的區碼重新格式化目前的號碼。
window.handleCustomerEditPhoneAreaChoice = function (idx, choice) {
  if (!customerEditPhones[idx]) return;
  customerEditPhones[idx].areaChoice = choice;
  const digits = String(customerEditPhones[idx].number || "").replace(
    /\D/g,
    ""
  );
  const formatted = formatTaiwanPhoneNumber(digits, choice);
  customerEditPhones[idx].number = formatted;
  const inputEl = document.getElementById(`phone_number_input_${idx}`);
  if (inputEl) inputEl.value = formatted;
};

window.addCustomerEditPhoneRow = function () {
  customerEditPhones.push({ type: "行動電話", number: "" });
  renderCustomerEditPhoneRows();
};

window.removeCustomerEditPhoneRow = function (idx) {
  if (customerEditPhones.length <= 1) return; // 至少留一列，避免清單整個空掉不好加回來
  customerEditPhones.splice(idx, 1);
  renderCustomerEditPhoneRows();
};

// 編輯模式表單：欄位跟檢視模式一一對應，儲存時整包寫回 records/{key}/customer
function renderCustomerEditForm(c) {
  document.getElementById("panel_customer").innerHTML = `
    <h2 class="text-xl font-bold text-gray-700 mb-4">編輯顧客資訊</h2>
    <div class="grid grid-cols-2 gap-6 mb-6">
      <div class="flex flex-col">
        <label class="text-sm text-gray-400 font-bold mb-1">姓名</label>
        <input id="customer_edit_name" type="text" value="${escapeAttr(
          c.name || ""
        )}"
          class="border border-gray-300 rounded px-3 py-3 text-lg" />
      </div>
      <div class="flex flex-col">
        <label class="text-sm text-gray-400 font-bold mb-1">會員卡號</label>
        <input id="customer_edit_memberId" type="text" value="${escapeAttr(
          c.memberId || ""
        )}"
          class="border border-gray-300 rounded px-3 py-3 text-lg" />
      </div>
    </div>

    <div class="flex flex-col mb-6">
      <div class="flex items-center justify-between mb-1">
        <label class="text-sm text-gray-400 font-bold">電話</label>
        <button type="button" onclick="addCustomerEditPhoneRow()"
          class="text-sm text-blue-600 font-bold hover:text-blue-800">＋ 新增電話</button>
      </div>
      <div id="customer_edit_phones_list" class="flex flex-col gap-2"></div>
    </div>

    <div class="grid grid-cols-1 gap-6 mb-6">
      <div class="flex flex-col">
        <label class="text-sm text-gray-400 font-bold mb-1">地址</label>
        <input id="customer_edit_address" type="text" value="${escapeAttr(
          c.address || ""
        )}"
          class="border border-gray-300 rounded px-3 py-3 text-lg" />
      </div>
    </div>
    <div class="flex flex-col mb-6">
      <label class="text-sm text-gray-400 font-bold mb-1">備註</label>
      <textarea id="customer_edit_notes" rows="3"
        class="border border-gray-300 rounded px-3 py-3 text-lg resize-none">${escapeAttr(
          c.notes || ""
        )}</textarea>
    </div>
    <div class="flex justify-end gap-3">
      <button onclick="cancelCustomerEdit()"
        class="bg-gray-100 text-gray-600 px-5 py-2.5 text-sm font-bold rounded hover:bg-gray-200 shadow transition">
        取消
      </button>
      <button id="customer_save_btn" onclick="saveCustomerInfo()"
        style="background-color: #0f766e; color: #ffffff"
        class="px-5 py-2.5 text-sm font-bold rounded hover:opacity-90 shadow transition">
        儲存
      </button>
    </div>
  `;
  renderCustomerEditPhoneRows();
}

window.toggleCustomerEditMode = function () {
  customerEditMode = true;
  const cached = currentRecordKey ? recordCache.get(currentRecordKey) : null;
  const c = (cached && cached.customer) || {};
  customerEditPhones = getCustomerPhoneList(c);
  if (customerEditPhones.length === 0) {
    customerEditPhones = [{ type: "行動電話", number: "" }];
  }
  renderCustomerPanel(cached);
};

window.cancelCustomerEdit = function () {
  customerEditMode = false;
  const cached = currentRecordKey ? recordCache.get(currentRecordKey) : null;
  renderCustomerPanel(cached);
};

// 儲存顧客資訊：整包寫回 records/{key}/customer，成功後更新本地快取、
// 詳細資料頁上方顯示的顧客姓名，並切回檢視模式。
// phone 欄位仍保留（存第一組電話號碼），讓估價單、搜尋結果列表等舊功能維持正常運作。
window.saveCustomerInfo = async function () {
  if (!currentRecordKey) return;
  const key = currentRecordKey;

  const phoneRows = document.querySelectorAll(
    "#customer_edit_phones_list > div"
  );
  const phones = [];
  phoneRows.forEach((row) => {
    const type = row.querySelector("select").value;
    const number = row.querySelector("input").value.trim();
    if (number) phones.push({ type, number });
  });

  const customer = {
    name: document.getElementById("customer_edit_name").value.trim(),
    phones,
    phone: phones.length ? phones[0].number : "",
    memberId: document.getElementById("customer_edit_memberId").value.trim(),
    address: document.getElementById("customer_edit_address").value.trim(),
    notes: document.getElementById("customer_edit_notes").value.trim(),
  };

  const saveBtn = document.getElementById("customer_save_btn");
  if (saveBtn) {
    saveBtn.disabled = true;
    saveBtn.textContent = "儲存中...";
  }

  try {
    await set(ref(db, "records/" + key + "/customer"), customer);

    const cached = recordCache.get(key) || {};
    cached.customer = customer;
    recordCache.set(key, cached);

    const nameEl = document.getElementById("detail_customer_name");
    if (nameEl) nameEl.textContent = customer.name || "";

    customerEditMode = false;
    renderCustomerPanel(cached);
  } catch (err) {
    console.error("儲存顧客資訊失敗：", err);
    showAppAlert(`儲存失敗：${err.code || err.message || "未知錯誤"}`);
    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.textContent = "儲存";
    }
  }
};

// 目前「歷史維修紀錄」分頁顯示的那批紀錄（{id: recordData}），
// 給 selectHistoryRecord() 點擊某一列時查表用，不用重打 Firebase。
let currentHistoryRepairs = {};
let selectedHistoryId = null; // 目前選到（反白）的那一筆歷史紀錄 id，供鍵盤快捷鍵（載入／刪除）使用

function renderHistoryPanel(data) {
  const repairs = (data && data.repairs) || {};
  currentHistoryRepairs = repairs;
  selectedHistoryId = null;

  // 「里程晚點補登」還沒補上里程的那筆，只是暫存的半成品資料（真正要看的
  // 是搜尋畫面上方「待補里程」提醒），在正式補上里程之前不該出現在歷史
  // 維修紀錄裡混淆視聽；等補登完成、mileageMissing 變成 false 之後才會顯示。
  const list = Object.entries(repairs)
    .filter(([, r]) => !r.mileageMissing)
    .map(([id, r]) => ({ id, ...r }))
    .sort((a, b) =>
      (b.datetime || b.date || "").localeCompare(a.datetime || a.date || "")
    );

  const listHtml =
    list.length === 0
      ? `<div class="text-center text-gray-400 py-10">尚無維修紀錄</div>`
      : `
      <div style="max-height: 260px; overflow-y: auto;" class="border border-gray-200 rounded-lg">
      <table class="w-full text-left border-collapse">
        <thead>
          <tr style="background-color: #ffffff" class="border-b-2 border-gray-200 text-gray-500 text-sm sticky top-0">
            <th class="py-2 pr-2 pl-2">日期時間</th>
            <th class="py-2 pr-2">里程</th>
            <th class="py-2 pr-2">技師</th>
            <th class="py-2 pr-2 text-right">金額</th>
            <th class="py-2 pr-2 pl-2">備註</th>
          </tr>
        </thead>
        <tbody>
          ${list
            .map(
              (r) => `
            <tr class="history_row border-b border-gray-100 cursor-pointer hover:bg-blue-50 transition ${
              r._pending ? "bg-yellow-50" : ""
            }" data-id="${r.id}" onclick="selectHistoryRecord('${r.id}')">
              <td class="py-2 pr-2 pl-2 whitespace-nowrap">${(
                r.datetime ||
                r.date ||
                "-"
              ).replace("T", " ")}${
                r._pending
                  ? ` <span class="inline-block bg-yellow-400 text-yellow-900 text-xs font-bold px-2 py-0.5 rounded-full align-middle">尚未上傳</span>`
                  : ""
              }</td>
              <td class="py-2 pr-2 whitespace-nowrap">${
                r.mileage != null ? `${r.mileage} km` : "-"
              }</td>
              <td class="py-2 pr-2 whitespace-nowrap">${r.mechanic || "-"}</td>
              <td class="py-2 pr-2 text-right whitespace-nowrap">${
                r.cost != null ? `$${r.cost}` : "-"
              }</td>
              <td class="py-2 pr-2 pl-2 max-w-[160px] truncate text-gray-600" title="${
                r.notes ? escapeAttr(r.notes) : ""
              }">${r.notes ? escapeAttr(r.notes) : "-"}</td>
            </tr>`
            )
            .join("")}
        </tbody>
      </table>
      </div>`;

  document.getElementById("panel_history").innerHTML = `
    <h2 class="text-xl font-bold text-gray-700 mb-4">歷史維修紀錄</h2>
    <div id="history_list_region">${listHtml}</div>
    <div class="mt-6 pt-6 border-t-2 border-gray-200">
      <h3 class="text-lg font-bold text-gray-600 mb-3">維修項目明細</h3>
      <div id="history_detail_content" class="text-center text-gray-400 py-8">
        點擊上方任一筆紀錄，查看維修項目明細
      </div>
    </div>
  `;
}

// 點擊上方列表某一列：把該筆紀錄的品項明細顯示在下方，並把選到的那一列反白。
window.selectHistoryRecord = function (id) {
  const record = currentHistoryRepairs[id];
  const detailEl = document.getElementById("history_detail_content");
  if (!record || !detailEl) return;

  selectedHistoryId = id;

  document.querySelectorAll(".history_row").forEach((row) => {
    row.classList.toggle("bg-blue-50", row.dataset.id === id);
  });

  const items = record.itemsDetail || [];
  const total = items.reduce(
    (sum, it) => sum + (it.subtotal != null ? it.subtotal : it.qty * it.price),
    0
  );

  const itemsTableHtml =
    items.length === 0
      ? `<div class="text-center text-gray-500 py-4">這筆紀錄沒有明細資料，項目文字：${escapeAttr(
          record.items || "-"
        )}</div>`
      : `
      <table class="w-full text-left border-collapse">
        <thead>
          <tr class="border-b-2 border-yellow-400 text-gray-600 text-sm">
            <th class="py-2 pr-2">品項</th>
            <th class="py-2 pr-2 w-24">分類</th>
            <th class="py-2 pr-2 w-20 text-right">數量</th>
            <th class="py-2 pr-2 w-24 text-right">單價</th>
            <th class="py-2 pr-2 w-24 text-right">小計</th>
          </tr>
        </thead>
        <tbody>
          ${items
            .map(
              (it) => `
            <tr class="border-b border-yellow-300">
              <td class="py-2 pr-2">${escapeAttr(it.name)}</td>
              <td class="py-2 pr-2 text-sm">${escapeAttr(
                it.category || "-"
              )}</td>
              <td class="py-2 pr-2 text-right">${it.qty}</td>
              <td class="py-2 pr-2 text-right">$${it.price}</td>
              <td class="py-2 pr-2 text-right font-bold">$${
                it.subtotal != null ? it.subtotal : it.qty * it.price
              }</td>
            </tr>`
            )
            .join("")}
        </tbody>
      </table>
      <div class="flex justify-end items-center mt-3 pt-3 border-t-2 border-yellow-400">
        <span class="font-bold text-gray-700 mr-2">總計：</span>
        <span class="text-xl font-black text-gray-900">$${total}</span>
      </div>`;

  detailEl.innerHTML = `
    <div class="bg-yellow-300 text-gray-900 rounded-lg p-4 shadow-inner">
      ${itemsTableHtml}
      ${
        record.notes
          ? `<div class="mt-3 pt-3 border-t-2 border-yellow-400 text-sm text-gray-800">備註：${escapeAttr(
              record.notes
            )}</div>`
          : ""
      }
    </div>
    <div class="flex gap-3 mt-4">
      <button onclick="loadHistoryRecordToRepairTab('${id}')"
        class="flex-1 bg-blue-600 text-white px-4 py-3 text-base font-bold rounded hover:bg-blue-500 shadow transition">
        載入維修資料
      </button>
      <button id="history_generate_estimate_btn" onclick="generateEstimateFromHistory('${id}')"
        class="bg-white text-teal-700 border-2 border-teal-600 px-4 py-3 text-base font-bold rounded hover:bg-teal-50 shadow-sm transition">
        產生估價單
      </button>
      <button onclick="deleteHistoryRecord('${id}')"
        class="bg-red-600 text-white px-4 py-3 text-base font-bold rounded hover:bg-red-500 shadow transition">
        刪除歷史維修紀錄
      </button>
    </div>
  `;
};

// 📄「產生估價單」（用某一筆已經存檔的歷史維修紀錄）——例如客戶弄丟了紙本，
// 或當初沒有馬上列印，事後想重新補印一份估價單，就從歷史紀錄這裡重新產生。
window.generateEstimateFromHistory = async function (id) {
  const record = currentHistoryRepairs[id];
  if (!record) return;
  if (!window.electronAPI || !window.electronAPI.generateEstimateDocx) {
    showAppAlert("這個版本的程式還沒有「產生估價單」功能，請先更新到最新版本。");
    return;
  }

  const items = (record.itemsDetail || []).map((it) => ({
    name: it.name || "",
    amount: it.subtotal != null ? it.subtotal : (it.qty || 0) * (it.price || 0),
  }));

  const cached = currentRecordKey ? recordCache.get(currentRecordKey) : null;
  const customer = (cached && cached.customer) || {};
  const plateLabel =
    document.getElementById("detail_query_label")?.textContent?.trim() ||
    currentRecordKey ||
    "";
  const entryDate = (record.datetime || record.date || "").split("T")[0];

  await window.openEstimateChoiceModal(
    {
      entryDate,
      quoteDate: entryDate,
      customerName: customer.name || "",
      phone: customer.phone || "",
      plate: plateLabel,
      mileage: record.mileage != null ? record.mileage : "",
      notes: record.notes || "",
      items,
    },
    "history_generate_estimate_btn",
    "產生估價單"
  );
};

// 「📥 載入維修資料」：把這筆歷史紀錄的完整內容（含里程與分類）帶到「維修資料」分頁顯示，
// 並把該分頁的按鈕文字改成「維修資料(歷史紀錄)」，提醒使用者目前看到的是舊紀錄，
// 不是預設的空白新增表單。
window.loadHistoryRecordToRepairTab = function (id) {
  const record = currentHistoryRepairs[id];
  if (!record) return;

  window.switchDetailTab("repair");

  editingHistoryRepairId = id; // 存檔時要覆蓋這一筆，不是新增
  pendingRepairEditKey = null; // 兩種編輯模式互斥，載入歷史紀錄時先確保不是補登里程模式
  loadedEstimateSourceId = null; // 同上，也要確保不是從估價帶入的模式

  const [datePart, timePart] = (record.datetime || "").split("T");
  const dateInput = document.getElementById("repair_date");
  const timeInput = document.getElementById("repair_time");
  if (dateInput && datePart) dateInput.value = datePart;
  if (timeInput && timePart) timeInput.value = timePart;

  const mechanicSelect = document.getElementById("repair_mechanic_select");
  const customInput = document.getElementById("repair_mechanic_custom");
  const knownMechanics = ["阿翰", "明松"];
  if (mechanicSelect && record.mechanic) {
    if (knownMechanics.includes(record.mechanic)) {
      mechanicSelect.value = record.mechanic;
      if (customInput) customInput.classList.add("hidden");
    } else {
      mechanicSelect.value = "__custom__";
      if (customInput) {
        customInput.classList.remove("hidden");
        customInput.value = record.mechanic;
      }
    }
  }

  const mileageInput = document.getElementById("repair_mileage");
  if (mileageInput) {
    mileageInput.value = record.mileage != null ? record.mileage : "";
    window.updateDistanceDisplay();
  }

  repairNotesValue = record.notes || "";
  updateNotesButtonLabel();

  const tbody = document.getElementById("repair_items_body");
  if (tbody) tbody.innerHTML = "";
  repairRowSeq = 0;
  (record.itemsDetail || []).forEach((it) => {
    addPrefillRepairItemRow(
      it.name,
      it.qty,
      it.price,
      it.category,
      it.maintenanceType
    );
  });
  recalcRepairTotal();

  const repairTabBtn = document.querySelector(
    '.detail_tab_btn[data-tab="repair"]'
  );
  if (repairTabBtn) repairTabBtn.textContent = "維修資料(歷史紀錄)";
};

// 「🗑 刪除歷史維修紀錄」：從 Firebase 永久刪除這一筆維修紀錄，刪除後立即
// 更新本地快取並重新渲染上方列表與下方明細，不用重新整理頁面或重打一次 Firebase。
window.deleteHistoryRecord = async function (id) {
  if (!currentRecordKey) return;

  const confirmed = await showAppConfirm("確定要刪除這筆維修紀錄嗎？刪除後無法復原！");
  if (!confirmed) return;

  const key = currentRecordKey;

  try {
    await remove(ref(db, "records/" + key + "/repairs/" + id));

    const cached = recordCache.get(key) || {};
    if (cached.repairs) delete cached.repairs[id];
    recordCache.set(key, cached);

    renderHistoryPanel(cached);

    showAppAlert("已刪除這筆維修紀錄！");
  } catch (err) {
    console.error("刪除維修紀錄失敗：", err);
    showAppAlert(`刪除失敗：${err.code || err.message || "未知錯誤"}`);
  }
};

window.switchDetailTab = function (tab) {
  currentTab = tab;
  document.querySelectorAll(".detail_tab_btn").forEach((btn) => {
    const active = btn.dataset.tab === tab;
    btn.classList.toggle("bg-white", active);
    btn.classList.toggle("text-blue-700", active);
    btn.classList.toggle("border-blue-500", active);
    btn.classList.toggle("bg-gray-100", !active);
    btn.classList.toggle("text-gray-500", !active);
  });

  ["repair", "customer", "history"].forEach((name) => {
    document
      .getElementById(`panel_${name}`)
      .classList.toggle("hidden", name !== tab);
  });
};

// -----------------------------------------------------------------
// ✏️ 修改車牌／卡號：點擊詳細資料頁左上角的車牌文字，可以把整台車的資料
// （顧客資訊、維修紀錄）搬到新的車牌／卡號底下。因為 Firebase 是用車牌
// 正規化後的文字當作 key，所以「改車牌」實際上是：讀出舊 key 的完整資料、
// 寫到新 key、再刪除舊 key，並同步搬動待補里程提醒與最近紀錄裡的文字。
// -----------------------------------------------------------------

window.editVehiclePlate = function () {
  if (!currentRecordKey) return;

  const labelEl = document.getElementById("detail_query_label");
  const currentLabel = labelEl ? labelEl.textContent.trim() : currentRecordKey;

  const input = document.getElementById("edit_plate_input");
  const errorEl = document.getElementById("edit_plate_error");
  if (input) input.value = currentLabel;
  if (errorEl) {
    errorEl.classList.add("hidden");
    errorEl.textContent = "";
  }

  const modal = document.getElementById("edit_plate_modal");
  modal.classList.remove("hidden");
  modal.classList.add("flex");

  setTimeout(() => {
    if (input) {
      input.focus();
      input.select();
    }
  }, 0);
};

window.closeEditPlateModal = function () {
  const modal = document.getElementById("edit_plate_modal");
  modal.classList.add("hidden");
  modal.classList.remove("flex");
};

function showEditPlateError(message) {
  const errorEl = document.getElementById("edit_plate_error");
  if (!errorEl) return;
  errorEl.textContent = message;
  errorEl.classList.remove("hidden");
}

window.confirmEditVehiclePlate = async function () {
  if (!currentRecordKey) return;

  const labelEl = document.getElementById("detail_query_label");
  const currentLabel = labelEl ? labelEl.textContent.trim() : currentRecordKey;

  const input = document.getElementById("edit_plate_input");
  const trimmed = (input ? input.value : "").trim();

  if (!trimmed) {
    showEditPlateError("車牌／卡號不可空白！");
    return;
  }

  const pureInput = trimmed.replace(/-/g, "").toUpperCase();
  if (!pureInput) {
    showEditPlateError("請輸入有效的車牌／卡號！");
    return;
  }
  if (/[.#$\[\]/]/.test(pureInput)) {
    showEditPlateError("車牌／卡號不可包含 . # $ [ ] / 這些符號！");
    return;
  }

  // 格式化顯示用文字，規則跟搜尋框的智慧格式化一致
  let formattedLabel = pureInput;
  if (/^([A-Z]+)([0-9]+)/.test(pureInput)) {
    formattedLabel = pureInput.replace(/^([A-Z]+)([0-9]+)/, "$1-$2");
  } else if (/^([0-9]+)([A-Z]+)/.test(pureInput)) {
    formattedLabel = pureInput.replace(/^([0-9]+)([A-Z]+)/, "$1-$2");
  }

  const oldKey = currentRecordKey;
  const newKey = pureInput;

  if (newKey === oldKey) {
    window.closeEditPlateModal();
    return; // 沒有實際變更
  }

  const confirmBtn = document.getElementById("edit_plate_confirm_btn");
  if (confirmBtn) {
    confirmBtn.disabled = true;
    confirmBtn.textContent = "處理中...";
  }

  try {
    // 先確認新車牌沒有被其他車輛佔用，避免覆蓋掉別人的資料
    const newSnap = await get(ref(db, "records/" + newKey));
    if (newSnap.exists()) {
      showEditPlateError(
        `車牌「${formattedLabel}」已經有資料了，請改用其他車牌！`
      );
      return;
    }

    const oldSnap = await get(ref(db, "records/" + oldKey));
    const oldData = oldSnap.exists() ? oldSnap.val() : null;
    if (!oldData) {
      showEditPlateError("找不到原本的車輛資料，無法變更車牌！");
      return;
    }

    await set(ref(db, "records/" + newKey), oldData);
    await remove(ref(db, "records/" + oldKey));

    // 待補里程提醒（如果有）也要一併搬過去，並更新顯示文字
    const pendingSnap = await get(ref(db, "pendingMileage/" + oldKey));
    if (pendingSnap.exists()) {
      const pendingData = pendingSnap.val();
      await set(ref(db, "pendingMileage/" + newKey), {
        ...pendingData,
        query: formattedLabel,
      });
      await remove(ref(db, "pendingMileage/" + oldKey));
    }

    // 更新本地快取，讓畫面立刻反映新車牌，不用重打一次 Firebase
    recordCache.delete(oldKey);
    recordCache.set(newKey, oldData);
    currentRecordKey = newKey;
    if (labelEl) labelEl.textContent = formattedLabel;

    // 最近紀錄裡如果有舊車牌文字，一併換成新的（全店共用）
    renameRecentSearch(currentLabel, formattedLabel);

    window.closeEditPlateModal();
    showAppAlert(`車牌已從「${currentLabel}」改成「${formattedLabel}」！`);
  } catch (err) {
    console.error("變更車牌失敗：", err);
    showEditPlateError(`變更失敗：${err.code || err.message || "未知錯誤"}`);
  } finally {
    if (confirmBtn) {
      confirmBtn.disabled = false;
      confirmBtn.textContent = "確認變更";
    }
  }
};

window.closeDetailPage = function () {
  // 離開這筆車牌 / 卡號的資料頁前，順便關掉可能還開著的分類選單、備註視窗，
  // 以及未儲存提示視窗，避免監聽器留著繼續跑、或使用者誤把內容編輯到已經離開的紀錄上。
  if (
    !document.getElementById("item_picker_overlay").classList.contains("hidden")
  ) {
    window.closeItemPicker();
  }
  const notesModal = document.getElementById("repair_notes_modal");
  if (notesModal && !notesModal.classList.contains("hidden")) {
    window.closeNotesModal(false);
  }
  window.closeEditPlateModal();
  window.closeUnsavedChangesModal();
  window.closeEstimateChoiceModal();
  window.closeLoadEstimateModal();
  document.getElementById("detail_page").classList.add("hidden");
  document.getElementById("detail_page").classList.remove("flex");
};

async function openDetailPage(query, key) {
  // 切換到另一筆車牌 / 卡號查詢時，也先關閉分類選單與備註視窗，避免資料對錯紀錄。
  if (
    !document.getElementById("item_picker_overlay").classList.contains("hidden")
  ) {
    window.closeItemPicker();
  }
  const notesModal = document.getElementById("repair_notes_modal");
  if (notesModal && !notesModal.classList.contains("hidden")) {
    window.closeNotesModal(false);
  }
  window.closeEditPlateModal();
  window.closeUnsavedChangesModal();
  window.closeEstimateChoiceModal();
  window.closeLoadEstimateModal();

  const detailPage = document.getElementById("detail_page");
  detailPage.classList.remove("hidden");
  detailPage.classList.add("flex");

  document.getElementById("detail_query_label").textContent = query;
  document.getElementById("detail_customer_name").textContent = "";
  document.getElementById("detail_empty").classList.add("hidden");
  setDetailLoading(false);

  currentRecordKey = key;
  lastMileageValue = 0; // 新查詢先歸零，資料回來後再校正
  customerEditMode = false; // 每次開啟新查詢都先還原成檢視模式，避免切換車牌後卡在編輯畫面

  // 維修資料是輸入表單，不需要等資料讀回來就能馬上使用
  renderRepairPanel();
  previewDailyCustomerCode(); // 先預覽下一號長怎樣（背景進行，不擋畫面），真正存檔才會領走
  const loadingRow = `<div class="text-center text-gray-400 py-10">資料載入中...</div>`;
  document.getElementById("panel_customer").innerHTML = loadingRow;
  document.getElementById("panel_history").innerHTML = loadingRow;
  window.switchDetailTab(currentTab);

  try {
    const data = await fetchRecord(key);

    // 若使用者在等待期間切換了其他查詢，這筆結果就丟棄，避免畫面錯亂
    if (currentRecordKey !== key) return;

    renderCustomerPanel(data);
    renderHistoryPanel(data);
    applyHomePhoneDraftToCustomer(data); // 首頁順便打的電話，自動帶進顧客資訊（編輯模式，等使用者按儲存）
    document.getElementById("detail_customer_name").textContent =
      (data && data.customer && data.customer.name) || "";

    // 讀不到就補 0，並更新表單上顯示的「上次里程數」
    lastMileageValue = computeLastMileage(data);
    const lastMileageEl = document.getElementById("repair_last_mileage");
    if (lastMileageEl) lastMileageEl.value = lastMileageValue;
    if (typeof window.updateDistanceDisplay === "function") {
      window.updateDistanceDisplay();
    }
    // 資料到手後，保養提醒要跟著用最新的歷史紀錄重新判斷一次
    renderMaintenanceReminders(
      document.getElementById("repair_mileage")?.value ?? ""
    );
    window.updateLoadEstimateButtonVisibility();
  } catch (err) {
    console.error("讀取 Firebase 資料失敗：", err);
    if (currentRecordKey !== key) return;
    renderCustomerPanel(null);
    renderHistoryPanel(null);
  }
}

// 依電話號碼（純數字）在目前已知的客戶資料裡找出符合的車牌／卡號 key。
// 資料來源是 recordCache——登入時已經把整個資料庫同步進記憶體
// （見 syncFullRecordsToLocalDisk），所以這裡不用額外打 Firebase，
// 純粹在本機記憶體裡比對，速度很快。
// 注意：recordCache 是「登入當下」的完整快照 + 之後單筆查詢時順便更新，
// 不是即時監聽整棵 records/ 樹，所以如果剛好有別台電腦「同一時間」新增
// 客戶電話、而這台電腦還沒重新整理過，理論上會慢一點才比對得到，
// 這是可接受的小落差，不影響一般使用。
function findRecordKeysByPhone(digits) {
  const target = String(digits || "").replace(/\D/g, "");
  if (!target) return [];

  const matched = [];
  recordCache.forEach((data, key) => {
    if (!data || !data.customer) return;
    const phones = getCustomerPhoneList(data.customer);
    const hit = phones.some(
      (p) => String(p.number || "").replace(/\D/g, "") === target
    );
    if (hit) matched.push(key);
  });
  return matched;
}

// 🔎 資料載入與查詢
window.processSearch = function () {
  const displayEl = document.getElementById("search_display");
  const query = displayEl.textContent.trim(); // 帶有橫線的車牌（如 ASD-1234）

  if (!query) return;

  // 儲存至最近紀錄（全店共用）
  addRecentSearch(query);
  historyNavIndex = -1;

  const pureInput = query.replace(/-/g, "");
  const key = pureInput.toUpperCase();

  // 純數字（電話／卡號共用同一個輸入框）：先照舊當卡號直接查 key，
  // 如果查不到，「順便」比對是不是任何客戶留的電話號碼——這樣不管
  // 店家打的到底是卡號還是客戶電話，兩邊只要有一邊查得到資料，
  // 就會直接跳出那位客戶的歷史維修紀錄，不用先確認打的是哪一種。
  if (!isPlateModeQuery(pureInput)) {
    const directHasData = recordCache.has(key) && !!recordCache.get(key);
    if (!directHasData) {
      const phoneMatches = findRecordKeysByPhone(pureInput);
      if (phoneMatches.length === 1) {
        openDetailPage(query, phoneMatches[0]);
        return;
      }
      if (phoneMatches.length > 1) {
        showPhoneMatchPicker(query, phoneMatches);
        return;
      }
    }
  }

  // 開啟詳細資料頁（維修資料 / 顧客資訊 / 歷史維修紀錄），單次讀取 Firebase
  openDetailPage(query, key);
};

// 同一支電話對到多位客戶（例如家人共用電話）時，列出來讓使用者自己選要開哪一筆，
// 樣式沿用「最近紀錄」清單那一套，點了就直接開啟那筆的歷史維修紀錄。
window.showPhoneMatchPicker = function (queryText, keys) {
  const modal = document.getElementById("phone_match_modal");
  const listEl = document.getElementById("phone_match_list");
  if (!modal || !listEl) return;

  listEl.innerHTML = keys
    .map((k) => {
      const data = recordCache.get(k);
      const name = (data && data.customer && data.customer.name) || "";
      return `
        <button
          onclick="window.selectPhoneMatch('${escapeAttr(k)}')"
          class="w-full text-left bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg px-4 py-3 mb-2 transition"
        >
          <span class="font-bold text-blue-800">${escapeAttr(k)}</span>
          ${name ? `<span class="text-gray-500 text-sm ml-2">${escapeAttr(name)}</span>` : ""}
        </button>
      `;
    })
    .join("");

  document.getElementById("phone_match_hint").textContent =
    `電話「${queryText}」對到 ${keys.length} 筆客戶資料，請選一筆：`;

  modal.classList.remove("hidden");
  modal.classList.add("flex");
};

window.closePhoneMatchModal = function () {
  const modal = document.getElementById("phone_match_modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
};

// 使用者從「同一支電話對到多筆客戶」清單裡點了其中一筆
window.selectPhoneMatch = function (key) {
  window.closePhoneMatchModal();
  openDetailPage(key, key);
};

// -----------------------------------------------------------------
// 📦 分類選單：從分類列旁邊的圓形「＋」按鈕開啟新增品項表單。
//
// 品項清單存放在 Firebase 的 itemCatalog/{分類}/{品項ID}，是全店共用的
// 共用品項庫（不是單一維修單專屬）。用 onValue 即時監聽目前選到的分類，
// 只要任何一台裝置新增了品項，所有正在瀏覽同一分類的畫面都會立刻同步看到，
// 不用重新整理、也不用重打一次 Firebase —— 這是這個功能的重點。
// -----------------------------------------------------------------

const ITEM_CATEGORIES = [
  "其他",
  "油品",
  "輪胎",
  "引擎",
  "電裝",
  "煞車",
  "車體",
  "驅動系統",
  "轉向系統",
  "工資",
  "其他耗材",
];

// 「工資」是服務項目，不是實體零件，不需要庫存追蹤／不會被進貨或扣庫存影響
const NO_STOCK_CATEGORIES = new Set(["工資"]);

// 進貨系統可選的分類（排除「工資」），F1~F10 快捷鍵跟分類按鈕排列順序都用這份清單
const STOCK_IN_CATEGORIES = ITEM_CATEGORIES.filter(
  (cat) => !NO_STOCK_CATEGORIES.has(cat)
);

let pickerCurrentCategory = null; // 目前選到的分類
let pickerCatalogUnsubscribe = null; // onValue 回傳的取消訂閱函式
let pickerCatalogItems = {}; // 目前分類、從 Firebase 即時收到的品項 {pushId: {name, price}}
let pickerCart = {}; // 使用者在選單裡點選、尚未加入維修表的項目 {分類::pushId: {category, name, price, qty}}
let pickerSearchQuery = ""; // 目前的品項名稱搜尋關鍵字（小寫），空字串代表沒有在搜尋
let pickerCurrentPage = 1; // 目前分頁頁碼，品項太多時（例如某分類 300 多筆）分頁顯示
let pickerUsedItemNames = new Set(); // 這台車過去維修紀錄裡用過的品項名稱，用來把品項卡片標成螢光色

// 掃這台車（currentRecordKey）快取裡的所有歷史維修紀錄，把用過的品項名稱收集成一個 Set。
// 用名稱比對（trim 後），不是用 id 比對，因為舊紀錄的品項不一定是從共用品項庫點的。
function buildUsedItemNamesSet(key) {
  const set = new Set();
  const cached = key ? recordCache.get(key) : null;
  if (cached && cached.repairs) {
    Object.values(cached.repairs).forEach((repair) => {
      if (repair && Array.isArray(repair.itemsDetail)) {
        repair.itemsDetail.forEach((it) => {
          if (it && it.name) set.add(String(it.name).trim());
        });
      }
    });
  }
  return set;
}

function detachCatalogListener() {
  if (pickerCatalogUnsubscribe) {
    pickerCatalogUnsubscribe();
  }
  pickerCatalogUnsubscribe = null;
}

window.openItemPicker = function () {
  if (!currentRecordKey) {
    showAppAlert("請先搜尋並開啟一筆車牌 / 卡號資料，才能新增維修項目！");
    return;
  }

  // 進入維修項目的分類選單就填滿整個應用程式視窗，畫面更寬敞好選
  // （跟進貨系統的頁面一樣，用 CSS 讓畫面鋪滿 App 本身即可，不動到作業系統視窗
  // 本身的全螢幕狀態，避免跟讀取／存檔／列印視窗互相干擾）。

  pickerCart = {};
  pickerCurrentCategory = null;
  pickerCatalogItems = {};
  pickerSearchQuery = "";
  pickerCurrentPage = 1;
  pickerUsedItemNames = buildUsedItemNamesSet(currentRecordKey);

  renderPickerCategoryButtons();
  renderPickerCart();

  const formEl = document.getElementById("item_picker_new_item_form");
  formEl.classList.add("hidden");
  formEl.innerHTML = "";

  const searchBoxEl = document.getElementById("item_picker_search_box");
  searchBoxEl.classList.add("hidden");
  const searchInputEl = document.getElementById("picker_search_input");
  if (searchInputEl) searchInputEl.value = "";

  const overlay = document.getElementById("item_picker_overlay");
  overlay.classList.remove("hidden");
  overlay.classList.add("flex");

  // 預設先帶出「油品」分類，不用使用者自己再點一次
  window.selectPickerCategory("油品");
};

window.closeItemPicker = function () {
  detachCatalogListener();
  const overlay = document.getElementById("item_picker_overlay");
  overlay.classList.add("hidden");
  overlay.classList.remove("flex");
};

function renderPickerCategoryButtons() {
  const el = document.getElementById("item_picker_categories");
  el.innerHTML = ITEM_CATEGORIES.map(
    (cat) => `
    <button
      data-cat="${cat}"
      onclick="selectPickerCategory('${cat}')"
      class="picker_cat_btn flex-shrink-0 whitespace-nowrap px-3 py-1.5 text-sm rounded-full font-bold border-2 border-gray-300 bg-gray-50 text-gray-600 hover:border-red-300 transition"
    >${cat}</button>
  `
  ).join("");
}

// 點選分類：切換高亮、顯示載入中、掛上這個分類的即時監聽。
// 切換分類時一律先收起「新增品項」表單，避免把品項加錯分類。
window.selectPickerCategory = function (cat) {
  pickerCurrentCategory = cat;
  pickerSearchQuery = "";
  pickerCurrentPage = 1;

  document.querySelectorAll(".picker_cat_btn").forEach((btn) => {
    const active = btn.dataset.cat === cat;
    btn.classList.toggle("bg-red-50", active);
    btn.classList.toggle("text-red-600", active);
    btn.classList.toggle("border-red-500", active);
    btn.classList.toggle("bg-gray-50", !active);
    btn.classList.toggle("text-gray-600", !active);
    btn.classList.toggle("border-gray-300", !active);
  });

  document.getElementById("item_picker_list").innerHTML = `
    <div class="text-center text-gray-400 py-16">
      <div class="w-8 h-8 border-4 border-gray-300 border-t-blue-600 rounded-full animate-spin-custom mx-auto mb-3"></div>
      載入分類品項中...
    </div>
  `;

  const formEl = document.getElementById("item_picker_new_item_form");
  formEl.classList.add("hidden");
  formEl.innerHTML = "";

  const searchBoxEl = document.getElementById("item_picker_search_box");
  searchBoxEl.classList.add("hidden");
  const searchInputEl = document.getElementById("picker_search_input");
  if (searchInputEl) searchInputEl.value = "";

  detachCatalogListener();
  const catalogRef = ref(db, "itemCatalog/" + cat);
  pickerCatalogUnsubscribe = onValue(
    catalogRef,
    (snap) => {
      pickerCatalogItems = snap.exists() ? snap.val() : {};
      syncCartWithCatalog();
      renderPickerCatalogList();
    },
    (err) => {
      // 讀取失敗時（例如 Firebase 規則沒開放 itemCatalog 路徑）不要讓畫面
      // 一直卡在「載入中」，直接把真正的錯誤原因秀出來方便排查。
      console.error("讀取分類品項失敗：", err);
      pickerCatalogItems = {};
      document.getElementById("item_picker_list").innerHTML = `
        <div class="text-center text-red-500 py-16 px-4">
          <div class="font-bold mb-1">讀取「${cat}」品項失敗</div>
          <div class="text-sm text-gray-500">${
            err.code || err.message || "未知錯誤"
          }</div>
          <div class="text-sm text-gray-400 mt-2">請確認 Firebase 規則是否允許讀取 itemCatalog，或檢查網路連線</div>
        </div>`;
    }
  );
};

function renderPickerNewItemForm(cat) {
  const wrap = document.getElementById("item_picker_new_item_form");
  wrap.classList.remove("hidden");
  wrap.innerHTML = `
    <div class="flex items-center gap-2 flex-wrap">
      <span class="text-sm font-bold text-yellow-700 flex-shrink-0">＋ 新增品項到「${cat}」：</span>
      <input id="picker_new_name" type="text" placeholder="項目名稱"
        class="border border-gray-300 rounded px-3 py-2 flex-1 min-w-[10rem]" />
      <input id="picker_new_price" type="number" min="0" placeholder="單價"
        class="border border-gray-300 rounded px-3 py-2 w-28" />
      <button onclick="submitNewCatalogItem()"
        class="bg-yellow-500 text-white px-4 py-2 font-bold rounded hover:bg-yellow-600 transition flex-shrink-0">
        新增品項
      </button>
    </div>
  `;
}

// 點分類列旁邊那顆圓形「＋」按鈕：開/關「新增品項」表單。
// 沒選分類就先提醒使用者選分類，避免不知道要加到哪個分類。
window.toggleNewItemForm = function () {
  if (!pickerCurrentCategory) {
    showAppAlert("請先在上方選擇一個分類，才能新增品項！");
    return;
  }

  const wrap = document.getElementById("item_picker_new_item_form");
  const isHidden = wrap.classList.contains("hidden");

  if (isHidden) {
    renderPickerNewItemForm(pickerCurrentCategory);
    const nameInput = document.getElementById("picker_new_name");
    if (nameInput) nameInput.focus();
  } else {
    wrap.classList.add("hidden");
    wrap.innerHTML = "";
  }
};

// 點分類列旁邊那顆藍色放大鏡按鈕：開/關「搜尋品項」輸入框。
// 沒選分類就先提醒使用者選分類，因為搜尋是針對目前分類底下的品項。
window.toggleItemSearch = function () {
  if (!pickerCurrentCategory) {
    showAppAlert("請先在上方選擇一個分類，才能搜尋品項！");
    return;
  }

  const box = document.getElementById("item_picker_search_box");
  const isHidden = box.classList.contains("hidden");

  if (isHidden) {
    box.classList.remove("hidden");
    const input = document.getElementById("picker_search_input");
    if (input) {
      input.value = pickerSearchQuery;
      input.focus();
    }
  } else {
    box.classList.add("hidden");
    const input = document.getElementById("picker_search_input");
    if (input) input.value = "";
    pickerSearchQuery = "";
    pickerCurrentPage = 1;
    renderPickerCatalogList();
  }
};

// 搜尋框輸入時即時篩選，並自動跳回第一頁
window.onPickerSearchInput = function (value) {
  pickerSearchQuery = value.trim().toLowerCase();
  pickerCurrentPage = 1;
  renderPickerCatalogList();
};

// 上一頁 / 下一頁
window.changePickerPage = function (delta) {
  pickerCurrentPage += delta;
  renderPickerCatalogList();
};

// 直接跳到第一頁 / 最後一頁（PageUp／PageDown 快捷鍵用）。
// 最後一頁不用先算出總頁數，交給 renderPickerCatalogList() 內部的邊界檢查去夾住即可。
window.jumpPickerToFirstPage = function () {
  pickerCurrentPage = 1;
  renderPickerCatalogList();
};

window.jumpPickerToLastPage = function () {
  pickerCurrentPage = Number.MAX_SAFE_INTEGER;
  renderPickerCatalogList();
};

// 新增一筆品項到目前分類的共用清單。寫入 Firebase 後不用手動更新畫面：
// 上面已經用 onValue 掛了即時監聽，這筆資料一寫入，所有裝置的清單就會自動同步出現。
window.submitNewCatalogItem = async function () {
  if (!pickerCurrentCategory) return;

  const nameInput = document.getElementById("picker_new_name");
  const priceInput = document.getElementById("picker_new_price");
  const name = nameInput.value.trim();
  const price = Number(priceInput.value);

  if (!name) {
    showAppAlert("請輸入項目名稱！");
    nameInput.focus();
    return;
  }
  if (priceInput.value === "" || isNaN(price) || price < 0) {
    showAppAlert("請輸入正確的單價！");
    priceInput.focus();
    return;
  }

  try {
    const newRef = push(ref(db, "itemCatalog/" + pickerCurrentCategory));
    await set(newRef, { name, price });
    nameInput.value = "";
    priceInput.value = "";
    nameInput.focus();
  } catch (err) {
    console.error("新增品項到分類失敗：", err);
    showAppAlert(
      `新增失敗：${
        err.code || err.message || "未知錯誤"
      }\n請確認 Firebase 規則是否允許寫入 itemCatalog，或檢查網路連線後再試一次！`
    );
  }
};

// 品項清單：每一張卡片有「－ 數量 ＋」，數量完全用點的，不用打字。
// 把字串放進 HTML 屬性（例如 value="..."）前先跳脫特殊字元，
// 避免品項名稱裡剛好有引號時把畫面弄壞。
// 依庫存量給不同顏色的標籤：沒庫存（≤紅色門檻）＝紅底，庫存偏低（≤黃色門檻）＝
// 黃底，充足＝綠底。門檻可以在「設定 → 一般 → 進貨系統設定」裡調整。
function stockBadgeClass(stock) {
  if (stock <= appStockRedThreshold) return "bg-red-100 text-red-700";
  if (stock <= appStockYellowThreshold) return "bg-yellow-100 text-yellow-700";
  return "bg-green-100 text-green-700";
}

function escapeAttr(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// 品項改名或刪除後，購物車裡如果剛好選了同一項，名稱要跟著同步顯示。
function syncCartWithCatalog() {
  let cartChanged = false;
  Object.keys(pickerCart).forEach((key) => {
    const [cat, id] = key.split("::");
    if (cat !== pickerCurrentCategory) return;
    const catalogItem = pickerCatalogItems[id];
    if (catalogItem && pickerCart[key].name !== catalogItem.name) {
      pickerCart[key].name = catalogItem.name;
      cartChanged = true;
    }
  });
  if (cartChanged) renderPickerCart();
}

function renderPickerCatalogList() {
  const listEl = document.getElementById("item_picker_list");
  let entries = Object.entries(pickerCatalogItems);

  // 有搜尋關鍵字就先依品項名稱篩選（不分大小寫）
  if (pickerSearchQuery) {
    entries = entries.filter(([, item]) =>
      (item.name || "").toLowerCase().includes(pickerSearchQuery)
    );
  }

  if (entries.length === 0) {
    listEl.innerHTML = pickerSearchQuery
      ? `<div class="text-center text-gray-400 py-16">找不到符合「${escapeAttr(
          pickerSearchQuery
        )}」的品項</div>`
      : `<div class="text-center text-gray-400 py-16">此分類尚無品項，請點右上角的「＋」新增第一筆</div>`;
    return;
  }

  // 依 appPickerPageSize 分頁，避免單一分類品項數量太多（例如 300 多筆）時畫面爆版
  const totalPages = Math.max(1, Math.ceil(entries.length / appPickerPageSize));
  if (pickerCurrentPage > totalPages) pickerCurrentPage = totalPages;
  if (pickerCurrentPage < 1) pickerCurrentPage = 1;
  const startIdx = (pickerCurrentPage - 1) * appPickerPageSize;
  const pageEntries = entries.slice(startIdx, startIdx + appPickerPageSize);

  const paginationHtml =
    totalPages > 1
      ? `
    <div class="flex items-center justify-center gap-3 mt-5 pb-2">
      <button onclick="changePickerPage(-1)" ${
        pickerCurrentPage <= 1 ? "disabled" : ""
      }
        class="px-4 py-2 bg-gray-200 rounded font-bold hover:bg-gray-300 disabled:opacity-40 disabled:cursor-not-allowed transition">上一頁</button>
      <span class="text-gray-500 font-bold text-sm">第 ${pickerCurrentPage} / ${totalPages} 頁（共 ${
          entries.length
        } 筆）</span>
      <button onclick="changePickerPage(1)" ${
        pickerCurrentPage >= totalPages ? "disabled" : ""
      }
        class="px-4 py-2 bg-gray-200 rounded font-bold hover:bg-gray-300 disabled:opacity-40 disabled:cursor-not-allowed transition">下一頁</button>
    </div>`
      : "";

  listEl.innerHTML = `
    <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
      ${pageEntries
        .map(([id, item]) => {
          const cartKey = pickerCurrentCategory + "::" + id;
          const qty = (pickerCart[cartKey] && pickerCart[cartKey].qty) || 0;
          const priceValue = item.price;
          const isUsedBefore = pickerUsedItemNames.has(
            String(item.name || "").trim()
          );
          return `
        <div class="border-2 ${
          qty > 0
            ? "border-teal-500 bg-teal-50"
            : isUsedBefore
            ? "border-yellow-400"
            : "border-gray-200 bg-white"
        } rounded-lg p-3 flex flex-col transition relative" ${
            qty === 0 && isUsedBefore
              ? 'style="background-color: #fef08a"'
              : ""
          }>
          ${
            isUsedBefore
              ? `<span title="這台車以前用過這個品項" class="absolute -top-2 -left-2 text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow" style="background-color: #facc15; color: #713f12">曾用過</span>`
              : ""
          }
          <button onclick="deleteCatalogItem('${id}')" title="刪除這個品項（永久生效，所有人都會消失）"
            class="absolute top-1.5 right-1.5 text-gray-300 hover:text-red-500 w-6 h-6 flex items-center justify-center rounded-full hover:bg-red-50 transition text-sm font-bold">✕</button>

          <input type="text" value="${escapeAttr(item.name)}"
            onchange="updateCatalogItemName('${id}', this.value)"
            title="改名後會永久同步給所有人"
            class="font-bold text-gray-800 mb-2 pr-6 border-2 border-transparent hover:border-gray-200 focus:border-blue-500 focus:outline-none rounded px-1 -mx-1" />

          <div class="flex items-center gap-1 mb-2">
            <label class="text-sm text-gray-500 flex-shrink-0">單價 $</label>
            <input type="number" min="0" value="${priceValue}"
              onchange="updatePickerItemPrice('${id}', this.value)"
              title="改單價後會永久同步給所有人"
              class="border-2 border-gray-300 rounded px-2 py-1 w-full text-gray-800 font-bold text-right focus:border-blue-500 focus:outline-none" />
          </div>
          ${
            NO_STOCK_CATEGORIES.has(pickerCurrentCategory)
              ? ""
              : `<div class="flex items-center gap-1 mb-3 text-sm">
                  <label class="text-gray-500 flex-shrink-0">目前庫存</label>
                  <input type="number" min="0" value="${getSharedStock(item.name)}"
                    onchange="updatePickerItemStock('${id}', this.value)"
                    title="直接輸入盤點後的正確庫存數字（同名稱商品共用同一個庫存數字）"
                    class="border-2 rounded px-2 py-1 w-20 text-right font-black focus:border-blue-500 focus:outline-none ${stockBadgeClass(
                      getSharedStock(item.name)
                    )}" />
                </div>`
          }

          <div class="flex items-center justify-between mt-auto pt-1">
            <button onclick="changePickerCartQty('${id}', -1)"
              class="bg-red-500 hover:bg-red-600 active:scale-90 text-white w-12 h-12 rounded-full font-black text-2xl leading-none shadow-md transition flex items-center justify-center flex-shrink-0">－</button>
            <span class="font-black text-2xl w-10 text-center">${qty}</span>
            <button onclick="changePickerCartQty('${id}', 1)"
              class="bg-black hover:bg-gray-800 active:scale-90 text-white w-12 h-12 rounded-full font-black text-2xl leading-none shadow-md transition flex items-center justify-center flex-shrink-0">＋</button>
          </div>
        </div>`;
        })
        .join("")}
    </div>
    ${paginationHtml}
  `;
}

// 改品項名稱：直接寫回 Firebase 共用的 itemCatalog，永久生效。
// 不用手動更新畫面，onValue 監聽收到新資料會自動重畫，
// 之後任何人打開這個分類看到的都會是改過的新名稱。
window.updateCatalogItemName = async function (id, newName) {
  const name = newName.trim();
  if (!pickerCurrentCategory) return;

  if (!name) {
    showAppAlert("品項名稱不能空白！");
    renderPickerCatalogList(); // 還原成原本的名稱
    return;
  }

  try {
    await update(ref(db, "itemCatalog/" + pickerCurrentCategory + "/" + id), {
      name,
    });
  } catch (err) {
    console.error("修改品項名稱失敗：", err);
    showAppAlert(`修改名稱失敗：${err.code || err.message || "未知錯誤"}`);
    renderPickerCatalogList(); // 失敗就還原顯示
  }
};

// 刪除品項：從 Firebase 共用清單永久移除，所有人都會同步看不到這個品項。
window.deleteCatalogItem = async function (id) {
  if (!pickerCurrentCategory) return;
  const item = pickerCatalogItems[id];
  const displayName = item ? item.name : "此品項";

  const confirmed = await showAppConfirm(
    `確定要刪除「${displayName}」嗎？\n刪除後所有人都會看不到這個品項，且無法復原！`
  );
  if (!confirmed) return;

  try {
    await remove(ref(db, "itemCatalog/" + pickerCurrentCategory + "/" + id));

    const cartKey = pickerCurrentCategory + "::" + id;
    if (pickerCart[cartKey]) {
      delete pickerCart[cartKey];
      renderPickerCart();
    }
  } catch (err) {
    console.error("刪除品項失敗：", err);
    showAppAlert(`刪除失敗：${err.code || err.message || "未知錯誤"}`);
  }
};

// 使用者在這張卡片上改單價：直接寫回 Firebase 共用的 itemCatalog，永久生效
// （做法比照改品項名稱 updateCatalogItemName），所以就算切換到別的分類再切回來、
// 或別台電腦打開，看到的都會是改過的新單價，不會被重置掉。
window.updatePickerItemPrice = async function (id, value) {
  if (!pickerCurrentCategory) return;
  const price = Number(value);
  if (value === "" || isNaN(price) || price < 0) {
    showAppAlert("請輸入正確的單價！");
    renderPickerCatalogList();
    return;
  }

  // 如果這個品項已經在購物車裡了，單價要一起同步更新
  const cartKey = pickerCurrentCategory + "::" + id;
  if (pickerCart[cartKey]) {
    pickerCart[cartKey].price = price;
    renderPickerCart();
  }

  try {
    await update(ref(db, "itemCatalog/" + pickerCurrentCategory + "/" + id), {
      price,
    });
  } catch (err) {
    console.error("修改單價失敗：", err);
    showAppAlert(`修改單價失敗：${err.code || err.message || "未知錯誤"}`);
    renderPickerCatalogList(); // 失敗就還原顯示
  }
};

// 使用者在這張卡片上直接修正庫存數字（跟「進貨/庫存管理」頁面的盤點修正是同一套邏輯，
// 見下方 setStockDirect），不用切開另一個畫面，選項目的當下發現數字不對就能直接改。
// 因為庫存現在依名稱共用，這裡改的數字，其他分類裡同名稱的商品也會一起變。
window.updatePickerItemStock = async function (id, value) {
  if (!pickerCurrentCategory) return;
  const newStock = Number(value);
  if (value === "" || isNaN(newStock) || newStock < 0) {
    showAppAlert("請輸入 0 以上的數字！");
    renderPickerCatalogList();
    return;
  }

  const item = pickerCatalogItems[id];
  const itemName = item ? item.name : "";
  const before = getSharedStock(itemName);
  const delta = newStock - before;
  if (delta === 0) return;

  try {
    await adjustItemStock(itemName, delta, {
      category: pickerCurrentCategory,
      itemId: id,
      note: "維修選單手動盤點修正",
    });
  } catch (err) {
    console.error("修正庫存失敗：", err);
    showAppAlert(`修正庫存失敗：${err.code || err.message || "未知錯誤"}`);
    renderPickerCatalogList(); // 失敗就還原顯示
  }
};

// 用點的來調整數量（不開放打字輸入數量），delta 是 +1 或 -1
window.changePickerCartQty = function (id, delta) {
  if (!pickerCurrentCategory) return;
  const item = pickerCatalogItems[id];
  if (!item) return;

  const cartKey = pickerCurrentCategory + "::" + id;
  const current = pickerCart[cartKey];
  const nextQty = (current ? current.qty : 0) + delta;
  const price = item.price;

  if (nextQty <= 0) {
    delete pickerCart[cartKey];
  } else {
    pickerCart[cartKey] = {
      category: pickerCurrentCategory,
      name: item.name,
      price,
      qty: nextQty,
    };
  }

  renderPickerCatalogList();
  renderPickerCart();
};

function renderPickerCart() {
  const cartEl = document.getElementById("item_picker_cart");
  const totalEl = document.getElementById("item_picker_cart_total");
  const confirmBtn = document.getElementById("item_picker_confirm_btn");
  const entries = Object.entries(pickerCart);
  const hasItems = entries.length > 0;

  if (!hasItems) {
    cartEl.innerHTML = `<span class="text-gray-400 text-sm italic">尚未選擇任何項目</span>`;
    totalEl.textContent = "";
  } else {
    let total = 0;
    cartEl.innerHTML = entries
      .map(([, it]) => {
        total += it.price * it.qty;
        return `
        <span class="bg-teal-100 text-teal-800 font-bold px-3 py-1.5 rounded-md border border-teal-300 text-sm">
          [${it.category}] ${it.name} x${it.qty}
        </span>`;
      })
      .join("");
    totalEl.textContent = `小計 $${total}`;
  }

  // 直接設定 style（不靠 bg-teal-700 這個 class，這個 class 在部分環境會整個失效
  // 讓按鈕變成看不到文字/看不到底色），確保「可以按」跟「不能按」兩種狀態一定看得清楚。
  confirmBtn.disabled = !hasItems;
  confirmBtn.classList.toggle("cursor-pointer", hasItems);
  confirmBtn.classList.toggle("cursor-not-allowed", !hasItems);
  if (hasItems) {
    confirmBtn.style.backgroundColor = "#0f766e";
    confirmBtn.style.color = "#ffffff";
  } else {
    confirmBtn.style.backgroundColor = "#d1d5db";
    confirmBtn.style.color = "#6b7280";
  }
}

// 把選單裡點好的項目，一次全部加進維修項目表格（鎖定列，含分類），並補回一列空白列繼續手動輸入。
window.confirmItemPickerSelection = function () {
  const entries = Object.values(pickerCart);
  if (entries.length === 0) return;

  const rows = document.querySelectorAll("#repair_items_body tr");
  if (rows.length > 0) {
    const lastRow = rows[rows.length - 1];
    const nameInput = lastRow.querySelector(".repair_item_name");
    // 如果表格最下面那一列還沒填、也還沒鎖定，先移除，等等把選單品項加完再補回空白列
    if (nameInput && !nameInput.readOnly && !nameInput.value.trim()) {
      lastRow.remove();
    }
  }

  entries.forEach((it) => {
    addLockedRepairItemRow(it.name, it.qty, it.price, it.category);
  });

  recalcRepairTotal();

  pickerCart = {};
  closeItemPicker();
};

// ===================================================================
// 📦 進貨系統（庫存管理）
//
// 概念：itemCatalog/{分類}/{品項ID} 這個原本就存在的共用品項庫，
// 現在每個品項多存一個 stock 欄位（目前庫存量）。這裡負責：
//   1. 讓店家在「進貨」畫面把買回來的零件數量加進庫存（也可以直接
//      改成盤點後的正確數字），每一筆異動都記一筆 stockLogs 留底。
//   2. 客戶系統（維修項目選單）在同一個 itemCatalog 資料上，
//      直接把 stock 欄位秀出來，庫存量就自動同步，不用額外同步邏輯。
//   3. 維修紀錄實際存檔時，自動把用掉的品項數量從庫存扣掉
//      （見 deductStockForRepairItems，在 saveRepairRecord 呼叫）。
//
// 用 runTransaction 而不是先 get() 再 set()，是因為同一時間可能有
// 兩台電腦同時進貨或同時扣庫存，用交易才能保證數字一定正確，不會互相蓋掉。
// ===================================================================

let stockInCurrentCategory = null;
let stockInCatalogUnsubscribe = null;
let stockInCatalogItems = {}; // {pushId: {name, price}}（stock 欄位已經搬到 itemStock/，不再從這裡讀）
let stockInSearchQuery = "";
let stockInLogUnsubscribe = null;
let stockInCurrentPage = 1; // 進貨系統目前分頁頁碼
const STOCK_IN_PAGE_SIZE = 8; // 進貨系統固定一頁 8 筆，跟品項選單的「一頁幾筆」設定分開，不共用

// ------------------------------------------------------------------
// 📦 商品庫存「依名稱共用」：不管同一個名稱的商品出現在哪個分類（例如
// 油品跟輪胎剛好都有一項叫「1」），庫存都是同一個數字、扣一次兩邊一起少。
// 庫存從原本存在 itemCatalog/{分類}/{品項ID}/stock，改成一個獨立、只依
// 「名稱」分的共用表：itemStock/{名稱編碼後的key} = 目前庫存數字。
// ------------------------------------------------------------------
let itemStockMap = {}; // {stockKey: 數字} 全店共用的商品庫存，key 是 stockKeyForName(name) 編碼後的結果
let itemStockUnsubscribe = null;

// 把商品名稱轉成合法又唯一的 Firebase key。RTDB 的 key 不能包含 . # $ [ ] /，
// encodeURIComponent 會處理掉 # $ [ ] / 空白等符號，但「.」它不會跳脫，
// 所以另外把「.」也手動轉掉，這樣中文、英數字、符號的品名都能安全轉成 key，
// 而且同一個名稱（trim 後完全一樣）永遠對應到同一把 key，這就是「依名稱共用」的關鍵。
function stockKeyForName(name) {
  const trimmed = String(name == null ? "" : name).trim();
  return encodeURIComponent(trimmed).replace(/\./g, "%2E");
}

// 依名稱查目前庫存數字，畫面上任何要顯示庫存的地方都呼叫這個，
// 保證分類選單、進貨畫面看到的是同一份數字。
function getSharedStock(name) {
  return Number(itemStockMap[stockKeyForName(name)]) || 0;
}

// ============================================================
// ✉️ 通知信箱
// 目前只有一種通知：庫存偏低／缺貨（跟「進貨」畫面同一套 <=3 的門檻，
// 兩邊看到的顏色/數字才會一致）。之後如果要加別種通知，從
// buildLowStockNotifications() 旁邊加一個 build 函式、在 renderMailboxList()
// 裡合併進 notifications 陣列即可，紅點跟開關視窗的邏輯都不用改。
// ============================================================
let mailboxCatalogMap = {}; // { 商品名稱(trim後): 分類 }，用來排除「工資」這種不追蹤庫存的服務項目
let mailboxCatalogUnsubscribe = null;

function setupMailboxCatalogListener() {
  if (mailboxCatalogUnsubscribe) return;
  mailboxCatalogUnsubscribe = onValue(
    ref(db, "itemCatalog"),
    (snap) => {
      const map = {};
      if (snap.exists()) {
        snap.forEach((catSnap) => {
          const category = catSnap.key;
          catSnap.forEach((itemSnap) => {
            const item = itemSnap.val() || {};
            const name = String(item.name || "").trim();
            if (!name) return;
            map[name] = category;
          });
        });
      }
      mailboxCatalogMap = map;
      updateMailboxBadge();
      const mailboxOverlay = document.getElementById("mailbox_overlay");
      if (mailboxOverlay && !mailboxOverlay.classList.contains("hidden")) {
        renderMailboxList();
      }
    },
    (err) => {
      console.error("讀取品項清單失敗（通知信箱）：", err);
    }
  );
}

// 算出目前所有「庫存偏低或缺貨」的商品（門檻用「進貨系統設定」裡的通知
// 門檻，可在設定頁調整），「工資」這種服務項目不追蹤庫存，排除掉。
function buildLowStockNotifications() {
  const list = [];
  Object.keys(mailboxCatalogMap).forEach((name) => {
    const category = mailboxCatalogMap[name];
    if (NO_STOCK_CATEGORIES.has(category)) return;
    const stock = getSharedStock(name);
    if (stock <= appStockNotifyThreshold) list.push({ name, category, stock });
  });
  // 缺貨（0）排最前面，數字小的排前面，方便店家優先處理要先補的貨
  list.sort((a, b) => a.stock - b.stock || a.name.localeCompare(b.name, "zh-Hant"));
  return list;
}

// 只要有任何一項通知，信箱圖示右上角就顯示紅點；一項都沒有就隱藏。
function updateMailboxBadge() {
  const dot = document.getElementById("mailbox_badge_dot");
  if (!dot) return;
  dot.classList.toggle("hidden", buildLowStockNotifications().length === 0);
}

window.openMailboxModal = function () {
  const overlay = document.getElementById("mailbox_overlay");
  if (!overlay) return;
  overlay.classList.remove("hidden");
  overlay.classList.add("flex");
  renderMailboxList();
};

window.closeMailboxModal = function () {
  const overlay = document.getElementById("mailbox_overlay");
  if (!overlay) return;
  overlay.classList.add("hidden");
  overlay.classList.remove("flex");
};

function renderMailboxList() {
  const listEl = document.getElementById("mailbox_list");
  if (!listEl) return;
  const notifications = buildLowStockNotifications();

  if (notifications.length === 0) {
    listEl.innerHTML = `<div class="text-center text-gray-400 py-10">目前沒有通知，庫存都很充足</div>`;
    return;
  }

  listEl.innerHTML = notifications
    .map((n) => {
      const isOut = n.stock <= appStockRedThreshold;
      return `
        <div class="flex items-center justify-between bg-white border border-gray-200 rounded-lg px-4 py-3 mb-2 shadow-sm">
          <div>
            <p class="font-bold text-gray-800">${escapeAttr(n.name)}</p>
            <p class="text-xs text-gray-400">分類：${escapeAttr(n.category || "—")}</p>
          </div>
          <span class="px-3 py-1 rounded-full text-sm font-bold flex-shrink-0 ${
            isOut ? "bg-red-100 text-red-700" : "bg-yellow-100 text-yellow-700"
          }">
            ${isOut ? "已缺貨" : `庫存剩 ${n.stock}`}
          </span>
        </div>
      `;
    })
    .join("");
}


// 「進貨」畫面，庫存數字一有異動，兩邊畫面都會立刻同步重新整理。
function setupItemStockListener() {
  if (itemStockUnsubscribe) return;
  itemStockUnsubscribe = onValue(
    ref(db, "itemStock"),
    (snap) => {
      itemStockMap = snap.exists() ? snap.val() : {};
      const pickerOverlay = document.getElementById("item_picker_overlay");
      if (
        pickerOverlay &&
        !pickerOverlay.classList.contains("hidden") &&
        pickerCurrentCategory
      ) {
        renderPickerCatalogList();
      }
      const stockInOverlay = document.getElementById("stock_in_overlay");
      if (
        stockInOverlay &&
        !stockInOverlay.classList.contains("hidden") &&
        stockInCurrentCategory
      ) {
        renderStockInList();
      }
      updateMailboxBadge();
      const mailboxOverlay = document.getElementById("mailbox_overlay");
      if (mailboxOverlay && !mailboxOverlay.classList.contains("hidden")) {
        renderMailboxList();
      }
    },
    (err) => {
      console.error("讀取商品庫存失敗：", err);
    }
  );
}

// 🔁 一次性搬家：把舊制「每個分類各自的 stock 欄位」依名稱加總合併成新制的
// itemStock/{key}（例如油品的「1」有 5 個、輪胎的「1」有 3 個，搬完會變成
// 共用的「1」有 8 個）。用 appSettings/itemStockMigrated 這個旗標＋交易卡住，
// 保證不管幾台電腦、開幾次程式，全店只會合併這一次，不會重複疊加。
async function migrateItemStockIfNeeded() {
  try {
    const flagRef = ref(db, "appSettings/itemStockMigrated");
    const result = await runTransaction(flagRef, (current) => {
      if (current) return; // 已經搬過家了，中止交易，不覆寫也不重複搬
      return true;
    });

    // 沒有真的把旗標從「還沒搬」改成「搬好了」，代表這台電腦不是搬家的那一個
    // （可能早就搬過、也可能剛好跟另一台電腦同時搬），不用再做事。
    if (!result.committed) return;

    const snap = await get(ref(db, "itemCatalog"));
    if (!snap.exists()) return;

    const totals = {}; // { 商品名稱(trim後)：加總後的庫存數字 }
    snap.forEach((catSnap) => {
      catSnap.forEach((itemSnap) => {
        const item = itemSnap.val() || {};
        const name = String(item.name || "").trim();
        if (!name) return;
        totals[name] = (totals[name] || 0) + (Number(item.stock) || 0);
      });
    });

    const updates = {};
    Object.entries(totals).forEach(([name, total]) => {
      updates["itemStock/" + stockKeyForName(name)] = total;
    });

    if (Object.keys(updates).length > 0) {
      await update(ref(db), updates);
    }
    console.log("庫存搬家完成：已將各分類同名稱商品的庫存加總合併為共用庫存。");
  } catch (err) {
    console.error("庫存搬家失敗：", err);
  }
}

// 找出目前登入的人，寫進進貨/扣庫存紀錄裡方便日後追查是誰經手的
function currentOperatorLabel() {
  return (auth.currentUser && auth.currentUser.email) || "未登入";
}

// 對某個「商品名稱」的共用庫存做加／減（delta 可正可負），用交易確保多人
// 同時操作也不會算錯，並且寫一筆 stockLogs 留底。回傳異動前後的數字。
// 注意：現在是依名稱操作（不是依分類＋品項ID），同名稱不管在哪個分類扣，
// 動到的都是同一個數字。
async function adjustItemStock(itemName, delta, meta = {}) {
  const name = String(itemName || "").trim();
  const stockRef = ref(db, "itemStock/" + stockKeyForName(name));
  let before = 0;
  let after = 0;

  const result = await runTransaction(stockRef, (current) => {
    before = Number(current) || 0;
    after = Math.max(0, before + delta); // 庫存不允許變成負數
    return after;
  });

  if (!result.committed) {
    throw new Error("庫存交易失敗，請重新整理後再試一次");
  }

  try {
    await push(ref(db, "stockLogs"), {
      itemName: name,
      category: meta.category || "", // 只是紀錄「這次是從哪個分類操作的」，不影響庫存數字本身
      itemId: meta.itemId || "",
      type: delta >= 0 ? "in" : "out",
      qty: Math.abs(delta),
      before,
      after,
      note: meta.note || "",
      operator: currentOperatorLabel(),
      at: Date.now(),
    });
  } catch (err) {
    // 紀錄寫失敗不影響庫存本身已經異動成功，只在主控台留下錯誤方便排查
    console.error("寫入進貨/扣庫存紀錄失敗：", err);
  }

  return { before, after };
}

// 維修紀錄實際存檔（新增一筆，不是補登里程的更新）成功後呼叫：
// 依「名稱」比對是否為共用品項庫裡的商品（不分類別），把用掉的數量從
// 共用庫存扣掉。找不到同名商品（例如手動打字輸入、不是從選單點的）就跳過，
// 不影響維修紀錄本身。任何一筆扣庫存失敗都只記錄錯誤、不拋出例外。
async function deductStockForRepairItems(items) {
  if (!Array.isArray(items) || items.length === 0) return;

  // 因為現在比對不分類別，這裡一次把整個 itemCatalog（所有分類）讀出來，
  // 只是用來確認「這個名稱有沒有在任何分類的品項庫裡出現過」，
  // 同一次存檔只讀一次，省流量。
  let allCatalogNames = null;

  for (const it of items) {
    const category = it.category;
    if (!category || NO_STOCK_CATEGORIES.has(category)) continue;
    const qty = Number(it.qty) || 0;
    if (qty <= 0) continue;

    const targetName = String(it.name || "").trim();
    if (!targetName) continue;

    try {
      if (!allCatalogNames) {
        const snap = await get(ref(db, "itemCatalog"));
        allCatalogNames = new Set();
        if (snap.exists()) {
          snap.forEach((catSnap) => {
            catSnap.forEach((itemSnap) => {
              const n = String((itemSnap.val() || {}).name || "").trim();
              if (n) allCatalogNames.add(n);
            });
          });
        }
      }
      if (!allCatalogNames.has(targetName)) continue; // 任何分類都找不到同名品項，可能是手動輸入的，不扣庫存

      await adjustItemStock(targetName, -qty, {
        category,
        note: "維修用料自動扣庫存",
      });
    } catch (err) {
      console.error(`扣庫存失敗（${category} / ${it.name}）：`, err);
    }
  }
}

window.openStockInModal = function () {
  stockInCurrentCategory = null;
  stockInCatalogItems = {};
  stockInSearchQuery = "";
  stockInCurrentPage = 1;
  const input = document.getElementById("stock_in_search_input");
  if (input) input.value = "";

  renderStockInCategoryButtons();
  document.getElementById("stock_in_log_panel").classList.add("hidden");

  const searchBoxEl = document.getElementById("stock_in_search_box");
  searchBoxEl.classList.add("hidden");

  const formEl = document.getElementById("stock_in_new_item_form");
  formEl.classList.add("hidden");
  formEl.innerHTML = "";

  const overlay = document.getElementById("stock_in_overlay");
  overlay.classList.remove("hidden");
  overlay.classList.add("flex");

  // 預設先帶出「油品」分類，不用使用者自己再點一次
  window.selectStockInCategory("油品");
};

window.closeStockInModal = function () {
  if (stockInCatalogUnsubscribe) stockInCatalogUnsubscribe();
  stockInCatalogUnsubscribe = null;
  if (stockInLogUnsubscribe) stockInLogUnsubscribe();
  stockInLogUnsubscribe = null;

  const overlay = document.getElementById("stock_in_overlay");
  overlay.classList.add("hidden");
  overlay.classList.remove("flex");
};

function renderStockInCategoryButtons() {
  const el = document.getElementById("stock_in_categories");
  el.innerHTML = STOCK_IN_CATEGORIES.map(
      (cat) => `
    <button
      data-cat="${cat}"
      onclick="selectStockInCategory('${cat}')"
      class="stockin_cat_btn flex-shrink-0 whitespace-nowrap px-3 py-1.5 text-sm rounded-full font-bold border-2 border-gray-300 bg-gray-50 text-gray-600 hover:border-red-300 transition"
    >${cat}</button>
  `
    )
    .join("");
}

window.selectStockInCategory = function (cat) {
  stockInCurrentCategory = cat;
  stockInSearchQuery = "";
  stockInCurrentPage = 1;
  const input = document.getElementById("stock_in_search_input");
  if (input) input.value = "";

  const searchBoxEl = document.getElementById("stock_in_search_box");
  searchBoxEl.classList.add("hidden");

  const formEl = document.getElementById("stock_in_new_item_form");
  formEl.classList.add("hidden");
  formEl.innerHTML = "";

  document.querySelectorAll(".stockin_cat_btn").forEach((btn) => {
    const active = btn.dataset.cat === cat;
    btn.classList.toggle("bg-red-50", active);
    btn.classList.toggle("text-red-600", active);
    btn.classList.toggle("border-red-500", active);
    btn.classList.toggle("bg-gray-50", !active);
    btn.classList.toggle("text-gray-600", !active);
    btn.classList.toggle("border-gray-300", !active);
  });

  document.getElementById("stock_in_list").innerHTML = `
    <div class="text-center text-gray-400 py-16">
      <div class="w-8 h-8 border-4 border-gray-300 border-t-amber-600 rounded-full animate-spin-custom mx-auto mb-3"></div>
      載入分類品項中...
    </div>
  `;

  if (stockInCatalogUnsubscribe) stockInCatalogUnsubscribe();
  const catalogRef = ref(db, "itemCatalog/" + cat);
  stockInCatalogUnsubscribe = onValue(
    catalogRef,
    (snap) => {
      stockInCatalogItems = snap.exists() ? snap.val() : {};
      renderStockInList();
    },
    (err) => {
      console.error("讀取分類品項失敗：", err);
      document.getElementById("stock_in_list").innerHTML = `
        <div class="text-center text-red-500 py-16 px-4">
          <div class="font-bold mb-1">讀取「${cat}」品項失敗</div>
          <div class="text-sm text-gray-500">${err.code || err.message || "未知錯誤"}</div>
        </div>`;
    }
  );
};

window.onStockInSearchInput = function (value) {
  stockInSearchQuery = value.trim().toLowerCase();
  stockInCurrentPage = 1;
  renderStockInList();
};

// 點分類列旁邊那顆藍色放大鏡按鈕：開/關「搜尋品項」輸入框。
// 跟分類選單（item_picker）的搜尋按鈕是同一套邏輯，只是換了一組 id。
window.toggleStockInSearch = function () {
  if (!stockInCurrentCategory) {
    showAppAlert("請先在上方選擇一個分類，才能搜尋品項！");
    return;
  }

  const box = document.getElementById("stock_in_search_box");
  const isHidden = box.classList.contains("hidden");

  if (isHidden) {
    box.classList.remove("hidden");
    const input = document.getElementById("stock_in_search_input");
    if (input) {
      input.value = stockInSearchQuery;
      input.focus();
    }
  } else {
    box.classList.add("hidden");
    const input = document.getElementById("stock_in_search_input");
    if (input) input.value = "";
    stockInSearchQuery = "";
    stockInCurrentPage = 1;
    renderStockInList();
  }
};

// 渲染「新增商品」表單，跟分類選單的 renderPickerNewItemForm 是同一套排版，
// 只是輸入框 id 換一組（stock_in_new_...），並且送出後呼叫的是進貨系統自己那份
// submitNewStockInCatalogItem（避免跟分類選單共用同一組輸入框 id 互相干擾）。
function renderStockInNewItemForm(cat) {
  const wrap = document.getElementById("stock_in_new_item_form");
  wrap.classList.remove("hidden");
  wrap.innerHTML = `
    <div class="flex items-center gap-2 flex-wrap">
      <span class="text-sm font-bold text-yellow-700 flex-shrink-0">＋ 新增商品到「${cat}」：</span>
      <input id="stock_in_new_name" type="text" placeholder="項目名稱"
        class="border border-gray-300 rounded px-3 py-2 flex-1 min-w-[10rem]" />
      <input id="stock_in_new_price" type="number" min="0" placeholder="單價"
        class="border border-gray-300 rounded px-3 py-2 w-28" />
      <button onclick="submitNewStockInCatalogItem()"
        class="bg-yellow-500 text-white px-4 py-2 font-bold rounded hover:bg-yellow-600 transition flex-shrink-0">
        新增商品
      </button>
    </div>
  `;
}

// 點分類列旁邊那顆圓形「＋」按鈕：開/關「新增商品」表單。
window.toggleStockInNewItemForm = function () {
  if (!stockInCurrentCategory) {
    showAppAlert("請先在上方選擇一個分類，才能新增商品！");
    return;
  }

  const wrap = document.getElementById("stock_in_new_item_form");
  const isHidden = wrap.classList.contains("hidden");

  if (isHidden) {
    renderStockInNewItemForm(stockInCurrentCategory);
    const nameInput = document.getElementById("stock_in_new_name");
    if (nameInput) nameInput.focus();
  } else {
    wrap.classList.add("hidden");
    wrap.innerHTML = "";
  }
};

// 新增一筆商品到目前分類的共用品項庫（itemCatalog），初始庫存 0，
// 之後直接用畫面上的「進貨數量」把庫存補上去即可。跟分類選單的
// submitNewCatalogItem 是同一套邏輯，只是換一組輸入框 id。
window.submitNewStockInCatalogItem = async function () {
  if (!stockInCurrentCategory) return;

  const nameInput = document.getElementById("stock_in_new_name");
  const priceInput = document.getElementById("stock_in_new_price");
  const name = nameInput.value.trim();
  const price = Number(priceInput.value);

  if (!name) {
    showAppAlert("請輸入項目名稱！");
    nameInput.focus();
    return;
  }
  if (priceInput.value === "" || isNaN(price) || price < 0) {
    showAppAlert("請輸入正確的單價！");
    priceInput.focus();
    return;
  }

  try {
    const newRef = push(ref(db, "itemCatalog/" + stockInCurrentCategory));
    await set(newRef, { name, price });
    nameInput.value = "";
    priceInput.value = "";
    nameInput.focus();
  } catch (err) {
    console.error("新增商品失敗：", err);
    showAppAlert(
      `新增失敗：${
        err.code || err.message || "未知錯誤"
      }\n請確認 Firebase 規則是否允許寫入 itemCatalog，或檢查網路連線後再試一次！`
    );
  }
};

// 進貨系統上一頁 / 下一頁
window.changeStockInPage = function (delta) {
  stockInCurrentPage += delta;
  renderStockInList();
};

// 直接跳到第一頁 / 最後一頁（PageUp／PageDown 快捷鍵用）。
// 最後一頁不用先算出總頁數，交給 renderStockInList() 內部的邊界檢查去夾住即可。
window.jumpStockInToFirstPage = function () {
  stockInCurrentPage = 1;
  renderStockInList();
};

window.jumpStockInToLastPage = function () {
  stockInCurrentPage = Number.MAX_SAFE_INTEGER;
  renderStockInList();
};

function renderStockInList() {
  const listEl = document.getElementById("stock_in_list");
  if (!stockInCurrentCategory) {
    listEl.innerHTML = `<div class="text-center text-gray-400 py-16">請先在上方選擇一個分類</div>`;
    return;
  }

  let entries = Object.entries(stockInCatalogItems);
  if (stockInSearchQuery) {
    entries = entries.filter(([, item]) =>
      (item.name || "").toLowerCase().includes(stockInSearchQuery)
    );
  }

  if (entries.length === 0) {
    listEl.innerHTML = stockInSearchQuery
      ? `<div class="text-center text-gray-400 py-16">找不到符合「${escapeAttr(
          stockInSearchQuery
        )}」的品項</div>`
      : `<div class="text-center text-gray-400 py-16">此分類尚無商品，請點上方「＋」新增商品</div>`;
    return;
  }

  // 進貨系統固定一頁 8 筆，避免單一分類品項數量太多時畫面爆版
  const totalPages = Math.max(1, Math.ceil(entries.length / STOCK_IN_PAGE_SIZE));
  if (stockInCurrentPage > totalPages) stockInCurrentPage = totalPages;
  if (stockInCurrentPage < 1) stockInCurrentPage = 1;
  const startIdx = (stockInCurrentPage - 1) * STOCK_IN_PAGE_SIZE;
  const pageEntries = entries.slice(startIdx, startIdx + STOCK_IN_PAGE_SIZE);

  const paginationHtml =
    totalPages > 1
      ? `
    <div class="flex items-center justify-center gap-3 mt-5 pb-2">
      <button onclick="changeStockInPage(-1)" ${
        stockInCurrentPage <= 1 ? "disabled" : ""
      }
        class="px-4 py-2 bg-gray-200 rounded font-bold hover:bg-gray-300 disabled:opacity-40 disabled:cursor-not-allowed transition">上一頁</button>
      <span class="text-gray-500 font-bold text-sm">第 ${stockInCurrentPage} / ${totalPages} 頁（共 ${
          entries.length
        } 筆）</span>
      <button onclick="changeStockInPage(1)" ${
        stockInCurrentPage >= totalPages ? "disabled" : ""
      }
        class="px-4 py-2 bg-gray-200 rounded font-bold hover:bg-gray-300 disabled:opacity-40 disabled:cursor-not-allowed transition">下一頁</button>
    </div>`
      : "";

  listEl.innerHTML = `
    <div class="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-5 gap-3">
      ${pageEntries
        .map(([id, item]) => {
          const stock = getSharedStock(item.name);
          return `
        <div class="border-2 border-gray-200 bg-white rounded-lg p-3 flex flex-col gap-2">
          <div class="font-bold text-gray-800 truncate" title="${escapeAttr(item.name)}">${escapeAttr(
            item.name
          )}</div>
          <div class="text-xs text-gray-400">單價 $${Number(item.price) || 0}</div>

          <div class="flex items-center gap-1">
            <label class="text-xs text-gray-500 flex-shrink-0">目前庫存</label>
            <input type="number" value="${stock}"
              onchange="setStockDirect('${id}', this.value)"
              title="直接輸入盤點後的正確庫存數字（同名稱商品共用同一個庫存數字）"
              class="border-2 rounded px-2 py-1 w-full text-right font-black focus:border-blue-500 focus:outline-none ${stockBadgeClass(
                stock
              )}" />
          </div>

          <div class="flex items-center gap-1 pt-1 border-t border-gray-100">
            <input type="number" min="1" placeholder="進貨數量" id="stockin_qty_${id}"
              class="border border-gray-300 rounded px-2 py-1.5 w-full text-right focus:border-amber-500 focus:outline-none" />
            <button onclick="submitStockIn('${id}')"
              class="bg-amber-600 hover:bg-amber-700 active:scale-95 text-white px-3 py-1.5 rounded font-bold text-sm flex-shrink-0 transition">＋進貨</button>
          </div>
        </div>`;
        })
        .join("")}
    </div>
    ${paginationHtml}
  `;
}

// 進貨：把輸入框裡的數量「加」進現有共用庫存（例如這次補進 20 個機油濾芯，
// 不管等一下是在哪個分類扣，扣的都是這個共用數字）
window.submitStockIn = async function (id) {
  if (!stockInCurrentCategory) return;
  const input = document.getElementById("stockin_qty_" + id);
  const qty = Number(input.value);
  if (!input.value || isNaN(qty) || qty <= 0) {
    showAppAlert("請輸入大於 0 的進貨數量！");
    input.focus();
    return;
  }

  const item = stockInCatalogItems[id];
  const itemName = item ? item.name : "";
  try {
    const { after } = await adjustItemStock(itemName, qty, {
      category: stockInCurrentCategory,
      itemId: id,
      note: "進貨",
    });
    input.value = "";
    showAppAlert(`已進貨 ${qty} 個「${itemName}」，目前庫存：${after}`);
  } catch (err) {
    console.error("進貨失敗：", err);
    showAppAlert(`進貨失敗：${err.code || err.message || "未知錯誤"}`);
  }
};

// 盤點／直接修正庫存數字：跟進貨不同，這是「直接改成輸入的數字」，
// 常用在真的去倉庫數過、發現系統數字跟實際不一樣的時候。
// 因為庫存依名稱共用，這裡改的數字，其他分類裡同名稱的商品也會一起變。
window.setStockDirect = async function (id, value) {
  if (!stockInCurrentCategory) return;
  const newStock = Number(value);
  if (value === "" || isNaN(newStock) || newStock < 0) {
    showAppAlert("請輸入 0 以上的數字！");
    renderStockInList();
    return;
  }

  const item = stockInCatalogItems[id];
  const itemName = item ? item.name : "";
  const before = getSharedStock(itemName);
  const delta = newStock - before;
  if (delta === 0) return;

  try {
    await adjustItemStock(itemName, delta, {
      category: stockInCurrentCategory,
      itemId: id,
      note: "手動盤點修正",
    });
  } catch (err) {
    console.error("修正庫存失敗：", err);
    showAppAlert(`修正庫存失敗：${err.code || err.message || "未知錯誤"}`);
    renderStockInList();
  }
};

// 展開/收起最近 15 筆進貨與扣庫存紀錄，方便核對「這批到底進了多少、什麼時候扣的」
window.toggleStockInLog = function () {
  const panel = document.getElementById("stock_in_log_panel");
  const isHidden = panel.classList.contains("hidden");

  if (!isHidden) {
    panel.classList.add("hidden");
    if (stockInLogUnsubscribe) stockInLogUnsubscribe();
    stockInLogUnsubscribe = null;
    return;
  }

  panel.classList.remove("hidden");
  panel.innerHTML = `<div class="text-center text-gray-400 py-4 text-sm">載入中...</div>`;

  const logsQuery = query(ref(db, "stockLogs"), limitToLast(15));
  stockInLogUnsubscribe = onValue(
    logsQuery,
    (snap) => {
      if (!snap.exists()) {
        panel.innerHTML = `<div class="text-center text-gray-400 py-4 text-sm">還沒有任何進貨紀錄</div>`;
        return;
      }
      const entries = Object.values(snap.val()).sort((a, b) => b.at - a.at);
      panel.innerHTML = entries
        .map((log) => {
          const time = new Date(log.at).toLocaleString("zh-TW", {
            hour12: false,
          });
          const isIn = log.type === "in";
          return `
        <div class="flex items-center justify-between py-1.5 border-b border-blue-100 last:border-0 text-sm">
          <span class="text-gray-600">${time}・[${escapeAttr(log.category || "")}] ${escapeAttr(
            log.itemName || ""
          )}</span>
          <span class="font-bold ${isIn ? "text-green-600" : "text-red-600"}">${
            isIn ? "+" : "-"
          }${log.qty}（${log.before} → ${log.after}）</span>
        </div>`;
        })
        .join("");
    },
    (err) => {
      // 讀取失敗時（例如 Firebase 規則沒開放 stockLogs 路徑）不要讓面板一直卡在
      // 「載入中」，直接把真正的錯誤原因秀出來方便排查。
      console.error("讀取進貨紀錄失敗：", err);
      panel.innerHTML = `
        <div class="text-center text-red-500 py-4 text-sm">
          讀取進貨紀錄失敗：${err.code || err.message || "未知錯誤"}
        </div>`;
    }
  );
};

// -----------------------------------------------------------------
// ⌨️ 全域鍵盤快捷鍵：Ctrl/⌘+S 儲存、Ctrl/⌘+F 開啟分類選單裡的品項搜尋框、
// Insert 切換插入／覆蓋模式、F1~F3 切換分頁、分類選單內的 F1~F11／Ctrl+N／
// Enter／PageUp／PageDown，以及維修資料、顧客資訊、歷史維修紀錄各分頁的
// 專屬快捷鍵（詳見下方各區塊註解）
// -----------------------------------------------------------------

// 判斷目前焦點是不是「打字區域」（輸入框／文字框／下拉選單）。
// F 鍵、Ctrl 組合鍵不算一般字元，不會受影響，不用特別排除；
// 但 Enter、Shift+字母 這類本來就可能拿來打字的按鍵，要先確認
// 使用者不是正在打字，才觸發快捷鍵，避免蓋掉正常輸入。
function isTypingElement(el) {
  if (!el || !el.tagName) return false;
  const tag = el.tagName;
  if (tag === "TEXTAREA" || tag === "SELECT") return true;
  if (tag === "INPUT") {
    const type = (el.type || "text").toLowerCase();
    return !["button", "checkbox", "radio", "submit", "reset", "range", "color", "file"].includes(
      type
    );
  }
  return !!el.isContentEditable;
}

// 判斷目前焦點是不是「可以打字、也支援用游標位置覆蓋字元」的輸入框
// （number 輸入框在 Chromium 底下不支援 selectionStart/selectionEnd，排除掉）。
function isTextEntryElement(el) {
  if (!el || !el.tagName) return false;
  const tag = el.tagName;
  if (tag === "TEXTAREA") return true;
  if (tag === "INPUT") {
    const type = (el.type || "text").toLowerCase();
    return ["text", "search", "tel", "email", "url", "password"].includes(type);
  }
  return false;
}

// 插入／覆蓋模式：false＝插入（預設），true＝覆蓋。
// 在打字區域按 Insert 鍵輪流切換；覆蓋模式下打字會直接取代游標右邊的字元。
let insertOverwriteMode = false;

// Ctrl/⌘+S：依照目前畫面狀態，把對應的表單存檔。
// - 分類選單開著時不做任何事（那個畫面沒有「存檔」這個概念，避免誤觸）
// - 詳細資料頁「維修資料」分頁：等同按下「儲存維修資料」
// - 詳細資料頁「顧客資訊」分頁且正在編輯：等同按下「儲存」
function handleSaveShortcut() {
  const itemPicker = document.getElementById("item_picker_overlay");
  if (itemPicker && !itemPicker.classList.contains("hidden")) return;

  const detailPage = document.getElementById("detail_page");
  if (!detailPage || detailPage.classList.contains("hidden")) return; // 搜尋畫面沒有東西可存

  if (currentTab === "customer") {
    if (!customerEditMode) return; // 檢視模式沒有東西可存
    const saveBtn = document.getElementById("customer_save_btn");
    if (saveBtn && !saveBtn.disabled) window.saveCustomerInfo();
    return;
  }

  if (currentTab === "repair") {
    const saveBtn = document.getElementById("repair_save_btn");
    if (saveBtn && !saveBtn.disabled) window.saveRepairRecord(false);
  }
}

// Ctrl/⌘+F：分類選單開著時，開啟（或聚焦）品項名稱搜尋框，等同點擊放大鏡按鈕。
function handleFindShortcut() {
  const itemPicker = document.getElementById("item_picker_overlay");
  if (!itemPicker || itemPicker.classList.contains("hidden")) return;

  const searchBox = document.getElementById("item_picker_search_box");
  if (searchBox && searchBox.classList.contains("hidden")) {
    window.toggleItemSearch();
  } else {
    const input = document.getElementById("picker_search_input");
    if (input) input.focus();
  }
}

// F12 是否正被按住，供下面 F12 隱藏快捷鍵判斷用；insertPressedDuringF12Hold 用來
// 分辨「只按 F12」（開設定）跟「F12 + Insert」（開匯入舊系統資料）這兩種情況；
// homePressedDuringF12Hold 同理，用來分辨「F12 + Home」（開內建終端機）。
let f12KeyHeld = false;
let insertPressedDuringF12Hold = false;
let homePressedDuringF12Hold = false;
window.addEventListener("keyup", (event) => {
  if (event.key === "F12") {
    f12KeyHeld = false;
    // 放開 F12 的當下，如果剛剛沒有按過 Insert 或 Home，代表使用者是要開
    // 「設定」，不是要開「匯入舊系統資料」或「內建終端機」；一樣只在搜尋
    // 首頁才生效。
    if (
      !insertPressedDuringF12Hold &&
      !homePressedDuringF12Hold &&
      isHomeSearchScreenActive()
    ) {
      if (typeof window.openHiddenSettingsModal === "function") {
        window.openHiddenSettingsModal();
      }
    }
    insertPressedDuringF12Hold = false;
    homePressedDuringF12Hold = false;
  }
});

// 真實實體鍵盤監聽
window.addEventListener("keydown", (event) => {
  const mask = document.getElementById("login_mask");
  if (!mask || !mask.classList.contains("hidden")) return;

  // 隱藏快捷鍵（都只在「搜尋車牌／卡號」首頁生效）：
  // 單按 F12 → 開「設定」；F12 按住不放、再按 Insert → 開「匯入舊系統資料」；
  // F12 按住不放、再按 Home → 開「內建終端機」（sudo boss 系列指令）。
  // （畫面上都沒有按鈕，只留這幾組快捷鍵給知道的人用）
  if (event.key === "F12") {
    f12KeyHeld = true;
    insertPressedDuringF12Hold = false;
    homePressedDuringF12Hold = false;
  } else if (event.key === "Insert" && f12KeyHeld) {
    event.preventDefault();
    insertPressedDuringF12Hold = true;
    if (
      isHomeSearchScreenActive() &&
      typeof window.openAccessImportModal === "function"
    ) {
      window.openAccessImportModal();
    }
    return;
  } else if (event.key === "Home" && f12KeyHeld) {
    event.preventDefault();
    homePressedDuringF12Hold = true;
    if (
      isHomeSearchScreenActive() &&
      typeof window.openBossTerminal === "function"
    ) {
      window.openBossTerminal();
    }
    return;
  } else if (event.key === "Insert") {
    // 在打字區域按 Insert：切換插入／覆蓋模式（輪流切換），不管目前開著哪個畫面都先判斷，
    // 不是打字區域的話就不理會，交給下面各畫面自己的邏輯處理。
    if (isTextEntryElement(event.target)) {
      event.preventDefault();
      insertOverwriteMode = !insertOverwriteMode;
    }
    return;
  } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "b") {
    // Ctrl/⌘+B → 老闆系統快速入口：跳出密碼視窗，密碼正確就直接進業績報表圖形介面，
    // 不用像 F12+Home 那樣先開終端機再手動打 sudo boss。也只在首頁生效，避免誤觸。
    if (isHomeSearchScreenActive() && typeof window.openBossQuickAccess === "function") {
      event.preventDefault();
      window.openBossQuickAccess();
    }
    return;
  }

  // 自製提示／確認視窗開著時優先處理：Esc 視同取消／關閉，Enter 視同按下主要按鈕。
  if (isAppDialogOpen()) {
    if (event.key === "Escape") {
      event.preventDefault();
      if (appDialogEscHandler) appDialogEscHandler();
    } else if (event.key === "Enter") {
      event.preventDefault();
      const primaryBtn =
        document.getElementById("app_dialog_confirm_btn") ||
        document.getElementById("app_dialog_ok_btn");
      if (primaryBtn) primaryBtn.click();
    }
    return;
  }

  // Ctrl/⌘+S 與 Ctrl/⌘+F 優先攔截，蓋掉瀏覽器原生的「儲存網頁」／「頁面內尋找」，
  // 且不管目前在哪個畫面都先判斷一次（各自的函式內部會自行決定要不要有動作）。
  const key = event.key.toLowerCase();
  if ((event.ctrlKey || event.metaKey) && key === "s") {
    event.preventDefault();
    handleSaveShortcut();
    return;
  }
  if ((event.ctrlKey || event.metaKey) && key === "f") {
    event.preventDefault();
    handleFindShortcut();
    return;
  }

  const unsavedModal = document.getElementById("unsaved_changes_modal");
  if (unsavedModal && !unsavedModal.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.closeUnsavedChangesModal();
    }
    return;
  }

  const notesModal = document.getElementById("repair_notes_modal");
  if (notesModal && !notesModal.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.closeNotesModal(false);
    }
    return; // 備註是一般文字框，其餘按鍵交給瀏覽器原生輸入處理，不要被虛擬鍵盤攔截
  }

  const editPlateModal = document.getElementById("edit_plate_modal");
  if (editPlateModal && !editPlateModal.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.closeEditPlateModal();
    } else if (event.key === "Enter") {
      event.preventDefault();
      window.confirmEditVehiclePlate();
    }
    return; // 一般文字框，其餘按鍵交給瀏覽器原生輸入處理，不要被虛擬鍵盤攔截
  }

  const estimateChoiceModal = document.getElementById("estimate_choice_modal");
  if (estimateChoiceModal && !estimateChoiceModal.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.closeEstimateChoiceModal();
    }
    return;
  }

  const hiddenSettingsModal = document.getElementById("hidden_settings_modal");
  if (hiddenSettingsModal && !hiddenSettingsModal.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.closeHiddenSettingsModal();
    }
    return;
  }

  const bossRevenueModal = document.getElementById("boss_revenue_modal");
  if (bossRevenueModal && !bossRevenueModal.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.closeBossRevenueModal();
    }
    return;
  }

  const bossQuickAccessModal = document.getElementById("boss_quickaccess_modal");
  if (bossQuickAccessModal && !bossQuickAccessModal.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.closeBossQuickAccessModal();
    }
    return; // 一般文字輸入框，交給瀏覽器原生輸入處理，不要被首頁的虛擬鍵盤攔截
  }

  const bossForgotPasswordModal = document.getElementById("boss_forgot_password_modal");
  if (bossForgotPasswordModal && !bossForgotPasswordModal.classList.contains("hidden")) {
    // Esc／Enter 已經在各步驟輸入框自己的 onkeydown（handleBossForgotPasswordKeydown）
    // 處理掉了，這裡只要負責攔住，不要讓底下首頁搜尋的虛擬鍵盤搶走英文字母、
    // 數字等按鍵（不然打信箱／驗證碼／新密碼時，字會跑到車牌搜尋框去）。
    return;
  }

  const bossTerminalModal = document.getElementById("boss_terminal_modal");
  if (bossTerminalModal && !bossTerminalModal.classList.contains("hidden")) {
    // Esc／Enter 已經在終端機輸入框自己的 onkeydown（handleBossTerminalKeydown）
    // 處理掉了，這裡只要負責攔住，不要讓底下首頁搜尋的虛擬鍵盤／快捷鍵邏輯
    // 搶走一般英文字母、數字等按鍵，不然會變成打不出字。
    return;
  }

  const accessImportModal = document.getElementById("access_import_modal");
  if (accessImportModal && !accessImportModal.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.closeAccessImportModal();
    }
    return; // 一般文字/數字輸入框，交給瀏覽器原生輸入處理，不要被首頁的虛擬鍵盤攔截
  }

  const itemPicker = document.getElementById("item_picker_overlay");
  if (itemPicker && !itemPicker.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.closeItemPicker();
      return;
    }

    // F1～F11：直接切換分類，效果跟點上方的分類按鈕一樣
    // （順序對應 ITEM_CATEGORIES：其他/油品/輪胎/引擎/電裝/煞車/車體/驅動系統/轉向系統/工資/其他耗材）
    const fKeyMatch = /^F([1-9]|1[01])$/.exec(event.key);
    if (fKeyMatch) {
      const cat = ITEM_CATEGORIES[Number(fKeyMatch[1]) - 1];
      if (cat) {
        event.preventDefault();
        window.selectPickerCategory(cat);
      }
      return;
    }

    // Ctrl/⌘+N：新增項目，等同點分類列旁邊那顆圓形「＋」按鈕
    if ((event.ctrlKey || event.metaKey) && key === "n") {
      event.preventDefault();
      window.toggleNewItemForm();
      return;
    }

    // Enter：「新增項目」表單開著時，等同按下「新增品項」按鈕儲存這個項目
    if (event.key === "Enter") {
      const formEl = document.getElementById("item_picker_new_item_form");
      if (formEl && !formEl.classList.contains("hidden")) {
        event.preventDefault();
        window.submitNewCatalogItem();
      }
      return;
    }

    // Ctrl/⌘+PageDown・PageUp：換下一頁／上一頁
    if ((event.ctrlKey || event.metaKey) && event.key === "PageDown") {
      event.preventDefault();
      window.changePickerPage(1);
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key === "PageUp") {
      event.preventDefault();
      window.changePickerPage(-1);
      return;
    }

    // PageDown・PageUp（不加 Ctrl）：直接跳到最後一頁／第一頁
    if (event.key === "PageDown") {
      event.preventDefault();
      window.jumpPickerToLastPage();
      return;
    }
    if (event.key === "PageUp") {
      event.preventDefault();
      window.jumpPickerToFirstPage();
      return;
    }

    return;
  }

  const stockInOverlay = document.getElementById("stock_in_overlay");
  if (stockInOverlay && !stockInOverlay.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.closeStockInModal();
      return;
    }

    // F1～F10：直接切換分類，效果跟點上方的分類按鈕一樣
    // （順序對應 STOCK_IN_CATEGORIES：其他/油品/輪胎/引擎/電裝/煞車/車體/驅動系統/轉向系統/其他耗材）
    const stockInFKeyMatch = /^F([1-9]|10)$/.exec(event.key);
    if (stockInFKeyMatch) {
      const cat = STOCK_IN_CATEGORIES[Number(stockInFKeyMatch[1]) - 1];
      if (cat) {
        event.preventDefault();
        window.selectStockInCategory(cat);
      }
      return;
    }

    // Ctrl/⌘+PageDown・PageUp：換下一頁／上一頁
    if ((event.ctrlKey || event.metaKey) && event.key === "PageDown") {
      event.preventDefault();
      window.changeStockInPage(1);
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key === "PageUp") {
      event.preventDefault();
      window.changeStockInPage(-1);
      return;
    }

    // PageDown・PageUp（不加 Ctrl）：直接跳到最後一頁／第一頁
    if (event.key === "PageDown") {
      event.preventDefault();
      window.jumpStockInToLastPage();
      return;
    }
    if (event.key === "PageUp") {
      event.preventDefault();
      window.jumpStockInToFirstPage();
      return;
    }

    return; // 進貨/庫存管理都是一般文字/數字輸入框，交給瀏覽器原生輸入處理，不要被首頁的虛擬鍵盤攔截
  }

  const detailPage = document.getElementById("detail_page");
  if (detailPage && !detailPage.classList.contains("hidden")) {
    if (event.key === "Escape") {
      event.preventDefault();
      window.requestCloseDetailPage();
      return;
    }

    // F1／F2／F3：切換「顧客資訊」「維修資料」「歷史維修紀錄」三個分頁
    if (event.key === "F1") {
      event.preventDefault();
      window.switchDetailTab("customer");
      return;
    }
    if (event.key === "F2") {
      event.preventDefault();
      window.switchDetailTab("repair");
      return;
    }
    if (event.key === "F3") {
      event.preventDefault();
      window.switchDetailTab("history");
      return;
    }

    // Ctrl/⌘+Shift+S：里程晚點補登，等同按下「⏳ 里程晚點補登」按鈕
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && key === "s") {
      event.preventDefault();
      if (currentTab === "repair") {
        const pendingBtn = document.getElementById("repair_save_pending_btn");
        if (pendingBtn && !pendingBtn.disabled) window.saveRepairRecord(true);
      }
      return;
    }

    // Ctrl/⌘+Shift+Enter・Delete：歷史維修紀錄分頁，載入／刪除目前選到的那一筆
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === "Enter") {
      event.preventDefault();
      if (currentTab === "history" && selectedHistoryId) {
        window.loadHistoryRecordToRepairTab(selectedHistoryId);
      }
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === "Delete") {
      event.preventDefault();
      if (currentTab === "history" && selectedHistoryId) {
        window.deleteHistoryRecord(selectedHistoryId);
      }
      return;
    }

    // 以下這幾個快捷鍵用到 Enter／Shift+字母，本身也可能是正常打字的一部分，
    // 所以先確認目前焦點不是在打字區域，才觸發，避免蓋掉使用者正常輸入。
    if (!isTypingElement(event.target)) {
      if (currentTab === "repair") {
        // Enter：開啟分類選單，等同「點選輸入項目」按鈕
        if (event.key === "Enter" && !event.shiftKey) {
          event.preventDefault();
          window.openItemPicker();
          return;
        }
        // Shift+Enter：手動新增項目，等同「手動新增項目」按鈕
        if (event.key === "Enter" && event.shiftKey) {
          event.preventDefault();
          window.addRepairItemRow();
          return;
        }
        // Shift+N：加入備註，等同「備註」按鈕
        if (event.shiftKey && key === "n") {
          event.preventDefault();
          window.openNotesModal();
          return;
        }
      } else if (currentTab === "customer") {
        // Shift+N：顧客資訊的編輯，等同「編輯」按鈕
        if (event.shiftKey && key === "n" && !customerEditMode) {
          event.preventDefault();
          window.toggleCustomerEditMode();
          return;
        }
      }
    }

    return;
  }

  // ↕️ 以下只有在「搜尋車牌／卡號」首頁（沒有任何視窗開著）時才會執行，
  // 上下鍵可以直接切換到最近的歷史紀錄，不用點滑鼠。
  if (event.key === "Backspace") {
    event.preventDefault();
    window.backspaceKey();
  } else if (event.key === "Enter") {
    event.preventDefault();
    window.processSearch();
  } else if (event.key === "ArrowUp") {
    event.preventDefault();
    navigateSearchHistory(1);
  } else if (event.key === "ArrowDown") {
    event.preventDefault();
    navigateSearchHistory(-1);
  } else if (event.key === "ArrowLeft") {
    event.preventDefault();
    const pos = searchCursorPos === null ? rawSearchQuery.length : searchCursorPos;
    if (pos > 0) window.setSearchCursorPos(pos - 1);
  } else if (event.key === "ArrowRight") {
    event.preventDefault();
    if (searchCursorPos !== null) {
      const pos = searchCursorPos + 1;
      window.setSearchCursorPos(pos >= rawSearchQuery.length ? null : pos);
    }
  } else if (/^[a-zA-Z0-9]$/.test(event.key)) {
    event.preventDefault();
    window.typeKey(event.key);
  }
});

// 覆蓋模式的實際效果：insertOverwriteMode 開啟時，在文字輸入框打一般字元
// 會直接取代游標右邊那個字元，而不是插進去。獨立成另一個監聽器處理，
// 才不會被上面各畫面各自的鍵盤邏輯攔住（那些邏輯大多只處理 Escape/Enter，
// 其餘按鍵本來就會放行給瀏覽器原生輸入）。
window.addEventListener("keydown", (event) => {
  if (!insertOverwriteMode) return;

  const mask = document.getElementById("login_mask");
  if (!mask || !mask.classList.contains("hidden")) return;

  if (event.ctrlKey || event.metaKey || event.altKey) return;
  if (event.key.length !== 1) return; // 只處理一般可輸入的單一字元，功能鍵／方向鍵等不受影響

  const el = event.target;
  if (!isTextEntryElement(el)) return;

  try {
    const start = el.selectionStart;
    const end = el.selectionEnd;
    if (typeof start !== "number" || typeof end !== "number") return;
    if (start !== end) return; // 有選取文字時，維持瀏覽器預設的「取代選取範圍」行為即可
    if (start >= el.value.length) return; // 游標已經在最後面，右邊沒有字可覆蓋，讓瀏覽器照正常插入處理

    event.preventDefault();
    el.value = el.value.slice(0, start) + event.key + el.value.slice(start + 1);
    el.selectionStart = el.selectionEnd = start + 1;
    el.dispatchEvent(new Event("input", { bubbles: true }));
  } catch (err) {
    // 少數輸入框類型（例如某些瀏覽器版本）不支援 selectionStart/selectionEnd，
    // 遇到就放棄覆蓋、讓瀏覽器照正常插入處理，不要讓整個監聽器噴錯中斷。
  }
});

// 🚀 網頁一啟動立即渲染歷史紀錄
updateHistoryUI();
updateNetworkBanner();
loadLocalDiskCacheIntoMemory(); // 先把硬碟裡上次同步的完整資料灌進記憶體，離線也能馬上查得到
loadOfflineQueue().then(() => {
  updateNetworkBanner();
  if (isOnline && offlineQueue.length > 0) {
    syncOfflineQueue();
  }
});

// -----------------------------------------------------------------
// 📥 舊系統資料匯入（Microsoft Access .accdb / .mdb）
//
// 流程：選檔案（main.js 那邊用 mdb-reader 讀出所有資料表）→ 選要匯入的
// 表、把舊系統的欄位對應到新系統的欄位 → 預覽 → 確認後才真的寫進
// Firebase。可以只匯「客戶/車籍」主檔，也可以再多選一張維修紀錄表用
// 車牌/卡號關聯起來一起匯；如果舊系統只有一張「每次維修一列」的表，
// 「維修紀錄表」也可以選同一張表，用同一個車牌欄位關聯就好。
// -----------------------------------------------------------------

let accessImportTables = null; // { 表名: { columns:[...], rows:[...] } }
let accessImportStep = "pick"; // pick | mapping | preview | importing | done
let accessImportConfig = null;
let accessImportPlan = null; // buildAccessImportPlan() 的結果，預覽/匯入共用
let accessImportResult = null;
let catalogImportStatus = "idle"; // idle | importing | done ——品項分類清單匯入，跟上面的客戶/維修紀錄匯入各走各的
let catalogImportResult = null;

function resetAccessImportState() {
  accessImportTables = null;
  accessImportStep = "pick";
  accessImportConfig = {
    masterTable: "",
    masterMapping: {
      plate: "",
      name: "",
      phone: "",
      memberId: "",
      address: "",
      notes: "",
      // 上面 6 個欄位對應不到的其他舊系統欄位（例如引擎號碼、顏色、生日…），
      // 預設整理成文字附加到備註，避免使用者沒注意到就默默遺失資料；
      // 不想要的話可以在畫面上取消勾選。
      keepExtraColumns: true,
    },
    useRepairTable: false,
    repairTable: "",
    repairMapping: {
      linkField: "",
      key: "", // 本表的主鍵欄位（例如 NO），用來讓下面的「品項明細表」對回這一筆維修紀錄
      datetime: "",
      items: "",
      mileage: "",
      mechanic: "",
      cost: "",
      notes: "",
    },
    // 品項明細表：舊系統如果是「一次維修一列」＋「品項另外開一張明細表、用主鍵關聯」
    // 這種兩層結構（例如 維修記錄主檔＋維修記錄明細），可以多選這一層，
    // 匯入後每筆維修紀錄底下會有完整的品項清單（含分類），不用整包塞進備註。
    useItemsTable: false,
    itemsTable: "",
    itemsMapping: {
      linkField: "", // 明細表裡對應到「維修紀錄表主鍵欄位」的欄位
      name: "",
      qty: "",
      price: "",
      category: "", // 選填：類別代號（數字 0~10，跟系統的品項分類清單對應），對不到就歸類「其他」
    },
    overwriteExisting: false,
    // 品項分類清單（給「維修資料」表單上那個分類選單／共用品項庫用）：跟客戶／
    // 車籍、維修紀錄是完全獨立的兩件事，寫進 Firebase 的 itemCatalog，不是 records。
    catalogImport: {
      enabled: false,
      table: "",
      mapping: {
        name: "",
        price: "",
        categoryCode: "", // 對應舊系統的類別代號（0~10），對不到就歸類「其他」
      },
      skipDuplicates: true,
    },
  };
  accessImportPlan = null;
  accessImportResult = null;
  catalogImportStatus = "idle"; // idle | importing | done
  catalogImportResult = null;
}

window.openAccessImportModal = function () {
  resetAccessImportState();
  renderAccessImportBody();
  const modal = document.getElementById("access_import_modal");
  modal.classList.remove("hidden");
  modal.classList.add("flex");
};

window.closeAccessImportModal = function () {
  if (accessImportStep === "importing") return; // 匯入中不能關掉，避免中途中斷
  const modal = document.getElementById("access_import_modal");
  modal.classList.add("hidden");
  modal.classList.remove("flex");
};

// ⚙️ 隱藏「設定」頁：搜尋首頁單按 F12 打開，沒有畫面按鈕，全螢幕呈現，
// 介面模仿 iPhone 設定 App 的分組清單＋子頁面風格。
// storage 現在拆成兩層：storage（選擇本機／遠端）→ storage_local／storage_remote
let settingsCurrentPage = "main"; // main | display | storage | storage_local | storage_remote | server
let settingsPageStack = []; // 返回鍵用的頁面堆疊，才能一層一層往回走（不是每次都直接跳回 main）
let settingsConnectedUnsubscribe = null; // 「伺服器」子頁面用的即時連線狀態監聽

// -----------------------------------------------------------------
// 🖥️ 隱藏終端機（F12 按住不放、再按 Home）：跟 F12 開設定、F12+Insert 開
// 匯入舊系統資料是同一組隱藏快捷鍵家族，只在搜尋首頁生效。
//
// 指令：
// - sudo boss passwdadd：設定／變更密碼。第一次（還沒設定過密碼）不用
//   驗證，直接輸入新密碼兩次確認即可；已經設定過的話，要先輸入目前的
//   密碼驗證通過，才能設定新密碼。
// - sudo boss：輸入目前的密碼，驗證通過就解鎖這次執行期間的 boss 模式。
//
// 密碼不會存明文，是用 SHA-256 雜湊過後存在 Firebase 的
// appSettings/bossPasswordHash，全店裝置共用同一組密碼、同一組規則
// （appSettings 這個節點你們的 Firebase 規則已經有開放讀寫，不用再另外加）。
// 密碼輸入時畫面上只會顯示圓點數量，不會顯示實際輸入的字元。
// -----------------------------------------------------------------
let bossTerminalLines = [];
let bossTerminalMode = "idle"; // idle｜awaiting_password｜awaiting_current_password_for_change｜awaiting_new_password｜awaiting_new_password_confirm｜awaiting_mileage_value｜awaiting_technician_choice｜awaiting_technician_custom_name
let bossTerminalPendingNewPassword = null;
let bossModeUnlocked = false; // 這次程式執行期間是否已經解鎖 boss 模式
let adminModeUnlocked = false; // 是否已經切換到「管理員模式」——sudo serverdata / sudo data 這類刪除資料的指令只有這個模式才看得到、用得到
let bossPasswordPurpose = "unlock"; // 輸入密碼驗證通過之後要做什麼：unlock（解鎖並看業績報表）｜help（只是要看指令說明）
let bossTerminalPendingCategory = null; // sudo select 流程中，目前選到的分類
let bossTerminalPendingLetterOptions = []; // 忘記密碼流程中，畫面上列出來給使用者選的 4 組英文字母選項
let bossTerminalPendingSelectedLetters = null; // 忘記密碼流程中，使用者選中的那組英文字母
let bossTerminalPendingItemsList = []; // sudo select 流程中，該分類底下可選的品項清單
let bossTerminalPendingItemName = null; // sudo select 流程中，目前選定／手動輸入的品名
let bossTerminalPendingItemPrice = null; // sudo select 流程中，目前選定／手動輸入的單價
let bossTerminalHistory = []; // 之前打過的指令（不含密碼），給方向鍵上下瀏覽用
let bossTerminalHistoryIndex = 0; // 目前瀏覽到歷史紀錄的第幾筆，等於 history.length 代表在最新的空白行

async function sha256Hex(text) {
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

// 密碼輸入時，畫面上完全不顯示任何字元（連圓點都不要），
// 做法是把輸入框保持 type="text"，但打字時把文字顏色跟游標顏色都設成
// 透明，這樣使用者打字的當下畫面上什麼都看不到；解除時再把顏色還原。
function setBossTerminalMasked(masked) {
  const input = document.getElementById("boss_terminal_input");
  if (!input) return;
  input.type = "text";
  if (masked) {
    input.style.color = "transparent";
    input.style.caretColor = "transparent";
  } else {
    input.style.color = "#22c55e";
    input.style.caretColor = "#22c55e";
  }
}

function bossTerminalPrint(text) {
  bossTerminalLines.push(text);
  renderBossTerminalOutput();
}

function renderBossTerminalOutput() {
  const el = document.getElementById("boss_terminal_output");
  if (!el) return;
  el.textContent = bossTerminalLines.join("\n");
  el.scrollTop = el.scrollHeight;
}

// -----------------------------------------------------------------
// Ctrl+B 老闆系統快速入口：跟終端機的「sudo boss」共用同一組密碼，
// 差別是這裡用圖形化的小視窗直接問密碼，答對就直接跳進業績報表的
// 圖形介面，不用先打指令。這次執行期間如果已經解鎖過（bossModeUnlocked），
// 就不用再輸入一次密碼，直接看報表。
// -----------------------------------------------------------------
let bossQuickAccessPasswordHash = null; // 開視窗當下先讀一次，送出時不用再打一次 API

window.openBossQuickAccess = async function () {
  if (bossModeUnlocked) {
    await showBossRevenueReport();
    return;
  }

  let hasPassword = false;
  try {
    const snap = await get(ref(db, "appSettings/bossPasswordHash"));
    hasPassword = snap.exists();
    bossQuickAccessPasswordHash = hasPassword ? snap.val() : null;
  } catch (err) {
    console.error("讀取 boss 密碼設定失敗：", err);
    showAppAlert("讀取失敗，請確認網路連線後再試一次。");
    return;
  }
  if (!hasPassword) {
    showAppAlert(
      "尚未設定過老闆密碼，請先用內建終端機（F12 按住不放再按 Home）輸入 sudo boss passwdadd 設定密碼。"
    );
    return;
  }

  const passwordInput = document.getElementById("boss_quickaccess_password");
  const statusEl = document.getElementById("boss_quickaccess_status");
  if (passwordInput) passwordInput.value = "";
  if (statusEl) statusEl.textContent = "";

  const modal = document.getElementById("boss_quickaccess_modal");
  if (modal) {
    modal.classList.remove("hidden");
    modal.classList.add("flex");
  }
  setTimeout(() => passwordInput && passwordInput.focus(), 0);
};

window.closeBossQuickAccessModal = function () {
  const modal = document.getElementById("boss_quickaccess_modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
  const passwordInput = document.getElementById("boss_quickaccess_password");
  if (passwordInput) passwordInput.value = "";
};

window.handleBossQuickAccessKeydown = function (event) {
  if (event.key === "Escape") {
    event.preventDefault();
    window.closeBossQuickAccessModal();
  } else if (event.key === "Enter") {
    event.preventDefault();
    window.confirmBossQuickAccess();
  }
};

window.confirmBossQuickAccess = async function () {
  const passwordInput = document.getElementById("boss_quickaccess_password");
  const statusEl = document.getElementById("boss_quickaccess_status");
  const confirmBtn = document.getElementById("boss_quickaccess_confirm_btn");
  const value = passwordInput ? passwordInput.value : "";

  if (!value) {
    if (statusEl) statusEl.textContent = "請輸入密碼。";
    return;
  }

  if (confirmBtn) confirmBtn.disabled = true;
  try {
    const enteredHash = await sha256Hex(value);
    if (bossQuickAccessPasswordHash && enteredHash === bossQuickAccessPasswordHash) {
      bossModeUnlocked = true;
      window.closeBossQuickAccessModal();
      await showBossRevenueReport();
    } else {
      if (statusEl) statusEl.textContent = "密碼錯誤，請再試一次。";
      if (passwordInput) {
        passwordInput.value = "";
        passwordInput.focus();
      }
    }
  } catch (err) {
    console.error("驗證 boss 密碼失敗：", err);
    if (statusEl) statusEl.textContent = "驗證失敗，請確認網路連線後再試一次。";
  } finally {
    if (confirmBtn) confirmBtn.disabled = false;
  }
};

// -----------------------------------------------------------------
// 「忘記密碼？」圖形化流程（不使用終端機）：
// 1. 輸入信箱 → 2. 點選信箱收到的授權代碼（4 選 1）→
// 3. 輸入驗證金鑰（6 位數字）→ 4. 設定新密碼（輸入兩次確認）。
// 跟終端機版的 sudo boss forgot 是同一套後端（sendPasswordResetCode／
// verifyPasswordResetCode／appSettings/bossPasswordHash），只是改成
// 圖形視窗一步一步點，不用打指令。
// -----------------------------------------------------------------
let forgotPwStep = "email"; // email | letters | digits | newpassword | done
let forgotPwLetterOptions = [];
let forgotPwSelectedLetters = null;

window.openBossForgotPasswordModal = function () {
  window.closeBossQuickAccessModal();
  forgotPwStep = "email";
  forgotPwLetterOptions = [];
  forgotPwSelectedLetters = null;
  renderBossForgotPasswordBody();
  const modal = document.getElementById("boss_forgot_password_modal");
  if (modal) {
    modal.classList.remove("hidden");
    modal.classList.add("flex");
  }
};

window.closeBossForgotPasswordModal = function () {
  const modal = document.getElementById("boss_forgot_password_modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
};

function renderBossForgotPasswordBody() {
  const bodyEl = document.getElementById("boss_forgot_password_body");
  if (!bodyEl) return;

  if (forgotPwStep === "email") {
    bodyEl.innerHTML = `
      <p class="text-gray-400 text-sm mb-4">輸入老闆的收件信箱，系統會寄送驗證碼</p>
      <label class="text-xs font-bold text-gray-500 block mb-1">信箱</label>
      <input id="boss_forgot_email" type="email" autocomplete="off"
        onkeydown="window.handleBossForgotPasswordKeydown(event)"
        class="w-full border rounded-lg px-3 py-2 mb-1 text-sm" />
      <p id="boss_forgot_status" class="text-red-500 text-xs min-h-[16px] mb-4"></p>
      <div class="flex gap-3">
        <button onclick="window.closeBossForgotPasswordModal()"
          class="flex-1 bg-gray-100 text-gray-600 py-2.5 font-bold rounded-lg hover:bg-gray-200 transition">
          取消
        </button>
        <button id="boss_forgot_submit_btn" onclick="window.submitBossForgotEmail()"
          style="background-color: #7c3aed; color: #ffffff"
          class="flex-1 py-2.5 font-bold rounded-lg hover:opacity-90 shadow transition">
          寄送驗證碼
        </button>
      </div>`;
    setTimeout(() => {
      const el = document.getElementById("boss_forgot_email");
      if (el) el.focus();
    }, 0);
    return;
  }

  if (forgotPwStep === "letters") {
    const optionsHtml = forgotPwLetterOptions
      .map(
        (letters, i) => `
        <button onclick="window.selectBossForgotLetters(${i})"
          class="w-full border border-gray-200 rounded-lg py-3 mb-2 font-bold text-gray-700 hover:border-purple-400 hover:bg-purple-50 transition">
          ${escapeAttr(letters)}
        </button>`
      )
      .join("");
    bodyEl.innerHTML = `
      <p class="text-gray-400 text-sm mb-4">驗證碼已寄出，請點選信箱裡看到的那組授權代碼</p>
      ${optionsHtml}
      <p id="boss_forgot_status" class="text-red-500 text-xs min-h-[16px] mt-2 mb-2"></p>
      <button onclick="window.closeBossForgotPasswordModal()"
        class="w-full bg-gray-100 text-gray-600 py-2.5 font-bold rounded-lg hover:bg-gray-200 transition mt-2">
        取消
      </button>`;
    return;
  }

  if (forgotPwStep === "digits") {
    bodyEl.innerHTML = `
      <p class="text-gray-400 text-sm mb-4">請輸入信箱收到的驗證金鑰（6 位數字）</p>
      <label class="text-xs font-bold text-gray-500 block mb-1">驗證金鑰</label>
      <input id="boss_forgot_digits" type="text" inputmode="numeric" maxlength="6" autocomplete="off"
        onkeydown="window.handleBossForgotPasswordKeydown(event)"
        class="w-full border rounded-lg px-3 py-2 mb-1 text-sm tracking-widest" />
      <p id="boss_forgot_status" class="text-red-500 text-xs min-h-[16px] mb-4"></p>
      <div class="flex gap-3">
        <button onclick="window.closeBossForgotPasswordModal()"
          class="flex-1 bg-gray-100 text-gray-600 py-2.5 font-bold rounded-lg hover:bg-gray-200 transition">
          取消
        </button>
        <button id="boss_forgot_submit_btn" onclick="window.submitBossForgotDigits()"
          style="background-color: #7c3aed; color: #ffffff"
          class="flex-1 py-2.5 font-bold rounded-lg hover:opacity-90 shadow transition">
          驗證
        </button>
      </div>`;
    setTimeout(() => {
      const el = document.getElementById("boss_forgot_digits");
      if (el) el.focus();
    }, 0);
    return;
  }

  if (forgotPwStep === "newpassword") {
    bodyEl.innerHTML = `
      <p class="text-gray-400 text-sm mb-4">驗證通過，請設定新密碼</p>
      <label class="text-xs font-bold text-gray-500 block mb-1">新密碼</label>
      <input id="boss_forgot_newpass" type="password" autocomplete="off"
        onkeydown="window.handleBossForgotPasswordKeydown(event)"
        class="w-full border rounded-lg px-3 py-2 mb-3 text-sm" />
      <label class="text-xs font-bold text-gray-500 block mb-1">再輸入一次以確認</label>
      <input id="boss_forgot_newpass_confirm" type="password" autocomplete="off"
        onkeydown="window.handleBossForgotPasswordKeydown(event)"
        class="w-full border rounded-lg px-3 py-2 mb-1 text-sm" />
      <p id="boss_forgot_status" class="text-red-500 text-xs min-h-[16px] mb-4"></p>
      <div class="flex gap-3">
        <button onclick="window.closeBossForgotPasswordModal()"
          class="flex-1 bg-gray-100 text-gray-600 py-2.5 font-bold rounded-lg hover:bg-gray-200 transition">
          取消
        </button>
        <button id="boss_forgot_submit_btn" onclick="window.submitBossForgotNewPassword()"
          style="background-color: #7c3aed; color: #ffffff"
          class="flex-1 py-2.5 font-bold rounded-lg hover:opacity-90 shadow transition">
          儲存新密碼
        </button>
      </div>`;
    setTimeout(() => {
      const el = document.getElementById("boss_forgot_newpass");
      if (el) el.focus();
    }, 0);
    return;
  }

  if (forgotPwStep === "done") {
    bodyEl.innerHTML = `
      <p class="text-gray-700 text-sm mb-4">密碼已經設定完成，請用新密碼重新登入。</p>
      <button onclick="window.finishBossForgotPassword()"
        style="background-color: #7c3aed; color: #ffffff"
        class="w-full py-2.5 font-bold rounded-lg hover:opacity-90 shadow transition">
        好，回去輸入密碼
      </button>`;
  }
}

window.handleBossForgotPasswordKeydown = function (event) {
  if (event.key === "Escape") {
    event.preventDefault();
    window.closeBossForgotPasswordModal();
  } else if (event.key === "Enter") {
    event.preventDefault();
    const btn = document.getElementById("boss_forgot_submit_btn");
    if (btn) btn.click();
  }
};

window.submitBossForgotEmail = async function () {
  const emailInput = document.getElementById("boss_forgot_email");
  const statusEl = document.getElementById("boss_forgot_status");
  const btn = document.getElementById("boss_forgot_submit_btn");
  const email = emailInput ? emailInput.value.trim() : "";

  if (!email) {
    if (statusEl) statusEl.textContent = "請輸入信箱。";
    return;
  }

  if (btn) btn.disabled = true;
  if (statusEl) statusEl.textContent = "";
  try {
    if (!window.electronAPI || typeof window.electronAPI.sendPasswordResetCode !== "function") {
      if (statusEl) statusEl.textContent = "找不到寄信功能，請確認程式版本。";
      return;
    }
    const result = await window.electronAPI.sendPasswordResetCode(email);
    if (result && result.ok && Array.isArray(result.letterOptions)) {
      forgotPwLetterOptions = result.letterOptions;
      forgotPwStep = "letters";
      renderBossForgotPasswordBody();
    } else {
      // 不管是「信箱不在名單裡」還是寄送失敗，都用同一種說法，
      // 避免讓人試出哪些信箱是有效的老闆信箱。
      if (statusEl)
        statusEl.textContent = "驗證碼寄送失敗，請確認信箱是否正確後再試一次。";
    }
  } catch (err) {
    console.error("寄送驗證碼失敗：", err);
    if (statusEl) statusEl.textContent = "寄送失敗，請確認網路連線後再試一次。";
  } finally {
    if (btn) btn.disabled = false;
  }
};

window.selectBossForgotLetters = function (index) {
  const letters = forgotPwLetterOptions[index];
  if (!letters) return;
  forgotPwSelectedLetters = letters;
  forgotPwStep = "digits";
  renderBossForgotPasswordBody();
};

window.submitBossForgotDigits = async function () {
  const digitsInput = document.getElementById("boss_forgot_digits");
  const statusEl = document.getElementById("boss_forgot_status");
  const btn = document.getElementById("boss_forgot_submit_btn");
  const digits = digitsInput ? digitsInput.value.trim() : "";

  if (!digits) {
    if (statusEl) statusEl.textContent = "請輸入驗證金鑰。";
    return;
  }

  if (btn) btn.disabled = true;
  if (statusEl) statusEl.textContent = "";
  try {
    if (
      !window.electronAPI ||
      typeof window.electronAPI.verifyPasswordResetCode !== "function"
    ) {
      if (statusEl) statusEl.textContent = "找不到驗證功能，請確認程式版本。";
      return;
    }
    const fullCode = (forgotPwSelectedLetters || "") + digits;
    const result = await window.electronAPI.verifyPasswordResetCode(fullCode);
    if (result && result.ok) {
      forgotPwStep = "newpassword";
      renderBossForgotPasswordBody();
    } else if (result && result.reason === "expired") {
      if (statusEl)
        statusEl.textContent = "驗證碼已過期，請重新操作一次「忘記密碼」。";
    } else {
      if (statusEl) statusEl.textContent = "驗證碼錯誤，請再試一次。";
    }
  } catch (err) {
    console.error("驗證驗證碼失敗：", err);
    if (statusEl) statusEl.textContent = "驗證失敗，請稍後再試一次。";
  } finally {
    if (btn) btn.disabled = false;
  }
};

window.submitBossForgotNewPassword = async function () {
  const newPassInput = document.getElementById("boss_forgot_newpass");
  const confirmInput = document.getElementById("boss_forgot_newpass_confirm");
  const statusEl = document.getElementById("boss_forgot_status");
  const btn = document.getElementById("boss_forgot_submit_btn");
  const newPass = newPassInput ? newPassInput.value : "";
  const confirmPass = confirmInput ? confirmInput.value : "";

  if (!newPass) {
    if (statusEl) statusEl.textContent = "密碼不能是空的。";
    return;
  }
  if (newPass !== confirmPass) {
    if (statusEl) statusEl.textContent = "兩次輸入不一致，請重新輸入。";
    if (newPassInput) newPassInput.value = "";
    if (confirmInput) confirmInput.value = "";
    if (newPassInput) newPassInput.focus();
    return;
  }

  if (btn) btn.disabled = true;
  if (statusEl) statusEl.textContent = "";
  try {
    const hash = await sha256Hex(newPass);
    await set(ref(db, "appSettings/bossPasswordHash"), hash);
    forgotPwStep = "done";
    renderBossForgotPasswordBody();
  } catch (err) {
    console.error("儲存密碼失敗：", err);
    if (statusEl) statusEl.textContent = "儲存失敗，請確認網路連線後再試一次。";
  } finally {
    if (btn) btn.disabled = false;
  }
};

window.finishBossForgotPassword = function () {
  window.closeBossForgotPasswordModal();
  window.openBossQuickAccess();
};

// -----------------------------------------------------------------
// 🏭 「一般」設定裡的「原廠設定」：把系統整個打回全新狀態，跟「忘記密碼」
// 共用同一套信箱白名單＋驗證碼機制，差別是驗證通過後不是只改密碼，而是：
// 1. 清光伺服器上「所有」資料（車籍、維修紀錄、品項分類、系統設定，
//    範圍跟儲存空間 > 遠端空間那顆「清除全部資料」按鈕完全一樣）
// 2. 把使用者剛剛設定的新密碼寫回去（appSettings 節點被清空的時候
//    連 bossPasswordHash 也會一起被刪掉，所以密碼要在清除「之後」才寫入）
// 3. 再問一次「新增一個新系統」還是「繼承舊系統」——
//    選新系統：資料已經清空了，直接結束；
//    選舊系統：直接接到現有的「匯入舊系統資料（Access）」視窗
//    （跟 F12+Insert 開的是同一個 window.openAccessImportModal()）。
//
// 步驟：google（Google 登入驗證身分）→ email → letters →
//       digits → newpassword → choice（新系統／舊系統）→ processing（清除中）→ done
// -----------------------------------------------------------------
let factoryResetStep = "google"; // google | email | letters | digits | newpassword | choice | processing | done
let factoryResetLetterOptions = [];
let factoryResetSelectedLetters = null;
let factoryResetPendingPasswordHash = null; // 新密碼先算好雜湊存著，清除完資料才寫回 Firebase

// 打開原廠設定前，先去伺服器讀一次「是否已經執行過原廠設定」：
// - 沒做過（false／沒有這個值）：正常跑一次原廠設定流程，流程跑完會自動回到系統登入畫面
// - 已經做過（true）：不用再跑一次流程，直接回到系統登入畫面
window.openFactoryResetModal = async function () {
  const btn = document.activeElement;
  const originalText = btn ? btn.textContent : null;
  if (btn) {
    btn.disabled = true;
    btn.textContent = "檢查中...";
  }
  let alreadyDone = false;
  try {
    const snap = await get(ref(db, "appSettings/hasFactoryReset"));
    alreadyDone = snap.exists() ? !!snap.val() : false;
    systemHasFactoryReset = alreadyDone;
  } catch (err) {
    console.error("讀取原廠設定狀態失敗：", err);
    showAppAlert("讀取伺服器狀態失敗，請確認網路連線後再試一次。");
    if (btn) {
      btn.disabled = false;
      btn.textContent = originalText;
    }
    return;
  }
  if (btn) {
    btn.disabled = false;
    btn.textContent = originalText;
  }

  if (alreadyDone) {
    // 已經跑過原廠設定了，不用再跑一次整套流程，直接回到系統登入畫面。
    window.finishFactoryResetToLogin();
    return;
  }

  factoryResetStep = "google";
  factoryResetLetterOptions = [];
  factoryResetSelectedLetters = null;
  factoryResetPendingPasswordHash = null;
  renderFactoryResetBody();
  const modal = document.getElementById("factory_reset_modal");
  if (modal) {
    modal.classList.remove("hidden");
    modal.classList.add("flex");
  }
};

window.closeFactoryResetModal = function () {
  if (factoryResetStep === "processing") return; // 清除中不能關掉，避免中途中斷
  const modal = document.getElementById("factory_reset_modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
};

function renderFactoryResetBody() {
  const bodyEl = document.getElementById("factory_reset_body");
  const closeBtn = document.getElementById("factory_reset_close_btn");
  if (!bodyEl) return;

  // 清除中那一步不給關掉，其他步驟都可以按右上角 ✕ 取消
  if (closeBtn) {
    closeBtn.classList.toggle("hidden", factoryResetStep === "processing");
  }

  if (factoryResetStep === "google") {
    bodyEl.innerHTML = `
      <div class="flex flex-col items-center text-center py-2">
        <div class="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center text-4xl mb-4">
          🔑
        </div>
        <p class="text-gray-700 text-sm mb-1 font-bold">請先用 Google 登入驗證身分</p>
        <p class="text-gray-400 text-xs mb-6 leading-relaxed">
          瀏覽器會另外開一個分頁讓你登入，登入成功才能繼續下一步。
        </p>
      </div>
      <p id="factory_reset_status" class="text-red-500 text-xs min-h-[16px] mb-2 text-center"></p>
      <div class="flex gap-3">
        <button onclick="window.closeFactoryResetModal()"
          class="flex-1 bg-gray-100 text-gray-600 py-2.5 font-bold rounded-lg hover:bg-gray-200 transition">
          取消
        </button>
        <button id="factory_reset_google_btn" onclick="window.factoryResetGoogleLogin()"
          class="flex-1 bg-red-600 text-white py-2.5 font-bold rounded-lg hover:opacity-90 shadow transition">
          使用 Google 登入
        </button>
      </div>`;
    return;
  }

  if (factoryResetStep === "email") {
    bodyEl.innerHTML = `
      <p class="text-gray-400 text-sm mb-4">輸入老闆的收件信箱，系統會寄送驗證碼</p>
      <label class="text-xs font-bold text-gray-500 block mb-1">信箱</label>
      <input id="factory_reset_email" type="email" autocomplete="off"
        onkeydown="window.handleFactoryResetKeydown(event)"
        class="w-full border rounded-lg px-3 py-2 mb-1 text-sm" />
      <p id="factory_reset_status" class="text-red-500 text-xs min-h-[16px] mb-4"></p>
      <div class="flex gap-3">
        <button onclick="window.closeFactoryResetModal()"
          class="flex-1 bg-gray-100 text-gray-600 py-2.5 font-bold rounded-lg hover:bg-gray-200 transition">
          取消
        </button>
        <button id="factory_reset_submit_btn" onclick="window.submitFactoryResetEmail()"
          class="flex-1 bg-red-600 text-white py-2.5 font-bold rounded-lg hover:opacity-90 shadow transition">
          寄送驗證碼
        </button>
      </div>`;
    setTimeout(() => {
      const el = document.getElementById("factory_reset_email");
      if (el) el.focus();
    }, 0);
    return;
  }

  if (factoryResetStep === "letters") {
    const optionsHtml = factoryResetLetterOptions
      .map(
        (letters, i) => `
        <button onclick="window.selectFactoryResetLetters(${i})"
          class="w-full border border-gray-200 rounded-lg py-3 mb-2 font-bold text-gray-700 hover:border-red-400 hover:bg-red-50 transition">
          ${escapeAttr(letters)}
        </button>`
      )
      .join("");
    bodyEl.innerHTML = `
      <p class="text-gray-400 text-sm mb-4">驗證碼已寄出，請點選信箱裡看到的那組授權代碼</p>
      ${optionsHtml}
      <p id="factory_reset_status" class="text-red-500 text-xs min-h-[16px] mt-2 mb-2"></p>
      <button onclick="window.closeFactoryResetModal()"
        class="w-full bg-gray-100 text-gray-600 py-2.5 font-bold rounded-lg hover:bg-gray-200 transition mt-2">
        取消
      </button>`;
    return;
  }

  if (factoryResetStep === "digits") {
    bodyEl.innerHTML = `
      <p class="text-gray-400 text-sm mb-4">請輸入信箱收到的驗證金鑰（6 位數字）</p>
      <label class="text-xs font-bold text-gray-500 block mb-1">驗證金鑰</label>
      <input id="factory_reset_digits" type="text" inputmode="numeric" maxlength="6" autocomplete="off"
        onkeydown="window.handleFactoryResetKeydown(event)"
        class="w-full border rounded-lg px-3 py-2 mb-1 text-sm tracking-widest" />
      <p id="factory_reset_status" class="text-red-500 text-xs min-h-[16px] mb-4"></p>
      <div class="flex gap-3">
        <button onclick="window.closeFactoryResetModal()"
          class="flex-1 bg-gray-100 text-gray-600 py-2.5 font-bold rounded-lg hover:bg-gray-200 transition">
          取消
        </button>
        <button id="factory_reset_submit_btn" onclick="window.submitFactoryResetDigits()"
          class="flex-1 bg-red-600 text-white py-2.5 font-bold rounded-lg hover:opacity-90 shadow transition">
          驗證
        </button>
      </div>`;
    setTimeout(() => {
      const el = document.getElementById("factory_reset_digits");
      if (el) el.focus();
    }, 0);
    return;
  }

  if (factoryResetStep === "newpassword") {
    bodyEl.innerHTML = `
      <p class="text-gray-400 text-sm mb-4">驗證通過，請設定老闆新密碼</p>
      <label class="text-xs font-bold text-gray-500 block mb-1">新密碼</label>
      <input id="factory_reset_newpass" type="password" autocomplete="off"
        onkeydown="window.handleFactoryResetKeydown(event)"
        class="w-full border rounded-lg px-3 py-2 mb-3 text-sm" />
      <label class="text-xs font-bold text-gray-500 block mb-1">再輸入一次以確認</label>
      <input id="factory_reset_newpass_confirm" type="password" autocomplete="off"
        onkeydown="window.handleFactoryResetKeydown(event)"
        class="w-full border rounded-lg px-3 py-2 mb-1 text-sm" />
      <p id="factory_reset_status" class="text-red-500 text-xs min-h-[16px] mb-4"></p>
      <div class="flex gap-3">
        <button onclick="window.closeFactoryResetModal()"
          class="flex-1 bg-gray-100 text-gray-600 py-2.5 font-bold rounded-lg hover:bg-gray-200 transition">
          取消
        </button>
        <button id="factory_reset_submit_btn" onclick="window.submitFactoryResetNewPassword()"
          class="flex-1 bg-red-600 text-white py-2.5 font-bold rounded-lg hover:opacity-90 shadow transition">
          下一步
        </button>
      </div>`;
    setTimeout(() => {
      const el = document.getElementById("factory_reset_newpass");
      if (el) el.focus();
    }, 0);
    return;
  }

  if (factoryResetStep === "choice") {
    bodyEl.innerHTML = `
      <p class="text-gray-700 text-sm mb-1 font-bold">密碼已經準備好了，最後一步：</p>
      <p class="text-gray-400 text-xs mb-5">這台是要開始用在一間全新的店，還是要接續舊系統的資料？</p>
      <button onclick="window.chooseFactoryResetNewSystem()"
        class="w-full border-2 border-gray-200 rounded-lg py-3 mb-3 text-left px-4 hover:border-red-400 hover:bg-red-50 transition">
        <div class="font-bold text-gray-800">新增一個新系統</div>
        <div class="text-xs text-gray-400 mt-0.5">資料清空後直接完成，不匯入任何舊資料</div>
      </button>
      <button onclick="window.chooseFactoryResetOldSystem()"
        class="w-full border-2 border-gray-200 rounded-lg py-3 mb-3 text-left px-4 hover:border-red-400 hover:bg-red-50 transition">
        <div class="font-bold text-gray-800">繼承舊系統</div>
        <div class="text-xs text-gray-400 mt-0.5">資料清空後，緊接著開啟「匯入舊系統資料（Access）」</div>
      </button>
      <p id="factory_reset_status" class="text-red-500 text-xs min-h-[16px]"></p>`;
    return;
  }

  if (factoryResetStep === "processing") {
    bodyEl.innerHTML = `
      <div class="flex flex-col items-center text-center py-6">
        <div class="w-10 h-10 border-4 border-gray-300 border-t-red-600 rounded-full animate-spin-custom mb-4"></div>
        <p id="factory_reset_status" class="text-gray-600 text-sm">正在清除所有資料，請稍候...</p>
      </div>`;
    return;
  }

  if (factoryResetStep === "done") {
    bodyEl.innerHTML = `
      <p class="text-gray-700 text-sm mb-4">${factoryResetDoneMessage || "已完成，系統回到全新狀態。"}</p>
      <button onclick="window.finishFactoryResetToLogin()"
        class="w-full bg-red-600 text-white py-2.5 font-bold rounded-lg hover:opacity-90 shadow transition">
        好，回到登入畫面
      </button>`;
    return;
  }
}

// 原廠設定完成後，不只是關掉這個視窗回到設定選單，而是把整個系統
// 登出、蓋掉所有還開著的視窗（設定／終端機…），回到最一開始那個
// 「一般系統登入畫面」，才符合「原廠設定完畢＝系統回到全新開機狀態」。
window.finishFactoryResetToLogin = async function () {
  const modal = document.getElementById("factory_reset_modal");
  if (modal) {
    modal.classList.add("hidden");
    modal.classList.remove("flex");
  }
  if (typeof window.closeHiddenSettingsModal === "function") {
    window.closeHiddenSettingsModal();
  }
  const bossTerminalModal = document.getElementById("boss_terminal_modal");
  if (bossTerminalModal) {
    bossTerminalModal.classList.add("hidden");
    bossTerminalModal.classList.remove("flex");
  }
  factoryResetStep = "google";
  // logoutSystem 會處理離線模式／Google 登入兩種情況，並讓
  // onAuthStateChanged／login_mask 自動接手切回登入畫面。
  if (typeof window.logoutSystem === "function") {
    await window.logoutSystem();
  } else {
    document.getElementById("main_system")?.classList.add("hidden");
    document.getElementById("login_mask")?.classList.remove("hidden");
  }
};

window.factoryResetGoogleLogin = async function () {
  const btn = document.getElementById("factory_reset_google_btn");
  const status = document.getElementById("factory_reset_status");
  if (status) status.textContent = "";
  if (btn) {
    btn.disabled = true;
    btn.textContent = "登入中...";
  }
  try {
    await setPersistence(auth, browserLocalPersistence);
    const { idToken, accessToken } = await window.electronAPI.loginWithGoogle();
    const credential = GoogleAuthProvider.credential(idToken, accessToken);
    await signInWithCredential(auth, credential);
    factoryResetStep = "email";
    renderFactoryResetBody();
  } catch (error) {
    console.error("原廠設定 Google 登入失敗：", error);
    if (btn) {
      btn.disabled = false;
      btn.textContent = "使用 Google 登入";
    }
    if (status) {
      status.textContent =
        error && error.message === "no_code_returned"
          ? "登入視窗被關閉，請再試一次。"
          : `Google 登入失敗（${error && (error.code || error.message)}），請再試一次。`;
    }
  }
};

window.factoryResetProceedToEmail = function () {
  factoryResetStep = "email";
  renderFactoryResetBody();
};

window.handleFactoryResetKeydown = function (event) {
  if (event.key === "Escape") {
    event.preventDefault();
    window.closeFactoryResetModal();
  } else if (event.key === "Enter") {
    event.preventDefault();
    const btn = document.getElementById("factory_reset_submit_btn");
    if (btn) btn.click();
  }
};

window.submitFactoryResetEmail = async function () {
  const emailInput = document.getElementById("factory_reset_email");
  const statusEl = document.getElementById("factory_reset_status");
  const btn = document.getElementById("factory_reset_submit_btn");
  const email = emailInput ? emailInput.value.trim() : "";

  if (!email) {
    if (statusEl) statusEl.textContent = "請輸入信箱。";
    return;
  }

  if (btn) btn.disabled = true;
  if (statusEl) statusEl.textContent = "";
  try {
    if (!window.electronAPI || typeof window.electronAPI.sendPasswordResetCode !== "function") {
      if (statusEl) statusEl.textContent = "找不到寄信功能，請確認程式版本。";
      return;
    }
    const result = await window.electronAPI.sendPasswordResetCode(email, "factory_reset");
    if (result && result.ok && Array.isArray(result.letterOptions)) {
      factoryResetLetterOptions = result.letterOptions;
      factoryResetStep = "letters";
      renderFactoryResetBody();
    } else {
      // 不管是「信箱不在名單裡」還是寄送失敗，都用同一種說法，
      // 避免讓人試出哪些信箱是有效的老闆信箱。
      if (statusEl)
        statusEl.textContent = "驗證碼寄送失敗，請確認信箱是否正確後再試一次。";
    }
  } catch (err) {
    console.error("寄送驗證碼失敗：", err);
    if (statusEl) statusEl.textContent = "寄送失敗，請確認網路連線後再試一次。";
  } finally {
    if (btn) btn.disabled = false;
  }
};

window.selectFactoryResetLetters = function (index) {
  const letters = factoryResetLetterOptions[index];
  if (!letters) return;
  factoryResetSelectedLetters = letters;
  factoryResetStep = "digits";
  renderFactoryResetBody();
};

window.submitFactoryResetDigits = async function () {
  const digitsInput = document.getElementById("factory_reset_digits");
  const statusEl = document.getElementById("factory_reset_status");
  const btn = document.getElementById("factory_reset_submit_btn");
  const digits = digitsInput ? digitsInput.value.trim() : "";

  if (!digits) {
    if (statusEl) statusEl.textContent = "請輸入驗證金鑰。";
    return;
  }

  if (btn) btn.disabled = true;
  if (statusEl) statusEl.textContent = "";
  try {
    if (
      !window.electronAPI ||
      typeof window.electronAPI.verifyPasswordResetCode !== "function"
    ) {
      if (statusEl) statusEl.textContent = "找不到驗證功能，請確認程式版本。";
      return;
    }
    const fullCode = (factoryResetSelectedLetters || "") + digits;
    const result = await window.electronAPI.verifyPasswordResetCode(fullCode);
    if (result && result.ok) {
      factoryResetStep = "newpassword";
      renderFactoryResetBody();
    } else if (result && result.reason === "expired") {
      if (statusEl)
        statusEl.textContent = "驗證碼已過期，請重新操作一次「原廠設定」。";
    } else {
      if (statusEl) statusEl.textContent = "驗證碼錯誤，請再試一次。";
    }
  } catch (err) {
    console.error("驗證驗證碼失敗：", err);
    if (statusEl) statusEl.textContent = "驗證失敗，請稍後再試一次。";
  } finally {
    if (btn) btn.disabled = false;
  }
};

window.submitFactoryResetNewPassword = async function () {
  const newPassInput = document.getElementById("factory_reset_newpass");
  const confirmInput = document.getElementById("factory_reset_newpass_confirm");
  const statusEl = document.getElementById("factory_reset_status");
  const btn = document.getElementById("factory_reset_submit_btn");
  const newPass = newPassInput ? newPassInput.value : "";
  const confirmPass = confirmInput ? confirmInput.value : "";

  if (!newPass) {
    if (statusEl) statusEl.textContent = "密碼不能是空的。";
    return;
  }
  if (newPass !== confirmPass) {
    if (statusEl) statusEl.textContent = "兩次輸入不一致，請重新輸入。";
    if (newPassInput) newPassInput.value = "";
    if (confirmInput) confirmInput.value = "";
    if (newPassInput) newPassInput.focus();
    return;
  }

  if (btn) btn.disabled = true;
  if (statusEl) statusEl.textContent = "";
  try {
    // 先把新密碼的雜湊算好存著，資料清除完（appSettings 節點會被整個砍掉，
    // 連同舊密碼一起消失）之後才寫回 Firebase，不然清除的時候會把這組新密碼也一起洗掉。
    factoryResetPendingPasswordHash = await sha256Hex(newPass);
    factoryResetStep = "choice";
    renderFactoryResetBody();
  } catch (err) {
    console.error("處理新密碼失敗：", err);
    if (statusEl) statusEl.textContent = "處理失敗，請再試一次。";
  } finally {
    if (btn) btn.disabled = false;
  }
};

let factoryResetDoneMessage = "";

// 「新增一個新系統」跟「繼承舊系統」共用同一段清除＋寫回新密碼的邏輯，
// 差別只在清除完之後要不要緊接著開啟匯入舊系統資料視窗。
async function performFactoryResetWipe() {
  factoryResetStep = "processing";
  renderFactoryResetBody();
  showDeleteProgressScreen("正在執行原廠設定...");
  updateDeleteProgressScreen(5, "準備開始清除所有資料...");
  await deleteProgressPause(300);

  const total = FIREBASE_TOP_LEVEL_PATHS.length;
  for (let i = 0; i < total; i++) {
    const p = FIREBASE_TOP_LEVEL_PATHS[i];
    updateDeleteProgressScreen(
      5 + (i / total) * 70,
      `正在清除伺服器資料（${i + 1}/${total}）：${p}`
    );
    await remove(ref(db, p));
  }
  // 遠端資料都清光了，本機鏡像快取也一起清掉，避免本機還留著一份
  // 「伺服器上其實已經不存在」的舊資料，離線時反而查到假資料。
  recordCache.clear();
  lastFullSyncAt = null;
  updateDeleteProgressScreen(80, "正在清理本機鏡像快取...");
  try {
    await window.electronAPI.clearLocalCache();
  } catch (localErr) {
    console.error("清除遠端資料後，清理本機鏡像快取失敗：", localErr);
  }

  // appSettings 節點被砍掉的時候舊密碼也一起消失了，這裡把剛剛使用者
  // 設定的新密碼寫回去，系統才不會變成完全沒有密碼可以解鎖老闆功能。
  if (factoryResetPendingPasswordHash) {
    updateDeleteProgressScreen(92, "正在寫回新密碼設定...");
    await set(ref(db, "appSettings/bossPasswordHash"), factoryResetPendingPasswordHash);
  }

  // 原廠設定真的跑完了，把狀態寫回伺服器（appSettings 節點剛被清空過，
  // 這裡等於是「原廠設定完成後才第一次寫入」），這樣其他每一台電腦
  // 開機時都能查到「這套系統已經執行過原廠設定」。
  updateDeleteProgressScreen(97, "正在更新系統狀態...");
  await set(ref(db, "appSettings/hasFactoryReset"), true);
  systemHasFactoryReset = true;
  updateDeleteProgressScreen(100, "清除完成");
  await deleteProgressPause(400);
  hideDeleteProgressScreen();
}

window.chooseFactoryResetNewSystem = async function () {
  const statusEl = document.getElementById("factory_reset_status");
  try {
    await performFactoryResetWipe();
    factoryResetDoneMessage =
      "已清除所有資料並設定好新密碼，系統已回到全新開機的狀態，請用新密碼重新登入老闆功能。";
    factoryResetStep = "done";
    renderFactoryResetBody();
  } catch (err) {
    console.error("原廠設定失敗：", err);
    hideDeleteProgressScreen();
    factoryResetStep = "choice";
    renderFactoryResetBody();
    const s = document.getElementById("factory_reset_status");
    if (s) s.textContent = `清除失敗：${err.message || "未知錯誤"}，請確認網路連線後再試一次。`;
  }
};

window.chooseFactoryResetOldSystem = async function () {
  try {
    await performFactoryResetWipe();
    window.closeFactoryResetModal();
    // 資料清空、新密碼也設定好了，緊接著開啟現有的「匯入舊系統資料（Access）」視窗，
    // 跟 F12+Insert 開的是同一支函式。
    if (typeof window.openAccessImportModal === "function") {
      window.openAccessImportModal();
    }
  } catch (err) {
    console.error("原廠設定失敗：", err);
    hideDeleteProgressScreen();
    factoryResetStep = "choice";
    renderFactoryResetBody();
    const s = document.getElementById("factory_reset_status");
    if (s) s.textContent = `清除失敗：${err.message || "未知錯誤"}，請確認網路連線後再試一次。`;
  }
};

window.openBossTerminal = function () {
  bossTerminalLines = [];
  bossTerminalMode = "idle";
  bossTerminalPendingNewPassword = null;
  bossTerminalHistoryIndex = bossTerminalHistory.length;
  bossTerminalPrint("MotoSync 內建終端機 — 輸入指令後按 Enter 執行，Esc 離開");
  const modal = document.getElementById("boss_terminal_modal");
  if (modal) {
    modal.classList.remove("hidden");
    modal.classList.add("flex");
  }
  const input = document.getElementById("boss_terminal_input");
  if (input) {
    input.value = "";
    setTimeout(() => input.focus(), 0);
  }
  setBossTerminalMasked(false);
};

window.closeBossTerminal = function () {
  const modal = document.getElementById("boss_terminal_modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
  bossTerminalMode = "idle";
  bossTerminalPendingNewPassword = null;
};

window.handleBossTerminalKeydown = function (event) {
  if (event.key === "Escape") {
    event.preventDefault();
    event.stopPropagation();
    window.closeBossTerminal();
    return;
  }

  const input = document.getElementById("boss_terminal_input");
  if (!input) return;

  // 方向鍵「上／下」瀏覽之前打過的指令：上一個往上（越來越舊），
  // 下一個往下（越來越新），跟一般終端機習慣一樣。
  if (event.key === "ArrowUp") {
    event.preventDefault();
    if (bossTerminalHistory.length === 0) return;
    bossTerminalHistoryIndex = Math.max(0, bossTerminalHistoryIndex - 1);
    input.value = bossTerminalHistory[bossTerminalHistoryIndex];
    requestAnimationFrame(() =>
      input.setSelectionRange(input.value.length, input.value.length)
    );
    return;
  }
  if (event.key === "ArrowDown") {
    event.preventDefault();
    if (bossTerminalHistory.length === 0) return;
    bossTerminalHistoryIndex = Math.min(
      bossTerminalHistory.length,
      bossTerminalHistoryIndex + 1
    );
    input.value =
      bossTerminalHistoryIndex === bossTerminalHistory.length
        ? ""
        : bossTerminalHistory[bossTerminalHistoryIndex];
    requestAnimationFrame(() =>
      input.setSelectionRange(input.value.length, input.value.length)
    );
    return;
  }

  if (event.key !== "Enter") return;
  event.preventDefault();
  event.stopPropagation();

  const value = input.value;
  input.value = "";

  // 密碼相關的行完全不把使用者輸入的內容顯示出來，連圓點/星號都不顯示，
  // 避免旁邊有人看到打了什麼、甚至看出密碼長度。里程、技師這類非密碼的
  // 輸入則正常顯示，不用遮蔽。
  const isPasswordMode =
    bossTerminalMode === "awaiting_password" ||
    bossTerminalMode === "awaiting_current_password_for_change" ||
    bossTerminalMode === "awaiting_new_password" ||
    bossTerminalMode === "awaiting_new_password_confirm" ||
    bossTerminalMode === "awaiting_admin_password" ||
    bossTerminalMode === "awaiting_forgot_password_digits";

  if (isPasswordMode) {
    bossTerminalPrint("$");
  } else {
    bossTerminalPrint("$ " + value);
    // 密碼以外的指令才存進歷史紀錄，方向鍵才叫得回來。
    if (value.trim() !== "") {
      bossTerminalHistory.push(value);
      if (bossTerminalHistory.length > 100) bossTerminalHistory.shift();
    }
    bossTerminalHistoryIndex = bossTerminalHistory.length;
  }

  handleBossTerminalCommand(value.trim());
};

// -----------------------------------------------------------------
// 💰 業績報表：解鎖 boss 模式之後自動顯示一次，之後也可以在終端機裡輸入
// revenue 指令重看。抓 records 底下所有車的 repairs（不含 estimates，
// 估價還沒真的收錢，不算業績），用每筆的 cost 加總算今日／本月／總計，
// 用圖形畫面呈現（卡片 + 長條圖），不是純文字。
// -----------------------------------------------------------------
async function showBossRevenueReport() {
  bossTerminalPrint("正在計算業績，請稍候...");
  try {
    const snap = await get(ref(db, "records"));
    const allRecords = snap.exists() ? snap.val() : {};

    const todayKey = todayStr(); // yyyy-mm-dd
    const monthKey = todayKey.slice(0, 7); // yyyy-mm

    let todayTotal = 0;
    let todayCount = 0;
    let monthTotal = 0;
    let monthCount = 0;
    let allTotal = 0;
    let allCount = 0;
    const monthlyTotals = {}; // "yyyy-mm" -> { total, count }

    // 客戶數用「不重複車輛」來算，同一台車今天來修好幾個項目也只算一位客戶。
    const todayCustomerSet = new Set();
    const monthCustomerSet = new Set();
    const allCustomerSet = new Set();

    // 每位員工（維修人員）各自的今日／本月／總計／每月趨勢／客戶數，
    // 用來做「員工業績」分頁，key 是技師姓名。
    const employeeStats = {};
    function ensureEmployee(name) {
      if (!employeeStats[name]) {
        employeeStats[name] = {
          today: { total: 0, count: 0 },
          month: { total: 0, count: 0 },
          all: { total: 0, count: 0 },
          monthly: {},
          todayCustomerSet: new Set(),
          monthCustomerSet: new Set(),
          allCustomerSet: new Set(),
        };
      }
      return employeeStats[name];
    }

    Object.entries(allRecords).forEach(([vehicleKey, vehicle]) => {
      const repairs = (vehicle && vehicle.repairs) || {};
      Object.values(repairs).forEach((r) => {
        const dt = (r && r.datetime) || "";
        if (!dt) return;
        const cost = Number(r && r.cost) || 0;

        allTotal += cost;
        allCount += 1;
        allCustomerSet.add(vehicleKey);

        const dKey = dt.slice(0, 10);
        const mKey = dt.slice(0, 7);

        if (dKey === todayKey) {
          todayTotal += cost;
          todayCount += 1;
          todayCustomerSet.add(vehicleKey);
        }
        if (mKey === monthKey) {
          monthTotal += cost;
          monthCount += 1;
          monthCustomerSet.add(vehicleKey);
        }

        if (!monthlyTotals[mKey]) monthlyTotals[mKey] = { total: 0, count: 0 };
        monthlyTotals[mKey].total += cost;
        monthlyTotals[mKey].count += 1;

        const mechanicName = ((r && r.mechanic) || "").trim() || "未指定技師";
        const emp = ensureEmployee(mechanicName);
        emp.all.total += cost;
        emp.all.count += 1;
        emp.allCustomerSet.add(vehicleKey);
        if (dKey === todayKey) {
          emp.today.total += cost;
          emp.today.count += 1;
          emp.todayCustomerSet.add(vehicleKey);
        }
        if (mKey === monthKey) {
          emp.month.total += cost;
          emp.month.count += 1;
          emp.monthCustomerSet.add(vehicleKey);
        }
        if (!emp.monthly[mKey]) emp.monthly[mKey] = { total: 0, count: 0 };
        emp.monthly[mKey].total += cost;
        emp.monthly[mKey].count += 1;
      });
    });

    // 把 Set 轉成數字，員工清單也順便補上客戶數欄位，畫面渲染時比較好用。
    const todayCustomerCount = todayCustomerSet.size;
    const monthCustomerCount = monthCustomerSet.size;
    const allCustomerCount = allCustomerSet.size;
    Object.values(employeeStats).forEach((emp) => {
      emp.today.customers = emp.todayCustomerSet.size;
      emp.month.customers = emp.monthCustomerSet.size;
      emp.all.customers = emp.allCustomerSet.size;
    });

    bossTerminalPrint("業績報表已計算完成，另外開視窗顯示。");
    window.closeBossTerminal();
    renderBossRevenueModal({
      todayTotal,
      todayCount,
      todayCustomerCount,
      monthTotal,
      monthCount,
      monthCustomerCount,
      allTotal,
      allCount,
      allCustomerCount,
      monthlyTotals,
      employeeStats,
    });
  } catch (err) {
    console.error("計算業績失敗：", err);
    bossTerminalPrint("計算業績失敗，請確認網路連線後再試一次。");
  }
}

function fmtMoney(n) {
  return `$${Math.round(n).toLocaleString("en-US")}`;
}

// 畫「每月趨勢」長條圖用的共用函式，總覽分頁跟員工分頁都用得到，
// 差別只在傳進來的 monthlyTotals 跟顏色不同。
function buildMonthlyChartSvg(monthlyTotals, options) {
  options = options || {};
  const months = Object.keys(monthlyTotals).sort().slice(-12); // 最近最多 12 個月，由舊到新排，圖表比較好看
  const maxTotal = months.reduce(
    (max, m) => Math.max(max, monthlyTotals[m].total),
    0
  );

  const chartWidth = options.chartWidth || 720;
  const chartHeight = options.chartHeight || 220;
  const barGap = 12;
  const barWidth =
    months.length > 0
      ? Math.min(60, (chartWidth - barGap * (months.length - 1)) / months.length)
      : 0;
  const usedWidth = months.length * barWidth + (months.length - 1) * barGap;
  const startX = Math.max(0, (chartWidth - usedWidth) / 2);
  const barColor = options.barColor || "#7c3aed";
  const barColorMuted = options.barColorMuted || "#c4b5fd";

  if (months.length === 0) {
    return `<div class="text-center text-gray-400 py-10">還沒有任何維修紀錄可以統計</div>`;
  }

  let barsSvg = "";
  months.forEach((m, i) => {
    const info = monthlyTotals[m];
    const barHeight = maxTotal > 0 ? (info.total / maxTotal) * (chartHeight - 40) : 0;
    const x = startX + i * (barWidth + barGap);
    const y = chartHeight - 24 - barHeight;
    const isCurrentMonth = m === todayStr().slice(0, 7);
    const monthLabel = m.slice(5, 7) + "月";
    barsSvg += `
      <g>
        <rect x="${x}" y="${y}" width="${barWidth}" height="${Math.max(barHeight, 1)}"
          rx="4" fill="${isCurrentMonth ? barColor : barColorMuted}"></rect>
        <text x="${x + barWidth / 2}" y="${y - 6}" text-anchor="middle"
          font-size="11" fill="#374151">${fmtMoney(info.total)}</text>
        <text x="${x + barWidth / 2}" y="${chartHeight - 6}" text-anchor="middle"
          font-size="12" fill="#6b7280">${monthLabel}</text>
      </g>`;
  });

  return `<svg viewBox="0 0 ${chartWidth} ${chartHeight}" class="w-full h-auto">${barsSvg}</svg>`;
}

// 業績報表視窗現在分兩個分頁：「總覽」（原本的今日／本月／總計＋趨勢圖）
// 跟「員工業績」（每位維修人員各自的業績排行＋明細），可以互動點選切換。
let lastBossRevenueStats = null;
let bossRevenueActiveTab = "overview"; // "overview" | "employee"
let bossRevenueMetric = "month"; // "today" | "month" | "all"：員工排行要依哪個數字排序
let bossRevenueSelectedEmployee = null; // 目前點開明細的員工姓名
let bossRevenueLastSortedNames = []; // 記住目前排行榜的順序，讓點擊索引對得到姓名

function renderBossRevenueModal(stats) {
  lastBossRevenueStats = stats;
  // 每次重新計算資料時，如果之前選的員工這次已經不存在了（例如剛好沒有任何紀錄），
  // 就清掉，讓畫面重新挑一個預設員工顯示。
  if (
    bossRevenueSelectedEmployee &&
    !(stats.employeeStats && stats.employeeStats[bossRevenueSelectedEmployee])
  ) {
    bossRevenueSelectedEmployee = null;
  }
  renderBossRevenueBody();

  const modal = document.getElementById("boss_revenue_modal");
  if (modal) {
    modal.classList.remove("hidden");
    modal.classList.add("flex");
  }
}

function renderBossRevenueBody() {
  const stats = lastBossRevenueStats;
  const bodyEl = document.getElementById("boss_revenue_body");
  if (!stats || !bodyEl) return;

  const tabsHtml = `
    <div class="flex gap-2 mb-6">
      <button onclick="window.setBossRevenueTab('overview')"
        class="px-4 py-2 rounded-lg font-bold text-sm transition ${
          bossRevenueActiveTab === "overview"
            ? "bg-purple-600 text-white"
            : "bg-gray-100 text-gray-500 hover:bg-gray-200"
        }">
        總覽
      </button>
      <button onclick="window.setBossRevenueTab('employee')"
        class="px-4 py-2 rounded-lg font-bold text-sm transition ${
          bossRevenueActiveTab === "employee"
            ? "bg-purple-600 text-white"
            : "bg-gray-100 text-gray-500 hover:bg-gray-200"
        }">
        員工業績
      </button>
    </div>`;

  const contentHtml =
    bossRevenueActiveTab === "employee"
      ? buildEmployeeTabHtml(stats)
      : buildOverviewTabHtml(stats);

  bodyEl.innerHTML = tabsHtml + contentHtml;
}

function buildOverviewTabHtml(stats) {
  const {
    todayTotal,
    todayCount,
    todayCustomerCount,
    monthTotal,
    monthCount,
    monthCustomerCount,
    allTotal,
    allCount,
    allCustomerCount,
    monthlyTotals,
  } = stats;
  const chartSvg = buildMonthlyChartSvg(monthlyTotals);

  return `
    <div class="grid grid-cols-3 gap-4 mb-4">
      <div class="bg-purple-50 border border-purple-200 rounded-xl p-4 text-center">
        <div class="text-purple-500 text-sm font-bold mb-1">今日</div>
        <div class="text-2xl font-black text-purple-700">${fmtMoney(todayTotal)}</div>
        <div class="text-xs text-gray-400 mt-1">${todayCount} 筆</div>
      </div>
      <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
        <div class="text-blue-500 text-sm font-bold mb-1">本月</div>
        <div class="text-2xl font-black text-blue-700">${fmtMoney(monthTotal)}</div>
        <div class="text-xs text-gray-400 mt-1">${monthCount} 筆</div>
      </div>
      <div class="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-center">
        <div class="text-emerald-500 text-sm font-bold mb-1">總計</div>
        <div class="text-2xl font-black text-emerald-700">${fmtMoney(allTotal)}</div>
        <div class="text-xs text-gray-400 mt-1">${allCount} 筆</div>
      </div>
    </div>
    <div class="grid grid-cols-3 gap-4 mb-6">
      <div class="bg-white border border-purple-100 rounded-xl p-3 text-center">
        <div class="text-xs text-gray-400 mb-1">今日客戶數</div>
        <div class="text-lg font-bold text-purple-600">${todayCustomerCount} 位</div>
      </div>
      <div class="bg-white border border-blue-100 rounded-xl p-3 text-center">
        <div class="text-xs text-gray-400 mb-1">本月客戶數</div>
        <div class="text-lg font-bold text-blue-600">${monthCustomerCount} 位</div>
      </div>
      <div class="bg-white border border-emerald-100 rounded-xl p-3 text-center">
        <div class="text-xs text-gray-400 mb-1">總客戶數</div>
        <div class="text-lg font-bold text-emerald-600">${allCustomerCount} 位</div>
      </div>
    </div>
    <div class="text-gray-500 text-sm font-bold mb-2">最近月份趨勢</div>
    <div class="bg-gray-50 border border-gray-200 rounded-xl p-4">${chartSvg}</div>
  `;
}

function buildEmployeeTabHtml(stats) {
  const employeeStats = stats.employeeStats || {};
  const names = Object.keys(employeeStats);

  if (names.length === 0) {
    return `<div class="text-center text-gray-400 py-10">還沒有任何維修紀錄可以統計</div>`;
  }

  const metric = bossRevenueMetric;
  const metricLabel = { today: "今日", month: "本月", all: "總計" };

  const sorted = names
    .slice()
    .sort((a, b) => employeeStats[b][metric].total - employeeStats[a][metric].total);
  bossRevenueLastSortedNames = sorted;

  if (!bossRevenueSelectedEmployee || !employeeStats[bossRevenueSelectedEmployee]) {
    bossRevenueSelectedEmployee = sorted[0];
  }

  const maxVal = sorted.reduce((max, n) => Math.max(max, employeeStats[n][metric].total), 0);

  const metricButtons = ["today", "month", "all"]
    .map(
      (m) => `
      <button onclick="window.setBossRevenueMetric('${m}')"
        class="px-3 py-1.5 rounded-lg text-sm font-bold transition ${
          bossRevenueMetric === m
            ? "bg-blue-600 text-white"
            : "bg-gray-100 text-gray-500 hover:bg-gray-200"
        }">
        ${metricLabel[m]}
      </button>`
    )
    .join("");

  const rankingRows = sorted
    .map((name, i) => {
      const info = employeeStats[name][metric];
      const widthPct = maxVal > 0 ? Math.max((info.total / maxVal) * 100, 2) : 0;
      const isSelected = name === bossRevenueSelectedEmployee;
      return `
        <div onclick="window.selectBossRevenueEmployee(${i})"
          class="cursor-pointer rounded-lg p-3 mb-2 border transition ${
            isSelected
              ? "border-purple-400 bg-purple-50"
              : "border-gray-200 bg-white hover:border-purple-300"
          }">
          <div class="flex items-center justify-between mb-1">
            <div class="font-bold text-gray-700">第 ${i + 1} 名　${escapeAttr(name)}</div>
            <div class="text-sm text-gray-500">${fmtMoney(info.total)}<span class="text-xs text-gray-400 ml-1">（${info.count} 筆．${info.customers || 0} 位客戶）</span></div>
          </div>
          <div class="w-full bg-gray-100 rounded-full h-2">
            <div class="h-2 rounded-full ${isSelected ? "bg-purple-500" : "bg-blue-300"}"
              style="width:${widthPct}%"></div>
          </div>
        </div>`;
    })
    .join("");

  const empData = employeeStats[bossRevenueSelectedEmployee];
  const detailChart = buildMonthlyChartSvg(empData.monthly, {
    barColor: "#0f766e",
    barColorMuted: "#99f6e4",
  });

  return `
    <div class="mb-6">
      <div class="flex items-center justify-between mb-2">
        <div class="text-gray-500 text-sm font-bold">員工排行（依${metricLabel[metric]}排序，點一位看明細）</div>
        <div class="flex gap-2">${metricButtons}</div>
      </div>
      ${rankingRows}
    </div>
    <div class="border-t border-gray-200 pt-4">
      <div class="text-lg font-bold text-gray-800 mb-3">${escapeAttr(
        bossRevenueSelectedEmployee
      )} 的業績明細</div>
      <div class="grid grid-cols-3 gap-4 mb-4">
        <div class="bg-purple-50 border border-purple-200 rounded-xl p-4 text-center">
          <div class="text-purple-500 text-sm font-bold mb-1">今日</div>
          <div class="text-xl font-black text-purple-700">${fmtMoney(empData.today.total)}</div>
          <div class="text-xs text-gray-400 mt-1">${empData.today.count} 筆．${empData.today.customers || 0} 位客戶</div>
        </div>
        <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <div class="text-blue-500 text-sm font-bold mb-1">本月</div>
          <div class="text-xl font-black text-blue-700">${fmtMoney(empData.month.total)}</div>
          <div class="text-xs text-gray-400 mt-1">${empData.month.count} 筆．${empData.month.customers || 0} 位客戶</div>
        </div>
        <div class="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-center">
          <div class="text-emerald-500 text-sm font-bold mb-1">總計</div>
          <div class="text-xl font-black text-emerald-700">${fmtMoney(empData.all.total)}</div>
          <div class="text-xs text-gray-400 mt-1">${empData.all.count} 筆．${empData.all.customers || 0} 位客戶</div>
        </div>
      </div>
      <div class="text-gray-500 text-sm font-bold mb-2">最近月份趨勢</div>
      <div class="bg-gray-50 border border-gray-200 rounded-xl p-4">${detailChart}</div>
    </div>
  `;
}

window.setBossRevenueTab = function (tab) {
  bossRevenueActiveTab = tab;
  renderBossRevenueBody();
};

window.setBossRevenueMetric = function (metric) {
  bossRevenueMetric = metric;
  renderBossRevenueBody();
};

window.selectBossRevenueEmployee = function (index) {
  const name = bossRevenueLastSortedNames && bossRevenueLastSortedNames[index];
  if (!name) return;
  bossRevenueSelectedEmployee = name;
  renderBossRevenueBody();
};

window.closeBossRevenueModal = function () {
  const modal = document.getElementById("boss_revenue_modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
};

// -----------------------------------------------------------------
// 🗑️ 清除資料（本機／伺服器）的圖形化確認視窗
//
// 跟其他終端機指令不一樣，「清除資料」是真的會造成資料永久遺失的
// 危險操作，所以特別做一個看得到、點得到的圖形視窗，而不是純文字
// 問答：要同時輸入「管理員密碼」跟「信箱驗證碼」兩樣東西都對了，
// 才會真的執行刪除。
// -----------------------------------------------------------------
// -----------------------------------------------------------------
// 🖤 黑底刪除進度畫面：清除資料／原廠設定共用，蓋滿整個應用程式視窗，
// 讓使用者清楚看到「現在真的在刪、刪到哪裡了」，不是關掉的死畫面。
// -----------------------------------------------------------------
function showDeleteProgressScreen(title) {
  const screen = document.getElementById("delete_progress_screen");
  const titleEl = document.getElementById("delete_progress_title");
  const bar = document.getElementById("delete_progress_bar");
  const percent = document.getElementById("delete_progress_percent");
  const detail = document.getElementById("delete_progress_detail");
  if (titleEl) titleEl.textContent = title || "正在清除資料...";
  if (bar) bar.style.width = "0%";
  if (percent) percent.textContent = "0%";
  if (detail) detail.textContent = "";
  if (screen) {
    screen.classList.remove("hidden");
    screen.classList.add("flex");
  }
}

function updateDeleteProgressScreen(pct, detailText) {
  const bar = document.getElementById("delete_progress_bar");
  const percent = document.getElementById("delete_progress_percent");
  const detail = document.getElementById("delete_progress_detail");
  const clamped = Math.max(0, Math.min(100, pct));
  if (bar) bar.style.width = `${clamped}%`;
  if (percent) percent.textContent = `${Math.round(clamped)}%`;
  if (detail && detailText) detail.textContent = detailText;
}

function hideDeleteProgressScreen() {
  const screen = document.getElementById("delete_progress_screen");
  if (screen) {
    screen.classList.add("hidden");
    screen.classList.remove("flex");
  }
}

// 把畫面暫停一下，讓進度條看起來是真的一步步在跑，而不是瞬間跳 100%
function deleteProgressPause(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

let dangerDeleteType = null; // "local"｜"server"｜"settings_local"｜"settings_server"
let dangerDeleteStep = "warning1"; // warning1 | warning2 | warning3 | form

// 清除資料要連續按過三次一次比一次嚴重的警告，才會看到密碼／驗證碼表單。
const DANGER_DELETE_WARNINGS = [
  {
    heading: "⚠️ 第 1 次警告",
    body: "這個操作會刪除資料，而且無法復原。請先確認你真的要繼續。",
    confirmText: "我了解，繼續",
  },
  {
    heading: "⚠️ 第 2 次警告",
    body: "再次確認：資料一旦刪除就救不回來了，請確定不是誤按。",
    confirmText: "我確定，繼續",
  },
  {
    heading: "⚠️ 最後一次警告",
    body: "這是最後一次確認。按下「繼續」後，會進入密碼與驗證碼確認流程；驗證通過就會立刻開始刪除。",
    confirmText: "繼續，進入驗證",
  },
];

function renderDangerDeleteWarningStep() {
  const warningEl = document.getElementById("danger_delete_warning_step");
  const formEl = document.getElementById("danger_delete_form_step");
  if (!warningEl || !formEl) return;

  if (dangerDeleteStep === "form") {
    warningEl.classList.add("hidden");
    warningEl.innerHTML = "";
    formEl.classList.remove("hidden");
    return;
  }

  formEl.classList.add("hidden");
  warningEl.classList.remove("hidden");

  const stepIndex = { warning1: 0, warning2: 1, warning3: 2 }[
    dangerDeleteStep
  ];
  const info = DANGER_DELETE_WARNINGS[stepIndex];

  warningEl.innerHTML = `
    <div class="flex flex-col items-center text-center py-2">
      <div class="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center text-4xl mb-4 animate-warn-pulse">
        ⚠️
      </div>
      <p class="text-red-600 text-xs font-bold mb-1">${info.heading}</p>
      <p id="danger_delete_message" class="text-gray-700 text-sm mb-6 leading-relaxed"></p>
    </div>
    <div class="flex gap-3">
      <button onclick="window.closeDangerDeleteModal()"
        class="flex-1 bg-gray-100 text-gray-600 py-2.5 font-bold rounded-lg hover:bg-gray-200 transition">
        取消
      </button>
      <button onclick="window.dangerDeleteWarningNext()"
        class="flex-1 bg-red-600 text-white py-2.5 font-bold rounded-lg hover:opacity-90 shadow transition">
        ${info.confirmText}
      </button>
    </div>`;

  // 把當前情境（清本機／清伺服器…）的專屬說明疊在警告文字前面，
  // 讓使用者每一次警告都看得到「這次到底要刪什麼」。
  const messageEl = document.getElementById("danger_delete_message");
  if (messageEl) {
    messageEl.textContent = `${info.body}\n\n${dangerDeleteTypeMessage()}`;
    messageEl.style.whiteSpace = "pre-line";
  }
}

function dangerDeleteTypeMessage() {
  return "這會把伺服器上『所有』資料（車牌／卡號車籍、維修紀錄、估價、品項分類、系統設定…）連同這台電腦的本機快取、待補傳的離線紀錄，全部刪除，且無法復原！刪除完成後，系統的「是否執行過原廠設定」狀態也會被改回「尚未執行」。";
}

window.dangerDeleteWarningNext = function () {
  if (dangerDeleteStep === "warning1") {
    dangerDeleteStep = "warning2";
  } else if (dangerDeleteStep === "warning2") {
    dangerDeleteStep = "warning3";
  } else if (dangerDeleteStep === "warning3") {
    dangerDeleteStep = "form";
  }
  renderDangerDeleteWarningStep();
};

window.openDangerDeleteModal = function (type) {
  dangerDeleteType = type;
  dangerDeleteStep = "warning1";
  const modal = document.getElementById("danger_delete_modal");
  const title = document.getElementById("danger_delete_title");
  const message = document.getElementById("danger_delete_form_message");
  const passwordInput = document.getElementById("danger_delete_password");
  const emailInput = document.getElementById("danger_delete_email");
  const codeArea = document.getElementById("danger_delete_code_area");
  const sendBtn = document.getElementById("danger_delete_send_code_btn");
  const status = document.getElementById("danger_delete_status");
  const codeInput = document.getElementById("danger_delete_code_input");

  if (passwordInput) passwordInput.value = "";
  if (emailInput) emailInput.value = "";
  if (codeInput) codeInput.value = "";
  if (codeArea) codeArea.classList.add("hidden");
  if (sendBtn) {
    sendBtn.disabled = false;
    sendBtn.textContent = "寄送驗證碼到信箱";
  }
  if (status) {
    status.textContent = "";
    status.className = "text-sm mb-4 min-h-[20px]";
  }

  if (title) title.textContent = "清除資料";
  if (message)
    message.textContent =
      "這會把伺服器上所有資料，連同本機快取、待補傳的離線紀錄，全部刪除，且無法復原！請輸入管理員密碼並完成信箱驗證碼確認才能執行。";

  if (modal) {
    modal.classList.remove("hidden");
    modal.classList.add("flex");
  }
  renderDangerDeleteWarningStep();
};

window.closeDangerDeleteModal = function () {
  dangerDeleteType = null;
  dangerDeleteStep = "warning1";
  const modal = document.getElementById("danger_delete_modal");
  if (modal) {
    modal.classList.add("hidden");
    modal.classList.remove("flex");
  }
};

window.sendDangerDeleteCode = async function () {
  const sendBtn = document.getElementById("danger_delete_send_code_btn");
  const status = document.getElementById("danger_delete_status");
  const codeArea = document.getElementById("danger_delete_code_area");
  const emailInput = document.getElementById("danger_delete_email");

  const setStatus = (text, isError) => {
    if (!status) return;
    status.textContent = text;
    status.className = `text-sm mb-4 min-h-[20px] ${
      isError ? "text-red-600" : "text-green-600"
    }`;
  };

  const email = emailInput ? emailInput.value.trim() : "";
  if (!email) {
    setStatus("請先輸入收件信箱。", true);
    return;
  }

  if (sendBtn) {
    sendBtn.disabled = true;
    sendBtn.textContent = "寄送中...";
  }
  setStatus("", false);

  try {
    if (
      !window.electronAPI ||
      typeof window.electronAPI.sendPasswordResetCode !== "function"
    ) {
      setStatus("找不到寄信功能，請確認程式版本。", true);
      return;
    }
    const result = await window.electronAPI.sendPasswordResetCode(
      email,
      "delete_data"
    );
    if (result && result.ok) {
      if (codeArea) codeArea.classList.remove("hidden");
      setStatus("驗證碼已寄出，請查看信箱並貼上完整驗證碼。", false);
      setTimeout(() => {
        const codeInput = document.getElementById("danger_delete_code_input");
        if (codeInput) codeInput.focus();
      }, 0);
    } else if (result && result.error === "not_authorized") {
      // 故意用跟「寄送失敗」一樣的說法，不透露是信箱不在名單裡。
      setStatus("驗證碼寄送失敗，請確認信箱是否正確後再試一次。", true);
    } else {
      setStatus("驗證碼寄送失敗，請確認網路連線後再試一次。", true);
    }
  } catch (err) {
    console.error("寄送驗證碼失敗：", err);
    setStatus("寄送失敗，請確認網路連線後再試一次。", true);
  } finally {
    if (sendBtn) {
      sendBtn.disabled = false;
      sendBtn.textContent = "重新寄送驗證碼";
    }
  }
};

window.confirmDangerDelete = async function () {
  const status = document.getElementById("danger_delete_status");
  const confirmBtn = document.getElementById("danger_delete_confirm_btn");
  const passwordInput = document.getElementById("danger_delete_password");
  const codeInput = document.getElementById("danger_delete_code_input");

  const setStatus = (text, isError) => {
    if (!status) return;
    status.textContent = text;
    status.className = `text-sm mb-4 min-h-[20px] ${
      isError ? "text-red-600" : "text-green-600"
    }`;
  };

  const password = passwordInput ? passwordInput.value : "";
  if (!password) {
    setStatus("請先輸入管理員密碼。", true);
    return;
  }
  // 把使用者貼上來的驗證碼去掉空白、統一轉大寫，跟信件裡「字母 空格 數字」
  // 的顯示格式（例如 ABCD 123456）比對時才不會因為多打了空格而失敗。
  const fullCode = (codeInput ? codeInput.value : "").replace(/\s+/g, "");
  if (!fullCode) {
    setStatus("請先寄送驗證碼，並輸入信箱收到的完整驗證碼。", true);
    return;
  }

  if (confirmBtn) {
    confirmBtn.disabled = true;
    confirmBtn.textContent = "處理中...";
  }
  setStatus("正在驗證身分，請稍候...", false);

  try {
    // 先驗證管理員密碼
    const snap = await get(ref(db, "appSettings/bossPasswordHash"));
    const storedHash = snap.exists() ? snap.val() : null;
    if (!storedHash) {
      setStatus(
        "尚未設定過密碼，無法執行，請先用 sudo boss passwdadd 設定密碼。",
        true
      );
      return;
    }
    const enteredHash = await sha256Hex(password);
    if (enteredHash !== storedHash) {
      setStatus("密碼錯誤。", true);
      return;
    }

    // 密碼對了，再驗證信箱驗證碼
    if (
      !window.electronAPI ||
      typeof window.electronAPI.verifyPasswordResetCode !== "function"
    ) {
      setStatus("找不到驗證功能，請確認程式版本。", true);
      return;
    }
    const codeResult = await window.electronAPI.verifyPasswordResetCode(
      fullCode
    );
    if (!codeResult || !codeResult.ok) {
      if (codeResult && codeResult.reason === "expired") {
        setStatus("驗證碼已過期，請重新寄送。", true);
      } else {
        setStatus("驗證碼錯誤。", true);
      }
      return;
    }

    // 密碼跟驗證碼都對了，才真的執行刪除——切到黑底全螢幕進度畫面，
    // 讓使用者清楚看到刪除正在進行、進行到哪裡了。
    // 「清除資料」不分從哪個入口點進來，一律是全部刪光：伺服器所有資料
    // ＋本機車籍資料快取＋待補傳的離線紀錄，刪完再把伺服器上的
    // 「是否執行過原廠設定」狀態改回 false（等於系統又回到沒設定過的狀態）。
    setStatus("驗證通過，準備開始刪除...", false);
    showDeleteProgressScreen("正在清除資料...");
    updateDeleteProgressScreen(10, "驗證通過，準備開始刪除...");
    await deleteProgressPause(300);

    if (!auth.currentUser) {
      hideDeleteProgressScreen();
      setStatus("尚未登入，取消刪除。", true);
      return;
    }

    const total = FIREBASE_TOP_LEVEL_PATHS.length;
    for (let i = 0; i < total; i++) {
      const p = FIREBASE_TOP_LEVEL_PATHS[i];
      updateDeleteProgressScreen(
        10 + (i / total) * 55,
        `正在刪除伺服器資料（${i + 1}/${total}）：${p}`
      );
      await remove(ref(db, p));
    }

    // 遠端資料都刪光了，本機的鏡像快取、離線佇列也一起清掉，避免本機
    // 還留著一份「伺服器上其實已經不存在」的舊資料。
    recordCache.clear();
    lastFullSyncAt = null;
    offlineQueue = [];
    try {
      updateDeleteProgressScreen(75, "正在刪除本機車籍資料快取...");
      await window.electronAPI.clearLocalCache();
      updateDeleteProgressScreen(85, "正在清除待補傳的離線紀錄...");
      await window.electronAPI.writeOfflineQueue([]);
    } catch (localErr) {
      console.error("清理本機快取失敗：", localErr);
    }

    // appSettings 被整個刪掉的時候，hasFactoryReset 也一起消失了（等同 false），
    // 這裡明確再寫一次 false，確保狀態明確、開機檢查一定讀得到值。
    updateDeleteProgressScreen(95, "正在更新系統狀態...");
    await set(ref(db, "appSettings/hasFactoryReset"), false);
    systemHasFactoryReset = false;

    updateDeleteProgressScreen(100, "刪除完成");
    setStatus("伺服器資料與本機快取已全部清除完成！", false);
    updateNetworkBanner();
    if (
      settingsCurrentPage === "storage_remote" ||
      settingsCurrentPage === "storage_local"
    ) {
      renderHiddenSettingsBody();
    }

    await deleteProgressPause(500);
    hideDeleteProgressScreen();
    setTimeout(() => {
      window.closeDangerDeleteModal();
    }, 1800);
  } catch (err) {
    console.error("刪除失敗：", err);
    hideDeleteProgressScreen();
    setStatus("刪除失敗，請確認網路連線後再試一次。", true);
  } finally {
    if (confirmBtn) {
      confirmBtn.disabled = false;
      confirmBtn.textContent = "確定刪除";
    }
  }
};

function printBossHelp() {
  const lines = [
    "可用指令（全程都在終端機裡輸入，不會跳出任何畫面）：",
    "cd 車牌 → 在背景切換到該車牌／卡號的資料",
    "sudo select → 用文字選單選分類、選品項、輸入數量，直接寫入維修項目",
    "sudo mileage → 輸入本次里程數",
    "sudo technician → 選擇技師（選擇題）",
    "saveadd → 儲存維修資料",
    "saveestimateadd → 儲存估價",
    "sudo mileage later add → 里程晚點補登",
    "sudo test network → 測試網路詳細資料並打分數",
    "revenue → 重看業績報表",
    "sudo boss passwdadd → 設定／變更密碼",
    "sudo boss forgot → 忘記密碼，寄驗證碼到信箱重設",
    "sudo admin → 切換管理員模式",
    "clear → 清畫面",
    "exit → 離開",
  ];
  if (adminModeUnlocked) {
    lines.push(
      "（管理員模式）sudo serverdata → 查看伺服器資料統計",
      "（管理員模式）sudo serverdata delete → 開啟清除伺服器資料視窗（需要密碼＋信箱驗證碼）",
      "（管理員模式）sudo data → 查看本機硬碟資料統計",
      "（管理員模式）sudo data delete → 開啟清除本機資料視窗（需要密碼＋信箱驗證碼）"
    );
  }
  bossTerminalPrint(lines.join("\n"));
}

async function handleBossTerminalCommand(value) {
  const input = document.getElementById("boss_terminal_input");

  if (bossTerminalMode === "awaiting_password") {
    bossTerminalMode = "idle";
    setBossTerminalMasked(false);
    const purpose = bossPasswordPurpose;
    bossPasswordPurpose = "unlock";
    try {
      const snap = await get(ref(db, "appSettings/bossPasswordHash"));
      const storedHash = snap.exists() ? snap.val() : null;
      const enteredHash = await sha256Hex(value);
      if (storedHash && enteredHash === storedHash) {
        bossModeUnlocked = true;
        if (purpose === "help") {
          bossTerminalPrint("密碼正確，以下是可用指令：");
          printBossHelp();
        } else {
          bossTerminalPrint("密碼正確，boss 模式已解鎖。");
          await showBossRevenueReport();
        }
      } else {
        bossTerminalPrint("密碼錯誤。");
      }
    } catch (err) {
      console.error("驗證 boss 密碼失敗：", err);
      bossTerminalPrint("驗證失敗，請確認網路連線後再試一次。");
    }
    return;
  }

  if (bossTerminalMode === "awaiting_current_password_for_change") {
    bossTerminalMode = "idle";
    setBossTerminalMasked(false);
    try {
      const snap = await get(ref(db, "appSettings/bossPasswordHash"));
      const storedHash = snap.exists() ? snap.val() : null;
      const enteredHash = await sha256Hex(value);
      if (storedHash && enteredHash === storedHash) {
        bossTerminalMode = "awaiting_new_password";
        setBossTerminalMasked(true);
        bossTerminalPrint("驗證通過，請輸入新密碼：");
      } else {
        bossTerminalPrint("密碼錯誤，取消變更密碼。");
      }
    } catch (err) {
      console.error("驗證 boss 密碼失敗：", err);
      bossTerminalPrint("驗證失敗，請確認網路連線後再試一次。");
    }
    return;
  }

  if (bossTerminalMode === "awaiting_new_password") {
    if (!value) {
      bossTerminalPrint("密碼不能是空的，請重新輸入：");
      return;
    }
    bossTerminalPendingNewPassword = value;
    bossTerminalMode = "awaiting_new_password_confirm";
    bossTerminalPrint("請再輸入一次以確認：");
    return;
  }

  if (bossTerminalMode === "awaiting_new_password_confirm") {
    setBossTerminalMasked(false);
    if (value !== bossTerminalPendingNewPassword) {
      bossTerminalMode = "idle";
      bossTerminalPendingNewPassword = null;
      bossTerminalPrint("兩次輸入不一致，密碼設定取消，請重新輸入 sudo boss passwdadd。");
      return;
    }
    try {
      const hash = await sha256Hex(value);
      await set(ref(db, "appSettings/bossPasswordHash"), hash);
      bossTerminalPrint("密碼已設定完成。");
    } catch (err) {
      console.error("儲存 boss 密碼失敗：", err);
      bossTerminalPrint("儲存失敗，請確認網路連線後再試一次。");
    }
    bossTerminalMode = "idle";
    bossTerminalPendingNewPassword = null;
    return;
  }

  if (bossTerminalMode === "awaiting_mileage_value") {
    bossTerminalMode = "idle";
    if (!currentRecordKey) {
      bossTerminalPrint("目前沒有開啟中的車牌資料，取消輸入。");
      return;
    }
    const mileageText = value.trim();
    if (mileageText === "" || isNaN(Number(mileageText))) {
      bossTerminalPrint("里程數必須是數字，取消輸入。");
      return;
    }
    if (Number(mileageText) < 0) {
      bossTerminalPrint("里程數不能是負的，取消輸入。");
      return;
    }
    const mileageInput = document.getElementById("repair_mileage");
    if (mileageInput) {
      mileageInput.value = mileageText;
      if (typeof window.updateDistanceDisplay === "function") {
        window.updateDistanceDisplay();
      }
    }
    bossTerminalPrint(`已填入本次里程：${mileageText} km`);
    return;
  }

  if (bossTerminalMode === "awaiting_technician_choice") {
    if (!currentRecordKey) {
      bossTerminalMode = "idle";
      bossTerminalPrint("目前沒有開啟中的車牌資料，取消選擇。");
      return;
    }
    const select = document.getElementById("repair_mechanic_select");
    if (!select) {
      bossTerminalMode = "idle";
      bossTerminalPrint("找不到技師欄位，取消選擇。");
      return;
    }
    const choice = value.trim();
    if (choice === "1" || choice === "阿翰") {
      select.value = "阿翰";
      if (typeof window.onMechanicSelectChange === "function") {
        window.onMechanicSelectChange();
      }
      bossTerminalMode = "idle";
      bossTerminalPrint("技師已選擇：阿翰");
    } else if (choice === "2" || choice === "明松") {
      select.value = "明松";
      if (typeof window.onMechanicSelectChange === "function") {
        window.onMechanicSelectChange();
      }
      bossTerminalMode = "idle";
      bossTerminalPrint("技師已選擇：明松");
    } else if (choice === "3" || choice === "自行輸入") {
      select.value = "__custom__";
      if (typeof window.onMechanicSelectChange === "function") {
        window.onMechanicSelectChange();
      }
      bossTerminalMode = "awaiting_technician_custom_name";
      bossTerminalPrint("請輸入技師姓名：");
    } else {
      bossTerminalPrint("請輸入 1、2 或 3：\n1) 阿翰\n2) 明松\n3) 自行輸入");
    }
    return;
  }

  if (bossTerminalMode === "awaiting_technician_custom_name") {
    bossTerminalMode = "idle";
    const name = value.trim();
    if (!name) {
      bossTerminalPrint("技師姓名不能是空的，取消輸入。");
      return;
    }
    const customInput = document.getElementById("repair_mechanic_custom");
    if (customInput) customInput.value = name;
    bossTerminalPrint(`技師已輸入：${name}`);
    return;
  }

  if (bossTerminalMode === "awaiting_item_category_choice") {
    if (!currentRecordKey) {
      bossTerminalMode = "idle";
      bossTerminalPrint("目前沒有開啟中的車牌資料，取消選擇。");
      return;
    }
    const choice = value.trim();
    let category = null;
    const idx = parseInt(choice, 10);
    if (!isNaN(idx) && idx >= 1 && idx <= ITEM_CATEGORIES.length) {
      category = ITEM_CATEGORIES[idx - 1];
    } else if (ITEM_CATEGORIES.includes(choice)) {
      category = choice;
    }
    if (!category) {
      bossTerminalPrint(
        `無效的分類，請輸入 1~${ITEM_CATEGORIES.length} 之間的數字：`
      );
      return;
    }
    bossTerminalPendingCategory = category;
    try {
      const snap = await get(ref(db, "itemCatalog/" + category));
      const items = snap.exists() ? snap.val() : {};
      const list = Object.entries(items).map(([id, it]) => ({
        id,
        name: it && it.name,
        price: (it && it.price) || 0,
      }));
      bossTerminalPendingItemsList = list;
      if (list.length === 0) {
        bossTerminalMode = "awaiting_item_manual_name";
        bossTerminalPrint(`「${category}」目前沒有品項，請直接輸入品名：`);
      } else {
        const lines = list
          .map((it, i) => `${i + 1}) ${it.name}（$${it.price}）`)
          .join("\n");
        bossTerminalMode = "awaiting_item_choice";
        bossTerminalPrint(
          `分類：${category}\n${lines}\n0) 手動輸入新品項\n請輸入數字選擇：`
        );
      }
    } catch (err) {
      console.error("讀取品項失敗：", err);
      bossTerminalMode = "idle";
      bossTerminalPrint("讀取品項失敗，請確認網路連線後再試一次。");
    }
    return;
  }

  if (bossTerminalMode === "awaiting_item_choice") {
    const choice = value.trim();
    if (choice === "0") {
      bossTerminalMode = "awaiting_item_manual_name";
      bossTerminalPrint("請輸入品名：");
      return;
    }
    const list = bossTerminalPendingItemsList || [];
    const idx = parseInt(choice, 10);
    if (isNaN(idx) || idx < 1 || idx > list.length) {
      bossTerminalPrint(`無效的選擇，請輸入 0~${list.length} 之間的數字：`);
      return;
    }
    const item = list[idx - 1];
    bossTerminalPendingItemName = item.name;
    bossTerminalPendingItemPrice = item.price;
    bossTerminalMode = "awaiting_item_qty";
    bossTerminalPrint(`請輸入數量（單價 $${item.price}）：`);
    return;
  }

  if (bossTerminalMode === "awaiting_item_manual_name") {
    const name = value.trim();
    if (!name) {
      bossTerminalPrint("品名不能是空的，請重新輸入：");
      return;
    }
    bossTerminalPendingItemName = name;
    bossTerminalMode = "awaiting_item_manual_price";
    bossTerminalPrint("請輸入單價：");
    return;
  }

  if (bossTerminalMode === "awaiting_item_manual_price") {
    const priceText = value.trim();
    if (priceText === "" || isNaN(Number(priceText))) {
      bossTerminalPrint("單價必須是數字，請重新輸入：");
      return;
    }
    bossTerminalPendingItemPrice = Number(priceText);
    bossTerminalMode = "awaiting_item_qty";
    bossTerminalPrint("請輸入數量：");
    return;
  }

  if (bossTerminalMode === "awaiting_item_qty") {
    if (!currentRecordKey) {
      bossTerminalMode = "idle";
      bossTerminalPrint("目前沒有開啟中的車牌資料，取消新增。");
      return;
    }
    const qtyText = value.trim();
    if (qtyText === "" || isNaN(Number(qtyText))) {
      bossTerminalPrint("數量必須是數字，請重新輸入：");
      return;
    }
    const qty = Number(qtyText);
    const name = bossTerminalPendingItemName;
    const price = bossTerminalPendingItemPrice;
    const category = bossTerminalPendingCategory;
    addLockedRepairItemRow(name, qty, price, category);
    if (typeof window.recalcRepairTotal === "function") {
      window.recalcRepairTotal();
    }
    bossTerminalPrint(
      `已新增項目：${name} x ${qty}（單價 $${price}，小計 $${
        qty * price
      }）`
    );
    bossTerminalMode = "idle";
    bossTerminalPendingCategory = null;
    bossTerminalPendingItemsList = [];
    bossTerminalPendingItemName = null;
    bossTerminalPendingItemPrice = null;
    return;
  }

  if (bossTerminalMode === "awaiting_admin_password") {
    bossTerminalMode = "idle";
    setBossTerminalMasked(false);
    try {
      const snap = await get(ref(db, "appSettings/bossPasswordHash"));
      const storedHash = snap.exists() ? snap.val() : null;
      if (!storedHash) {
        bossTerminalPrint("尚未設定過密碼，請先輸入 sudo boss passwdadd 設定密碼。");
        return;
      }
      const enteredHash = await sha256Hex(value);
      if (enteredHash === storedHash) {
        adminModeUnlocked = true;
        bossTerminalPrint("密碼正確，已進入管理員模式。");
      } else {
        bossTerminalPrint("密碼錯誤。");
      }
    } catch (err) {
      console.error("驗證管理員密碼失敗：", err);
      bossTerminalPrint("驗證失敗，請確認網路連線後再試一次。");
    }
    return;
  }

  if (bossTerminalMode === "awaiting_forgot_password_letter_choice") {
    const choice = value.trim();
    const idx = parseInt(choice, 10);
    const options = bossTerminalPendingLetterOptions || [];
    if (isNaN(idx) || idx < 1 || idx > options.length) {
      bossTerminalPrint(`無效的選擇，請輸入 1~${options.length} 之間的數字：`);
      return;
    }
    bossTerminalPendingSelectedLetters = options[idx - 1];
    bossTerminalMode = "awaiting_forgot_password_digits";
    setBossTerminalMasked(true);
    bossTerminalPrint("請輸入信箱收到的驗證金鑰（6 位數字）：");
    return;
  }

  if (bossTerminalMode === "awaiting_forgot_password_digits") {
    bossTerminalMode = "idle";
    setBossTerminalMasked(false);
    const selectedLetters = bossTerminalPendingSelectedLetters;
    bossTerminalPendingLetterOptions = [];
    bossTerminalPendingSelectedLetters = null;
    try {
      if (
        !window.electronAPI ||
        typeof window.electronAPI.verifyPasswordResetCode !== "function"
      ) {
        bossTerminalPrint("找不到驗證功能，請確認程式版本。");
        return;
      }
      const fullCode = (selectedLetters || "") + value.trim();
      const result = await window.electronAPI.verifyPasswordResetCode(
        fullCode
      );
      if (result && result.ok) {
        bossTerminalMode = "awaiting_new_password";
        setBossTerminalMasked(true);
        bossTerminalPrint("驗證碼正確，請直接輸入新密碼：");
      } else if (result && result.reason === "expired") {
        bossTerminalPrint(
          "驗證碼已過期，請重新輸入 sudo boss forgot 再寄一次。"
        );
      } else {
        bossTerminalPrint("驗證碼錯誤，已取消。");
      }
    } catch (err) {
      console.error("驗證驗證碼失敗：", err);
      bossTerminalPrint("驗證失敗，請稍後再試一次。");
    }
    return;
  }

  if (bossTerminalMode === "awaiting_forgot_password_email") {
    const email = value.trim();
    bossTerminalMode = "idle";
    if (!email) {
      bossTerminalPrint("未輸入信箱，已取消。");
      return;
    }
    bossTerminalPrint("正在寄送驗證碼到信箱，請稍候...");
    try {
      if (
        !window.electronAPI ||
        typeof window.electronAPI.sendPasswordResetCode !== "function"
      ) {
        bossTerminalPrint("找不到寄信功能，請確認程式版本。");
        return;
      }
      const result = await window.electronAPI.sendPasswordResetCode(email);
      if (result && result.ok && Array.isArray(result.letterOptions)) {
        bossTerminalPendingLetterOptions = result.letterOptions;
        bossTerminalMode = "awaiting_forgot_password_letter_choice";
        const lines = result.letterOptions
          .map((letters, i) => `${i + 1}) ${letters}`)
          .join("\n");
        bossTerminalPrint(
          `驗證碼已寄出，請選出信箱裡看到的授權代碼（4 碼英文字母，輸入對應的數字）：\n${lines}`
        );
      } else if (result && result.error === "not_authorized") {
        // 故意用跟「寄送失敗」一樣的說法，不透露是信箱不在名單裡。
        bossTerminalPrint("驗證碼寄送失敗，請確認信箱是否正確後再試一次。");
      } else {
        bossTerminalPrint("驗證碼寄送失敗，請確認網路連線後再試一次。");
      }
    } catch (err) {
      console.error("寄送驗證碼失敗：", err);
      bossTerminalPrint("寄送失敗，請確認網路連線後再試一次。");
    }
    return;
  }


  // -------- 一般指令模式 --------
  if (value === "") return;
  const cmd = value.toLowerCase();


  if (cmd === "sudo boss passwdadd") {
    let hasPassword = false;
    try {
      const snap = await get(ref(db, "appSettings/bossPasswordHash"));
      hasPassword = snap.exists();
    } catch (err) {
      console.error("讀取 boss 密碼設定失敗：", err);
      bossTerminalPrint("讀取失敗，請確認網路連線後再試一次。");
      return;
    }
    if (hasPassword) {
      bossTerminalMode = "awaiting_current_password_for_change";
      setBossTerminalMasked(true);
      bossTerminalPrint("已經設定過密碼，請先輸入目前的密碼：");
    } else {
      bossTerminalMode = "awaiting_new_password";
      setBossTerminalMasked(true);
      bossTerminalPrint("尚未設定過密碼，請直接輸入新密碼：");
    }
    return;
  }

  if (cmd === "sudo boss forgot") {
    bossTerminalMode = "awaiting_forgot_password_email";
    bossTerminalPrint("請輸入收件信箱：");
    return;
  }

  if (cmd === "sudo boss") {
    let hasPassword = false;
    try {
      const snap = await get(ref(db, "appSettings/bossPasswordHash"));
      hasPassword = snap.exists();
    } catch (err) {
      console.error("讀取 boss 密碼設定失敗：", err);
      bossTerminalPrint("讀取失敗，請確認網路連線後再試一次。");
      return;
    }
    if (!hasPassword) {
      bossTerminalPrint("尚未設定過密碼，請先輸入 sudo boss passwdadd 設定密碼。");
      return;
    }
    bossTerminalMode = "awaiting_password";
    setBossTerminalMasked(true);
    bossTerminalPrint("請輸入密碼：");
    return;
  }

  if (cmd === "help") {
    if (bossModeUnlocked) {
      printBossHelp();
      return;
    }
    let hasPassword = false;
    try {
      const snap = await get(ref(db, "appSettings/bossPasswordHash"));
      hasPassword = snap.exists();
    } catch (err) {
      console.error("讀取 boss 密碼設定失敗：", err);
      bossTerminalPrint("讀取失敗，請確認網路連線後再試一次。");
      return;
    }
    if (!hasPassword) {
      bossTerminalPrint("尚未設定過密碼，請先輸入 sudo boss passwdadd 設定密碼。");
      return;
    }
    bossPasswordPurpose = "help";
    bossTerminalMode = "awaiting_password";
    setBossTerminalMasked(true);
    bossTerminalPrint("指令說明需要先輸入密碼才能查看，請輸入密碼：");
    return;
  }

  if (cmd === "revenue" || value === "業績") {
    if (!bossModeUnlocked) {
      bossTerminalPrint("請先輸入 sudo boss 解鎖 boss 模式。");
      return;
    }
    await showBossRevenueReport();
    return;
  }

  if (cmd === "clear") {
    bossTerminalLines = [];
    renderBossTerminalOutput();
    return;
  }

  if (cmd === "sudo test network") {
    bossTerminalPrint("正在測試網路，請稍候（會連續 ping 幾次，大約幾秒鐘）...");
    try {
      if (!navigator.onLine) {
        bossTerminalPrint("目前離線中，無法測試網路（分數：0 / 100）");
        return;
      }

      let isWifi = null;
      let pingMs = null;
      let lossPercent = null;
      let jitterMs = null;
      if (
        window.electronAPI &&
        typeof window.electronAPI.getNetworkDiagnostics === "function"
      ) {
        const result = await window.electronAPI.getNetworkDiagnostics();
        isWifi = result ? result.isWifi : null;
        pingMs = result ? result.pingMs : null;
        lossPercent = result ? result.lossPercent : null;
        jitterMs = result ? result.jitterMs : null;
      }

      const fbStart = performance.now();
      let firebaseOk = true;
      try {
        await get(ref(db, "appSettings"));
      } catch (err) {
        firebaseOk = false;
      }
      const firebaseMs = Math.round(performance.now() - fbStart);

      // 計分：PING 30 分、封包遺失率 20 分、PING 抖動 20 分、
      // 跟伺服器（Firebase）實際來回時間 30 分，加起來滿分 100。
      let pingScore;
      if (pingMs === null || pingMs === undefined) {
        pingScore = 10; // 量不到 PING，先給偏低的分數
      } else if (pingMs < 15) pingScore = 30;
      else if (pingMs < 30) pingScore = 27;
      else if (pingMs < 60) pingScore = 22;
      else if (pingMs < 90) pingScore = 18;
      else if (pingMs < 150) pingScore = 10;
      else pingScore = 3;

      let lossScore;
      if (lossPercent === null || lossPercent === undefined) {
        lossScore = 10;
      } else if (lossPercent <= 0) lossScore = 20;
      else if (lossPercent <= 2) lossScore = 17;
      else if (lossPercent <= 5) lossScore = 12;
      else if (lossPercent <= 15) lossScore = 6;
      else lossScore = 0;

      let jitterScore;
      if (jitterMs === null || jitterMs === undefined) {
        jitterScore = 10;
      } else if (jitterMs < 5) jitterScore = 20;
      else if (jitterMs < 10) jitterScore = 17;
      else if (jitterMs < 20) jitterScore = 13;
      else if (jitterMs < 40) jitterScore = 8;
      else jitterScore = 2;

      let fbScore;
      if (!firebaseOk) fbScore = 0;
      else if (firebaseMs < 150) fbScore = 30;
      else if (firebaseMs < 300) fbScore = 26;
      else if (firebaseMs < 600) fbScore = 21;
      else if (firebaseMs < 1200) fbScore = 15;
      else if (firebaseMs < 2500) fbScore = 7;
      else fbScore = 3;

      const total = pingScore + lossScore + jitterScore + fbScore;
      let grade;
      if (total >= 90) grade = "A+（非常快）";
      else if (total >= 75) grade = "A（良好）";
      else if (total >= 60) grade = "B（普通）";
      else if (total >= 40) grade = "C（偏慢）";
      else grade = "D（很慢，建議檢查網路）";

      bossTerminalPrint(
        [
          "網路詳細測試結果：",
          `連線方式：${
            isWifi === null ? "未知" : isWifi ? "WiFi" : "有線網路"
          }`,
          `PING：${
            pingMs === null || pingMs === undefined
              ? "無法量測"
              : pingMs + " ms"
          }`,
          `封包遺失率：${
            lossPercent === null || lossPercent === undefined
              ? "無法量測"
              : lossPercent + " %"
          }`,
          `PING 抖動（Jitter）：${
            jitterMs === null || jitterMs === undefined
              ? "無法量測"
              : jitterMs + " ms"
          }`,
          `連線到伺服器（Firebase）來回時間：${
            firebaseOk ? firebaseMs + " ms" : "連線失敗"
          }`,
          "",
          `網路分數：${total} / 100（${grade}）`,
        ].join("\n")
      );
    } catch (err) {
      console.error("測試網路失敗：", err);
      bossTerminalPrint("測試失敗，請稍後再試一次。");
    }
    return;
  }

  if (cmd.startsWith("cd ")) {
    const rawPlate = value.slice(3).trim();
    if (!rawPlate) {
      bossTerminalPrint("請輸入車牌，例如：cd ABC-1234");
      return;
    }
    const pureInput = rawPlate.replace(/-/g, "");
    const key = pureInput.toUpperCase();
    bossTerminalPrint(`正在切換到車牌：${rawPlate} ...`);
    try {
      addRecentSearch(rawPlate);
      await openDetailPage(rawPlate, key);
      bossTerminalPrint(
        `已切換到車牌：${rawPlate}（維修資料已在背景備好，畫面不會跳出，可以繼續下指令）`
      );
    } catch (err) {
      console.error("切換車牌失敗：", err);
      bossTerminalPrint("切換失敗，請確認網路連線後再試一次。");
    }
    return;
  }

  if (cmd === "sudo select") {
    if (!currentRecordKey) {
      bossTerminalPrint("請先用 cd 車牌 開啟一筆資料，才能選分類。");
      return;
    }
    bossTerminalMode = "awaiting_item_category_choice";
    bossTerminalPrint(
      "請選擇分類（輸入數字）：\n" +
        ITEM_CATEGORIES.map((c, i) => `${i + 1}) ${c}`).join("\n")
    );
    return;
  }

  if (cmd === "sudo mileage") {
    if (!currentRecordKey) {
      bossTerminalPrint("請先用 cd 車牌 開啟一筆資料，才能輸入里程。");
      return;
    }
    bossTerminalMode = "awaiting_mileage_value";
    bossTerminalPrint("請輸入本次里程數：");
    return;
  }

  if (cmd === "sudo technician") {
    if (!currentRecordKey) {
      bossTerminalPrint("請先用 cd 車牌 開啟一筆資料，才能選技師。");
      return;
    }
    bossTerminalMode = "awaiting_technician_choice";
    bossTerminalPrint("請選擇技師：\n1) 阿翰\n2) 明松\n3) 自行輸入");
    return;
  }

  if (cmd === "saveadd") {
    if (!currentRecordKey) {
      bossTerminalPrint("請先用 cd 車牌 開啟一筆資料，才能儲存。");
      return;
    }
    const hasItem = Array.from(
      document.querySelectorAll("#repair_items_body tr")
    ).some((row) => row.querySelector(".repair_item_name")?.value.trim());
    if (!hasItem) {
      bossTerminalPrint("請先用 sudo select 新增至少一項維修品項，才能儲存。");
      return;
    }
    if (!getMechanicName()) {
      bossTerminalPrint("請先用 sudo technician 選擇技師，才能儲存。");
      return;
    }
    const ok = await window.saveRepairRecord(false);
    if (ok) {
      bossTerminalPrint("維修資料已儲存完成。");
    } else {
      bossTerminalPrint("儲存失敗或資料不完整，請確認後再試一次。");
    }
    return;
  }

  if (cmd === "saveestimateadd") {
    if (!currentRecordKey) {
      bossTerminalPrint("請先用 cd 車牌 開啟一筆資料，才能儲存估價。");
      return;
    }
    const hasItem = Array.from(
      document.querySelectorAll("#repair_items_body tr")
    ).some((row) => row.querySelector(".repair_item_name")?.value.trim());
    if (!hasItem) {
      bossTerminalPrint("請先用 sudo select 新增至少一項估價品項，才能儲存。");
      return;
    }
    const ok = await window.saveEstimateRecord();
    if (ok) {
      bossTerminalPrint("估價已儲存完成。");
    } else {
      bossTerminalPrint("儲存失敗或資料不完整，請確認後再試一次。");
    }
    return;
  }

  if (cmd === "sudo admin") {
    if (adminModeUnlocked) {
      adminModeUnlocked = false;
      bossTerminalPrint("已離開管理員模式。");
      return;
    }
    bossTerminalMode = "awaiting_admin_password";
    setBossTerminalMasked(true);
    bossTerminalPrint("請輸入管理員密碼：");
    return;
  }

  if (cmd === "sudo serverdata" && adminModeUnlocked) {
    bossTerminalPrint("正在讀取伺服器資料，請稍候...");
    try {
      const recordsSnap = await get(ref(db, "records"));
      const records = recordsSnap.exists() ? recordsSnap.val() : {};
      const plateCount = Object.keys(records).length;
      let repairCount = 0;
      let estimateCount = 0;
      Object.values(records).forEach((rec) => {
        if (rec && rec.repairs)
          repairCount += Object.keys(rec.repairs).length;
        if (rec && rec.estimates)
          estimateCount += Object.keys(rec.estimates).length;
      });

      const catalogSnap = await get(ref(db, "itemCatalog"));
      const catalog = catalogSnap.exists() ? catalogSnap.val() : {};
      let itemCount = 0;
      Object.values(catalog).forEach((cat) => {
        itemCount += Object.keys(cat || {}).length;
      });

      const pendingSnap = await get(ref(db, "pendingMileage"));
      const pendingCount = pendingSnap.exists()
        ? Object.keys(pendingSnap.val()).length
        : 0;

      bossTerminalPrint(
        [
          "伺服器資料（Firebase）：",
          `車牌／卡號筆數：${plateCount} 筆`,
          `維修紀錄總數：${repairCount} 筆`,
          `估價紀錄總數：${estimateCount} 筆`,
          `品項總數（所有分類加總）：${itemCount} 項`,
          `待補里程提醒：${pendingCount} 筆`,
        ].join("\n")
      );
    } catch (err) {
      console.error("讀取伺服器資料失敗：", err);
      bossTerminalPrint("讀取失敗，請確認網路連線後再試一次。");
    }
    return;
  }

  if (cmd === "sudo serverdata delete" && adminModeUnlocked) {
    window.openDangerDeleteModal("server");
    return;
  }

  if (cmd === "sudo data" && adminModeUnlocked) {
    try {
      let info = null;
      let queue = [];
      if (window.electronAPI) {
        if (typeof window.electronAPI.getLocalCacheInfo === "function") {
          info = await window.electronAPI.getLocalCacheInfo();
        }
        if (typeof window.electronAPI.readOfflineQueue === "function") {
          queue = await window.electronAPI.readOfflineQueue();
        }
      }
      const sizeKb = info ? (info.sizeBytes / 1024).toFixed(1) : "0";
      const mtimeStr = info
        ? new Date(info.mtime).toLocaleString("zh-TW")
        : "尚未同步過";
      bossTerminalPrint(
        [
          "本機資料：",
          `車籍資料庫快取檔案大小：${sizeKb} KB`,
          `最後同步時間：${mtimeStr}`,
          `離線佇列（尚未上傳的維修紀錄）：${
            Array.isArray(queue) ? queue.length : 0
          } 筆`,
        ].join("\n")
      );
    } catch (err) {
      console.error("讀取本機資料失敗：", err);
      bossTerminalPrint("讀取本機資料失敗。");
    }
    return;
  }

  if (cmd === "sudo data delete" && adminModeUnlocked) {
    window.openDangerDeleteModal("local");
    return;
  }

  if (cmd === "sudo mileage later add" || cmd === "sudo mileage latter add") {
    if (!currentRecordKey) {
      bossTerminalPrint("請先用 cd 車牌 開啟一筆資料，才能補登。");
      return;
    }
    const hasItem = Array.from(
      document.querySelectorAll("#repair_items_body tr")
    ).some((row) => row.querySelector(".repair_item_name")?.value.trim());
    if (!hasItem) {
      bossTerminalPrint("請先用 sudo select 新增至少一項維修品項，才能儲存。");
      return;
    }
    if (!getMechanicName()) {
      bossTerminalPrint("請先用 sudo technician 選擇技師，才能儲存。");
      return;
    }
    const ok = await window.saveRepairRecord(true);
    if (ok) {
      bossTerminalPrint("已存檔，里程晚點補登。");
    } else {
      bossTerminalPrint("儲存失敗或資料不完整，請確認後再試一次。");
    }
    return;
  }

  if (cmd === "exit" || cmd === "quit") {
    window.closeBossTerminal();
    return;
  }

  bossTerminalPrint(`指令不存在：${value}（輸入 help 查看可用指令）`);
}

window.openHiddenSettingsModal = function () {
  settingsCurrentPage = "main";
  settingsPageStack = [];
  renderHiddenSettingsBody();
  const modal = document.getElementById("hidden_settings_modal");
  modal.classList.remove("hidden");
  modal.classList.add("flex");
};

window.closeHiddenSettingsModal = function () {
  if (settingsConnectedUnsubscribe) {
    settingsConnectedUnsubscribe();
    settingsConnectedUnsubscribe = null;
  }
  const modal = document.getElementById("hidden_settings_modal");
  modal.classList.add("hidden");
  modal.classList.remove("flex");
};

window.settingsGoBack = function () {
  if (settingsConnectedUnsubscribe) {
    settingsConnectedUnsubscribe();
    settingsConnectedUnsubscribe = null;
  }
  settingsCurrentPage = settingsPageStack.pop() || "main";
  renderHiddenSettingsBody();
};

window.settingsNavigateTo = function (page) {
  settingsPageStack.push(settingsCurrentPage);
  settingsCurrentPage = page;
  renderHiddenSettingsBody();
};

// iOS 設定風格的一個分組清單：白底圓角卡片，裡面每一列用細線分隔
function settingsGroupHtml(rowsHtml) {
  return `<div class="bg-white rounded-xl overflow-hidden shadow-sm mb-4 divide-y divide-gray-100">${rowsHtml}</div>`;
}

// 一列「可以點進去」的設定項目，右邊帶淡灰色的目前數值 + 箭頭
function settingsNavRowHtml(label, valueText, page) {
  return `
    <button onclick="window.settingsNavigateTo('${page}')"
      class="w-full flex items-center justify-between px-4 py-3.5 text-left hover:bg-gray-50 active:bg-gray-100 transition">
      <span class="text-gray-800 font-medium">${label}</span>
      <span class="flex items-center gap-1.5 text-gray-400 text-sm">
        ${valueText ? `<span>${valueText}</span>` : ""}
        <span class="text-gray-300">›</span>
      </span>
    </button>`;
}

// 一列「純顯示資訊」的設定項目，不能點，左邊標籤、右邊數值
function settingsInfoRowHtml(label, valueText) {
  return `
    <div class="w-full flex items-center justify-between px-4 py-3.5">
      <span class="text-gray-500">${label}</span>
      <span class="text-gray-800 font-medium text-right">${valueText}</span>
    </div>`;
}

function renderHiddenSettingsBody() {
  const body = document.getElementById("hidden_settings_body");
  const titleEl = document.getElementById("settings_page_title");
  const backBtn = document.getElementById("settings_back_btn");

  if (settingsCurrentPage !== "main") {
    backBtn.classList.remove("hidden");
    backBtn.classList.add("flex");
  } else {
    backBtn.classList.add("hidden");
    backBtn.classList.remove("flex");
  }

  if (settingsConnectedUnsubscribe && settingsCurrentPage !== "server") {
    settingsConnectedUnsubscribe();
    settingsConnectedUnsubscribe = null;
  }

  if (settingsCurrentPage === "main") {
    titleEl.textContent = "設定";
    body.innerHTML = `
      <div class="max-w-lg mx-auto">
        ${settingsGroupHtml(
          settingsNavRowHtml("一般", "", "general")
        )}
        ${settingsGroupHtml(
          settingsNavRowHtml("儲存空間", "", "storage") +
            settingsNavRowHtml("伺服器", "", "server")
        )}
      </div>
    `;
    return;
  }

  if (settingsCurrentPage === "general") {
    titleEl.textContent = "一般";
    body.innerHTML = `
      <div class="max-w-lg mx-auto">
        ${settingsGroupHtml(
          settingsNavRowHtml("鍵盤", "", "keyboard") +
            settingsNavRowHtml("進貨系統設定", "", "stock_settings") +
            settingsNavRowHtml("分類選單一頁品項數", String(appPickerPageSize), "display")
        )}
        <button onclick="window.openFactoryResetModal()"
          class="w-full bg-white rounded-xl overflow-hidden shadow-sm mb-4 px-4 py-3.5 text-left text-red-600 font-medium hover:bg-red-50 active:bg-red-100 transition">
          清除所有設定內容（原廠設定）
        </button>
        <p class="text-xs text-gray-400 px-1 -mt-2 mb-4">會清除系統上所有的車籍、維修紀錄、品項分類與系統設定，且無法復原。</p>
      </div>
    `;
    return;
  }

  if (settingsCurrentPage === "keyboard") {
    titleEl.textContent = "鍵盤";
    body.innerHTML = `
      <div class="max-w-lg mx-auto">
        <div class="bg-white rounded-xl shadow-sm p-4 mb-4 flex items-center justify-between gap-3">
          <div>
            <div class="text-gray-800 font-medium">智慧鍵盤</div>
            <div class="text-xs text-gray-400 mt-0.5">自動判斷車牌／電話／卡號，自動補橫線、跳出區碼選單</div>
          </div>
          <button onclick="window.toggleSmartKeyboard()" id="settings_smart_keyboard_toggle"
            class="w-12 h-7 rounded-full transition flex-shrink-0 relative ${
              appSmartKeyboardEnabled ? "bg-green-500" : "bg-gray-300"
            }">
            <span class="absolute top-0.5 ${
              appSmartKeyboardEnabled ? "left-6" : "left-0.5"
            } w-6 h-6 bg-white rounded-full shadow transition"></span>
          </button>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-4 mb-2">
          <label class="text-sm font-bold text-gray-500 block mb-2">車牌上限字元（不含橫線）</label>
          <div class="flex items-center gap-2">
            <input type="number" min="1" step="1" id="settings_plate_max_length"
              value="${appPlateMaxLength}"
              class="border-2 border-gray-300 rounded-lg px-3 py-2 w-28 text-gray-800 font-bold focus:border-blue-500 focus:outline-none" />
            <button onclick="window.savePlateMaxLength()"
              class="px-4 py-2 text-sm font-bold rounded-lg shadow transition"
              style="background-color: #0f766e; color: #ffffff">
              儲存
            </button>
          </div>
          <p id="settings_plate_max_length_status" class="text-xs text-teal-600 font-bold h-4 mt-2"></p>
        </div>
        <p class="text-xs text-gray-400 px-1">存檔後所有裝置會立刻套用新的設定。</p>
      </div>
    `;
    return;
  }

  if (settingsCurrentPage === "stock_settings") {
    titleEl.textContent = "進貨系統設定";
    body.innerHTML = `
      <div class="max-w-lg mx-auto">
        <div class="bg-white rounded-xl shadow-sm p-4 mb-2">
          <p class="text-xs text-gray-400 mb-4">設定「進貨/庫存管理」跟品項選單上，庫存數字要低到多少才顯示紅色（缺貨）、多少才顯示黃色（偏低），以及低到多少才會出現在信箱通知裡提醒補貨。</p>

          <div class="flex items-center justify-between gap-3 py-2.5 border-b border-gray-100">
            <label class="text-sm font-bold text-gray-700 flex items-center gap-2">
              <span class="w-3.5 h-3.5 rounded-full bg-red-500 inline-block flex-shrink-0"></span>
              紅色（缺貨）門檻
            </label>
            <input type="number" min="0" step="1" id="settings_stock_red_threshold"
              value="${appStockRedThreshold}"
              class="border-2 border-gray-300 rounded-lg px-3 py-2 w-24 text-gray-800 font-bold text-right focus:border-red-500 focus:outline-none" />
          </div>
          <p class="text-xs text-gray-400 pt-1.5 pb-2 border-b border-gray-100">庫存 ≤ 這個數字時顯示紅色（例：填 0 就是庫存見底才算缺貨）</p>

          <div class="flex items-center justify-between gap-3 py-2.5 border-b border-gray-100 mt-2">
            <label class="text-sm font-bold text-gray-700 flex items-center gap-2">
              <span class="w-3.5 h-3.5 rounded-full bg-yellow-400 inline-block flex-shrink-0"></span>
              黃色（偏低）門檻
            </label>
            <input type="number" min="0" step="1" id="settings_stock_yellow_threshold"
              value="${appStockYellowThreshold}"
              class="border-2 border-gray-300 rounded-lg px-3 py-2 w-24 text-gray-800 font-bold text-right focus:border-yellow-500 focus:outline-none" />
          </div>
          <p class="text-xs text-gray-400 pt-1.5 pb-2 border-b border-gray-100">庫存 ≤ 這個數字（但大於紅色門檻）時顯示黃色；比這個數字多就是綠色（充足）</p>

          <div class="flex items-center justify-between gap-3 py-2.5 mt-2">
            <label class="text-sm font-bold text-gray-700 flex items-center gap-2">
              通知門檻
            </label>
            <input type="number" min="0" step="1" id="settings_stock_notify_threshold"
              value="${appStockNotifyThreshold}"
              class="border-2 border-gray-300 rounded-lg px-3 py-2 w-24 text-gray-800 font-bold text-right focus:border-teal-500 focus:outline-none" />
          </div>
          <p class="text-xs text-gray-400 pt-1.5 pb-3">庫存 ≤ 這個數字時，會出現在信箱通知清單裡提醒要補貨</p>

          <button onclick="window.saveStockThresholds()"
            class="w-full px-4 py-2 text-sm font-bold rounded-lg shadow transition"
            style="background-color: #0f766e; color: #ffffff">
            儲存
          </button>
          <p id="settings_stock_threshold_status" class="text-xs text-teal-600 font-bold h-4 mt-2"></p>
        </div>
        <p class="text-xs text-gray-400 px-1">存檔後所有裝置會立刻套用新的設定。</p>
      </div>
    `;
    return;
  }

  if (settingsCurrentPage === "display") {
    titleEl.textContent = "顯示";
    body.innerHTML = `
      <div class="max-w-lg mx-auto">
        <div class="bg-white rounded-xl shadow-sm p-4 mb-2">
          <label class="text-sm font-bold text-gray-500 block mb-2">分類選單一頁顯示幾個品項</label>
          <div class="flex items-center gap-2">
            <input type="number" min="1" step="1" id="settings_picker_page_size"
              value="${appPickerPageSize}"
              class="border-2 border-gray-300 rounded-lg px-3 py-2 w-28 text-gray-800 font-bold focus:border-blue-500 focus:outline-none" />
            <button onclick="window.saveHiddenSettings()"
              class="px-4 py-2 text-sm font-bold rounded-lg shadow transition"
              style="background-color: #0f766e; color: #ffffff">
              儲存
            </button>
          </div>
          <p id="settings_save_status" class="text-xs text-teal-600 font-bold h-4 mt-2"></p>
        </div>
        <p class="text-xs text-gray-400 px-1">存檔後所有裝置會立刻套用新的一頁品項數。</p>
      </div>
    `;
    return;
  }

  // 「儲存空間」選單頁：只分兩條路——本機空間、遠端空間，各自的資料抓取跟
  // 危險操作（清除所有資料）都放到各自的子頁面裡，兩邊完全分開、互不影響。
  if (settingsCurrentPage === "storage") {
    titleEl.textContent = "儲存空間";
    body.innerHTML = `
      <div class="max-w-lg mx-auto">
        ${settingsGroupHtml(
          settingsNavRowHtml("本機空間", "", "storage_local") +
            settingsNavRowHtml("遠端空間", "", "storage_remote")
        )}
        <p class="text-xs text-gray-400 px-1">
          「本機空間」是這台電腦硬碟上的資料。「遠端空間」是存在伺服器（Firebase）上、
          全公司共用的資料庫。點進去可以分別查看用量，也可以分別清除資料。
        </p>
      </div>
    `;
    return;
  }

  // 「本機空間」子頁：這台電腦硬碟的實際容量、本機快取／離線佇列狀況，
  // 以及只會動到「這台電腦」的清除操作。
  if (settingsCurrentPage === "storage_local") {
    titleEl.textContent = "本機空間";
    const cachedCount = recordCache.size;
    const pendingCount = offlineQueue.length;
    const lastSyncText = lastFullSyncAt
      ? new Date(lastFullSyncAt).toLocaleString("zh-TW", { hour12: false })
      : "這次開機還沒同步過";
    body.innerHTML = `
      <div class="max-w-lg mx-auto">
        ${settingsGroupHtml(
          `<div id="settings_local_disk_space_row">${settingsInfoRowHtml(
            "本機空間",
            "讀取中…"
          )}</div>`
        )}
        <p class="text-xs text-gray-400 px-1 mb-4">
          這是這台電腦硬碟的實際已用／總容量，跟下面「硬碟快取檔案大小」不一樣
          （那個只是本程式自己這份快取檔案的大小）。
        </p>
        ${settingsGroupHtml(
          settingsInfoRowHtml("本機記憶體已載入的車籍筆數", `${cachedCount} 筆`) +
            settingsInfoRowHtml("上次完整同步到硬碟的時間", lastSyncText) +
            `<div id="settings_local_cache_size_row">${settingsInfoRowHtml(
              "硬碟快取檔案大小",
              "讀取中…"
            )}</div>` +
            settingsInfoRowHtml(
              "待上傳的離線維修紀錄",
              pendingCount > 0 ? `${pendingCount} 筆` : "沒有"
            )
        )}
        <p class="text-xs text-gray-400 px-1 mb-4">
          有連上網路時（登入成功、或斷線後恢復連線），系統會自動把完整的車籍／維修紀錄資料庫
          存一份到這台電腦的硬碟（不是只存在記憶體），這樣就算之後突然斷網、甚至換到一台全新的
          電腦重灌本程式，只要能再連得上網路完整同步過一次，之後離線時一樣查得到所有車籍資料。
          「待上傳的離線維修紀錄」是斷網時新增的維修紀錄，恢復網路後會自動補傳，在補傳完成前請不要清除。
        </p>
        ${settingsGroupHtml(
          `<button onclick="window.settingsOpenLocalDataFolder()"
            class="w-full flex items-center justify-between px-4 py-3.5 text-left hover:bg-gray-50 active:bg-gray-100 transition">
            <span class="font-medium" style="color: #0f766e">開啟本機資料夾</span>
          </button>` +
            `<button onclick="window.settingsSyncNow()"
            class="w-full flex items-center justify-between px-4 py-3.5 text-left hover:bg-gray-50 active:bg-gray-100 transition">
            <span class="font-medium" style="color: #0f766e">立即完整同步到硬碟</span>
          </button>` +
            `<button onclick="window.settingsClearLocalCache()"
            class="w-full flex items-center justify-between px-4 py-3.5 text-left hover:bg-gray-50 active:bg-gray-100 transition">
            <span class="font-medium" style="color: #dc2626">清除本機快取（含硬碟檔案）</span>
          </button>`
        )}
        <p class="text-xs text-gray-400 px-1 mb-1">
          本機檔案存在：<span class="font-mono" id="settings_local_data_path">%APPDATA%\yongxin-motorcycle-shop\offline-data\</span>
        </p>
        ${settingsGroupHtml(
          `<button onclick="window.settingsClearAllLocalData()"
            class="w-full flex items-center justify-between px-4 py-3.5 text-left hover:bg-red-50 active:bg-red-100 transition">
            <span class="font-bold" style="color: #dc2626">清除本機所有資料</span>
          </button>`
        )}
        <p class="text-xs text-red-500 px-1 mb-1">
          「清除本機所有資料」會把上面的本機快取，連同「待上傳的離線維修紀錄」一起整個刪掉，
          尚未上傳的維修紀錄會直接遺失、無法復原，請務必確認沒有待補傳資料再執行。
        </p>
        <p id="settings_storage_status" class="text-xs text-teal-600 font-bold h-4 px-1"></p>
      </div>
    `;

    // 本機空間是查這台電腦的磁碟資訊，不用網路，畫面一開就順便查一次
    (async () => {
      const row = document.getElementById("settings_local_disk_space_row");
      if (!row) return;
      try {
        const info = await window.electronAPI.getDiskSpace();
        if (info && typeof info.totalBytes === "number" && typeof info.freeBytes === "number") {
          const usedBytes = info.totalBytes - info.freeBytes;
          row.innerHTML = settingsInfoRowHtml(
            "本機空間",
            `${formatBytesForDisplay(usedBytes)} / ${formatBytesForDisplay(info.totalBytes)}`
          );
        } else {
          row.innerHTML = settingsInfoRowHtml("本機空間", "無法讀取");
        }
      } catch (err) {
        console.error("讀取本機磁碟空間失敗：", err);
        row.innerHTML = settingsInfoRowHtml("本機空間", "讀取失敗");
      }
    })();

    // 一開這個子頁就順便觸發一次「完整同步到硬碟」（背景執行，不卡畫面）。
    // 現在本機／遠端分成兩個子頁，各自打開各自的才觸發，不會互搶記憶體；
    // 這裡呼叫的是有防重入保護的版本，避免同步中重繪畫面又觸發新一輪同步。
    triggerLocalPageAutoSync();

    // 硬碟快取檔案大小是讀本機檔案，不用網路，畫面一開就順便查一次
    (async () => {
      const row = document.getElementById("settings_local_cache_size_row");
      if (!row) return;
      try {
        const info = await window.electronAPI.getLocalCacheInfo();
        row.innerHTML = settingsInfoRowHtml(
          "硬碟快取檔案大小",
          info ? formatBytesForDisplay(info.sizeBytes) : "還沒有硬碟快取"
        );
      } catch (err) {
        console.error("讀取硬碟快取檔案大小失敗：", err);
        row.innerHTML = settingsInfoRowHtml("硬碟快取檔案大小", "讀取失敗");
      }
    })();
    return;
  }

  // 「遠端空間」子頁：伺服器（Firebase）上的用量估算，以及會影響「全公司」
  // 所有電腦的清除操作，跟本機頁完全分開。
  if (settingsCurrentPage === "storage_remote") {
    titleEl.textContent = "遠端空間";
    body.innerHTML = `
      <div class="max-w-lg mx-auto">
        ${settingsGroupHtml(
          `<div id="settings_server_storage_row">${settingsInfoRowHtml(
            "遠端空間",
            "抓取中…"
          )}</div>`
        )}
        <p class="text-xs text-gray-400 px-1 mb-4">
          「遠端空間」是把整個資料庫抓下來、實際量出來的資料大小，打開這個頁面就會自動抓一次
          （會用到一點流量），上限 1GB 是 Firebase 免費方案的規定；數字都是估算值，不是官方
          帳單上的精確用量。
        </p>
        ${settingsGroupHtml(
          `<button onclick="window.settingsClearAllRemoteData()"
            class="w-full flex items-center justify-between px-4 py-3.5 text-left hover:bg-red-50 active:bg-red-100 transition">
            <span class="font-bold" style="color: #dc2626">清除遠端所有資料</span>
          </button>`
        )}
        <p class="text-xs text-red-500 px-1 mb-1">
          「清除遠端所有資料」會刪掉伺服器上「全部」的車籍、維修紀錄、品項分類與設定，
          全公司每一台電腦都會立刻受影響，且無法復原，請務必再三確認才執行。
        </p>
        <p id="settings_remote_storage_status" class="text-xs text-teal-600 font-bold h-4 px-1"></p>
      </div>
    `;

    // 一開這個子頁就順便估算一次遠端用量（背景執行，不卡畫面）。
    window.settingsCheckServerStorage();
    return;
  }

  if (settingsCurrentPage === "server") {
    titleEl.textContent = "伺服器";
    body.innerHTML = `
      <div class="max-w-lg mx-auto">
        ${settingsGroupHtml(
          settingsInfoRowHtml("Firebase 專案", firebaseConfig.projectId) +
            settingsInfoRowHtml("資料庫網址", firebaseConfig.databaseURL)
        )}
        ${settingsGroupHtml(
          settingsInfoRowHtml(
            "目前登入帳號",
            (auth.currentUser && auth.currentUser.email) || "未登入"
          ) +
            settingsInfoRowHtml(
              "網路狀態",
              isOnline ? "線上" : "離線"
            ) +
            `<div id="settings_server_connected_row">${settingsInfoRowHtml(
              "與伺服器連線",
              "確認中…"
            )}</div>`
        )}
      </div>
    `;

    // 即時監聽 Firebase 的連線狀態（跟網路是否連上網路線不完全一樣，這個是
    // 真的有沒有跟資料庫伺服器保持連線），只有停留在這個子頁面的時候才監聽。
    settingsConnectedUnsubscribe = onValue(ref(db, ".info/connected"), (snap) => {
      const row = document.getElementById("settings_server_connected_row");
      if (!row) return;
      row.innerHTML = settingsInfoRowHtml(
        "與伺服器連線",
        snap.val() === true ? "已連線" : "未連線"
      );
    });
    return;
  }
}

window.saveHiddenSettings = async function () {
  const input = document.getElementById("settings_picker_page_size");
  const val = Number(input.value);
  const statusEl = document.getElementById("settings_save_status");
  if (!Number.isInteger(val) || val < 1) {
    showAppAlert("請輸入 1 以上的整數！");
    return;
  }
  try {
    await set(ref(db, "appSettings/pickerPageSize"), val);
    appPickerPageSize = val;
    if (statusEl) statusEl.textContent = "已儲存！";
  } catch (err) {
    console.error("儲存設定失敗：", err);
    showAppAlert(`儲存失敗：${err.code || err.message || "未知錯誤"}`);
  }
};

// 智慧鍵盤開關：點一下直接存檔生效，不用另外按儲存（跟一般 iOS 設定頁的開關行為一致）。
window.toggleSmartKeyboard = async function () {
  const next = !appSmartKeyboardEnabled;
  try {
    await set(ref(db, "appSettings/smartKeyboardEnabled"), next);
    appSmartKeyboardEnabled = next;
    renderHiddenSettingsBody();
  } catch (err) {
    console.error("儲存設定失敗：", err);
    showAppAlert(`儲存失敗：${err.code || err.message || "未知錯誤"}`);
  }
};

window.savePlateMaxLength = async function () {
  const input = document.getElementById("settings_plate_max_length");
  const val = Number(input.value);
  const statusEl = document.getElementById("settings_plate_max_length_status");
  if (!Number.isInteger(val) || val < 1) {
    showAppAlert("請輸入 1 以上的整數！");
    return;
  }
  try {
    await set(ref(db, "appSettings/plateMaxLength"), val);
    appPlateMaxLength = val;
    if (statusEl) statusEl.textContent = "已儲存！";
  } catch (err) {
    console.error("儲存設定失敗：", err);
    showAppAlert(`儲存失敗：${err.code || err.message || "未知錯誤"}`);
  }
};

// 進貨系統設定：紅色（缺貨）／黃色（偏低）／通知門檻，三個都要是 0 以上的整數，
// 而且黃色門檻不能比紅色門檻小（不然顏色會顛倒，庫存偏低反而比缺貨還「安全」）。
window.saveStockThresholds = async function () {
  const redInput = document.getElementById("settings_stock_red_threshold");
  const yellowInput = document.getElementById("settings_stock_yellow_threshold");
  const notifyInput = document.getElementById("settings_stock_notify_threshold");
  const statusEl = document.getElementById("settings_stock_threshold_status");

  const red = Number(redInput.value);
  const yellow = Number(yellowInput.value);
  const notify = Number(notifyInput.value);

  if (!Number.isInteger(red) || red < 0) {
    showAppAlert("紅色（缺貨）門檻請輸入 0 以上的整數！");
    return;
  }
  if (!Number.isInteger(yellow) || yellow < red) {
    showAppAlert("黃色（偏低）門檻請輸入整數，且不能比紅色門檻小！");
    return;
  }
  if (!Number.isInteger(notify) || notify < 0) {
    showAppAlert("通知門檻請輸入 0 以上的整數！");
    return;
  }

  try {
    await update(ref(db, "appSettings"), {
      stockRedThreshold: red,
      stockYellowThreshold: yellow,
      stockNotifyThreshold: notify,
    });
    appStockRedThreshold = red;
    appStockYellowThreshold = yellow;
    appStockNotifyThreshold = notify;
    if (statusEl) statusEl.textContent = "已儲存！";
    refreshStockThresholdDependentUI(); // 立刻更新通知信箱的紅點跟清單
  } catch (err) {
    console.error("儲存進貨系統設定失敗：", err);
    showAppAlert(`儲存失敗：${err.code || err.message || "未知錯誤"}`);
  }
};

// 把整個 Firebase 資料庫抓下來、量實際的資料大小，當作「伺服器用量」的估算值。
// 用官方沒有提供的「精確剩餘配額」API，因為 Realtime Database 的用戶端 SDK
// 本來就沒有這種查詢功能（那個數字只有 Firebase / Google Cloud 後台才查得到），
// 這裡是退而求其次、抓資料量測大小的作法。
// 把 bytes 數字轉成好讀的 KB／MB 字串，硬碟快取大小、伺服器用量估算共用這個函式。
function formatBytesForDisplay(bytes) {
  if (typeof bytes !== "number" || isNaN(bytes)) return "未知大小";
  if (bytes < 1024) return `${bytes} bytes`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

// 資料庫最上層的節點清單，「估算遠端用量」跟「清除遠端所有資料」共用同一份，
// 避免以後兩邊各自維護一份清單，改了一邊卻忘記改另一邊。
const FIREBASE_TOP_LEVEL_PATHS = [
  "records",
  "itemCatalog",
  "appSettings",
  "pendingMileage",
  "stockLogs",
];

let isCheckingServerStorage = false; // 避免同一時間重複觸發，兩份「整包資料庫」同時疊在記憶體裡

window.settingsCheckServerStorage = async function () {
  const rowEl = document.getElementById("settings_server_storage_row");
  if (isCheckingServerStorage) return; // 已經在跑了，不要再排一次
  if (!rowEl) return;
  isCheckingServerStorage = true;
  rowEl.innerHTML = settingsInfoRowHtml("遠端空間", "抓取中…");

  const FIREBASE_FREE_TIER_LIMIT_BYTES = 1024 * 1024 * 1024; // Firebase 免費（Spark）方案上限 1GB

  try {
    if (!auth.currentUser) throw new Error("尚未登入");

    // 直接照已知的頂層節點分別讀出來加總，估算總大小。
    // （原本會先整包讀一次根節點「/」失敗了才切換成這個方式，等於資料量
    // 大的時候有機會把整個資料庫同時疊兩份在記憶體裡，這裡直接省略那次
    // 整包嘗試，一律用逐節點加總，尖峰記憶體用量只會有一份。）
    let totalBytes = 0;
    let lastErr = null;
    let anySucceeded = false;
    for (const p of FIREBASE_TOP_LEVEL_PATHS) {
      try {
        const snap = await get(ref(db, p));
        totalBytes += await computeJsonByteSizeOffMainThread(snap.val());
        anySucceeded = true;
      } catch (childErr) {
        console.error(`讀取節點「${p}」失敗，這部分大小不列入估算：`, childErr);
        lastErr = childErr;
      }
    }
    if (!anySucceeded) throw lastErr || new Error("所有節點都讀取失敗");

    rowEl.innerHTML = settingsInfoRowHtml(
      "遠端空間",
      `${formatBytesForDisplay(totalBytes)} / ${formatBytesForDisplay(
        FIREBASE_FREE_TIER_LIMIT_BYTES
      )}`
    );
  } catch (err) {
    // 直接把失敗原因顯示出來，方便判斷是規則權限問題、還是網路問題
    console.error("檢查伺服器用量失敗：", err);
    const reason = err.code || err.message || "未知錯誤";
    rowEl.innerHTML = settingsInfoRowHtml(
      "遠端空間",
      `<button onclick="window.settingsCheckServerStorage()"
        class="text-sm font-bold px-3 py-1 rounded-full" style="background-color:#fee2e2; color:#b91c1c"
        title="${escapeAttr(reason)}">失敗（${escapeAttr(reason)}），點一下再試</button>`
    );
  } finally {
    isCheckingServerStorage = false;
  }
};

// ⚠️⚠️⚠️ 清除伺服器（Firebase）上「全部」的資料——車籍、維修紀錄、品項分類、
// 系統設定通通刪掉。這是「全公司共用」的資料庫，一刪全公司每一台電腦都會
// 立刻受影響，而且沒有任何備份可以救回來，是整個系統裡最危險的按鈕。
// 因此設計成要連續跳出三次警告，使用者每一次都要按「確定」才會繼續往下，
// 中途只要按一次「取消」就整個中止，不會刪除任何東西。
window.settingsClearAllRemoteData = async function () {
  // 三次警告已經內建在「清除資料」視窗裡了，這裡不用再跳一次舊式的
  // confirm 對話框，直接開啟視窗即可。
  window.openDangerDeleteModal("settings_server");
};

// 直接在檔案總管（Windows）／Finder（macOS）打開本機資料夾，不用自己找路徑貼進網址列
window.settingsOpenLocalDataFolder = async function () {
  const statusEl = document.getElementById("settings_storage_status");
  try {
    const dir = await window.electronAPI.openLocalDataFolder();
    const pathEl = document.getElementById("settings_local_data_path");
    if (pathEl && dir) pathEl.textContent = dir;
    if (statusEl) statusEl.textContent = "已開啟本機資料夾！";
  } catch (err) {
    console.error("開啟本機資料夾失敗：", err);
    if (statusEl) statusEl.textContent = `開啟失敗：${err.message || "未知錯誤"}`;
  }
};

// 手動立即觸發一次「完整資料同步到硬碟」，不用等下次登入或恢復網路連線。
window.settingsSyncNow = async function () {
  const statusEl = document.getElementById("settings_storage_status");
  if (!isOnline) {
    if (statusEl) statusEl.textContent = "目前離線中，需要連上網路才能同步！";
    return;
  }
  if (statusEl) statusEl.textContent = "同步中...";
  const ok = await syncFullRecordsToLocalDisk();
  if (statusEl) {
    statusEl.textContent = ok ? "已同步完整資料到硬碟！" : "同步失敗，請稍後再試";
  }
  if (settingsCurrentPage === "storage_local") renderHiddenSettingsBody();
};

// 「本機空間」子頁一打開，畫面就自動觸發一次完整同步（見下面渲染該子頁的地方）。
// 這裡一定要包一層防重入旗標：因為 settingsSyncNow() 同步完成後會呼叫
// renderHiddenSettingsBody() 重繪整頁，而重繪會再次執行到這個子頁的程式碼、
// 又會再呼叫一次「自動觸發同步」——如果沒有這層旗標擋著，會變成「重繪→
// 觸發同步→同步完再重繪→又觸發同步…」不斷互相呼叫的無限迴圈，把畫面卡死。
// 有了旗標之後，同步還在進行中時，重繪觸發的呼又只會直接被擋下來，不會
// 產生新的一輪同步或重繪。
function triggerLocalPageAutoSync() {
  if (localPageAutoSyncTask) return localPageAutoSyncTask; // 已經在跑了，重繪觸發的呼叫直接擋掉
  localPageAutoSyncTask = settingsSyncNow().finally(() => {
    localPageAutoSyncTask = null;
  });
  return localPageAutoSyncTask;
}

// 清掉這台電腦本機快取（記憶體＋硬碟檔案），下次查詢會重新跟伺服器要一次最新資料。
// 不會動到 Firebase 上的真實資料，也不會動到還沒補傳的離線維修紀錄。
window.settingsClearLocalCache = async function () {
  const beforeCount = recordCache.size;
  recordCache.clear();
  lastFullSyncAt = null;
  const statusEl = document.getElementById("settings_storage_status");
  try {
    await window.electronAPI.clearLocalCache();
    if (statusEl) statusEl.textContent = `已清除 ${beforeCount} 筆本機快取（含硬碟檔案）！`;
  } catch (err) {
    console.error("清除硬碟快取檔案失敗：", err);
    if (statusEl) statusEl.textContent = `已清除記憶體快取，但硬碟檔案清除失敗：${err.message || "未知錯誤"}`;
  }
  if (settingsCurrentPage === "storage_local") renderHiddenSettingsBody();
};

// ⚠️⚠️⚠️ 清除「這台電腦」本機的所有資料——硬碟快取＋還沒補傳的離線維修紀錄，
// 兩邊都會整個刪掉。跟上面「清除本機快取」不一樣：那個不會動到還沒補傳的
// 離線紀錄；這個是本機能清的東西全清，所以一樣要求連續跳出三次警告，
// 使用者每一次都要按「確定」才會繼續往下，中途按「取消」就整個中止。
window.settingsClearAllLocalData = async function () {
  // 三次警告已經內建在「清除資料」視窗裡了，這裡不用再跳一次舊式的
  // confirm 對話框，直接開啟視窗即可。
  window.openDangerDeleteModal("settings_local");
};

// 車牌/卡號正規化：跟系統其他地方（搜尋、儲存）用同一套規則——
// 去掉橫線、去掉空白、轉大寫，這樣不管舊系統存的格式是 "ABC-1234"
// 還是 "abc 1234"，匯入後都會對應到同一筆資料。
function normalizeImportKey(v) {
  return String(v == null ? "" : v)
    .replace(/[-\s]/g, "")
    .toUpperCase();
}

function todayDatetimeLocalDefault() {
  return `${todayStr()}T00:00`;
}

// 把 Access 欄位的值（可能是 ISO 日期字串、純日期字串、或什麼都不是）
// 轉成系統維修紀錄用的 "YYYY-MM-DDTHH:mm" 格式；轉不出來就用今天代替，
// 不會讓整筆資料匯入失敗。
function toDatetimeLocalValue(v) {
  if (v === null || v === undefined || v === "") return todayDatetimeLocalDefault();
  if (typeof v === "string" && /^\d{4}-\d{2}-\d{2}/.test(v)) {
    const datePart = v.slice(0, 10);
    const timeMatch = v.match(/T?(\d{2}:\d{2})/);
    return `${datePart}T${timeMatch ? timeMatch[1] : "00:00"}`;
  }
  const d = new Date(v);
  if (isNaN(d.getTime())) return todayDatetimeLocalDefault();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`;
}

function accessImportFieldSelect(id, columns, selected, required) {
  const opts = [
    `<option value="">${required ? "—請選擇—" : "—不對應—"}</option>`,
  ].concat(
    columns.map(
      (c) =>
        `<option value="${escapeAttrForBadge(c)}" ${
          c === selected ? "selected" : ""
        }>${escapeAttrForBadge(c)}</option>`
    )
  );
  return `<select id="${id}" onchange="window.accessImportSyncAndRerender()" class="border border-gray-300 rounded px-2 py-1.5 w-full text-sm">${opts.join(
    ""
  )}</select>`;
}

window.accessImportSyncAndRerender = function () {
  accessImportSyncMappingFromDom();
  renderAccessImportBody();
};

window.accessImportMasterTableChanged = function () {
  accessImportSyncMappingFromDom();
  const val = document.getElementById("access_import_master_table").value;
  accessImportConfig.masterTable = val;
  accessImportConfig.masterMapping = {
    plate: "",
    name: "",
    phone: "",
    memberId: "",
    address: "",
    notes: "",
  };
  renderAccessImportBody();
};

window.accessImportRepairTableChanged = function () {
  accessImportSyncMappingFromDom();
  const val = document.getElementById("access_import_repair_table").value;
  accessImportConfig.repairTable = val;
  accessImportConfig.repairMapping = {
    linkField: "",
    key: "",
    datetime: "",
    items: "",
    mileage: "",
    mechanic: "",
    cost: "",
    notes: "",
  };
  // 換了維修紀錄表，原本選的品項明細表關聯欄位多半也對不上了，一併清空避免誤用
  accessImportConfig.useItemsTable = false;
  accessImportConfig.itemsTable = "";
  accessImportConfig.itemsMapping = {
    linkField: "",
    name: "",
    qty: "",
    price: "",
    category: "",
  };
  renderAccessImportBody();
};

window.accessImportItemsTableChanged = function () {
  accessImportSyncMappingFromDom();
  const val = document.getElementById("access_import_items_table").value;
  accessImportConfig.itemsTable = val;
  accessImportConfig.itemsMapping = {
    linkField: "",
    name: "",
    qty: "",
    price: "",
    category: "",
  };
  renderAccessImportBody();
};

window.accessImportToggleItemsSection = function () {
  accessImportSyncMappingFromDom();
  accessImportConfig.useItemsTable = document.getElementById(
    "access_import_use_items"
  ).checked;
  if (accessImportConfig.useItemsTable && !accessImportConfig.itemsTable) {
    // 預設帶一張跟主檔、維修紀錄表都不同的表，方便使用者省一次點擊
    const names = Object.keys(accessImportTables);
    accessImportConfig.itemsTable =
      names.find(
        (n) =>
          n !== accessImportConfig.masterTable &&
          n !== accessImportConfig.repairTable
      ) || names[0];
  }
  renderAccessImportBody();
};

window.accessImportToggleRepairSection = function () {
  accessImportSyncMappingFromDom();
  accessImportConfig.useRepairTable = document.getElementById(
    "access_import_use_repair"
  ).checked;
  if (accessImportConfig.useRepairTable && !accessImportConfig.repairTable) {
    // 預設帶一張表，方便使用者省一次點擊；如果只有一張表，就直接用同一張
    const names = Object.keys(accessImportTables);
    accessImportConfig.repairTable =
      names.find((n) => n !== accessImportConfig.masterTable) || names[0];
  }
  renderAccessImportBody();
};

// 把畫面上目前選好的下拉選單值，同步存回 accessImportConfig，
// 避免重新 render 的時候把使用者剛選好的東西弄丟。
function accessImportSyncMappingFromDom() {
  const val = (id) => document.getElementById(id)?.value ?? "";
  if (!document.getElementById("access_import_master_table")) return;

  const keepExtraEl = document.getElementById("access_import_keep_extra");
  accessImportConfig.masterMapping = {
    plate: val("access_import_map_plate"),
    name: val("access_import_map_name"),
    phone: val("access_import_map_phone"),
    memberId: val("access_import_map_memberId"),
    address: val("access_import_map_address"),
    notes: val("access_import_map_notes"),
    keepExtraColumns: keepExtraEl
      ? keepExtraEl.checked
      : accessImportConfig.masterMapping.keepExtraColumns,
  };

  if (accessImportConfig.useRepairTable) {
    accessImportConfig.repairMapping = {
      linkField: val("access_import_map_repairlink"),
      key: val("access_import_map_repairkey"),
      datetime: val("access_import_map_datetime"),
      items: val("access_import_map_items"),
      mileage: val("access_import_map_mileage"),
      mechanic: val("access_import_map_mechanic"),
      cost: val("access_import_map_cost"),
      notes: val("access_import_map_repairnotes"),
    };
  }

  if (accessImportConfig.useRepairTable && accessImportConfig.useItemsTable) {
    accessImportConfig.itemsMapping = {
      linkField: val("access_import_map_itemslink"),
      name: val("access_import_map_itemname"),
      qty: val("access_import_map_itemqty"),
      price: val("access_import_map_itemprice"),
      category: val("access_import_map_itemcategory"),
    };
  }

  if (accessImportConfig.catalogImport.enabled) {
    accessImportConfig.catalogImport.mapping = {
      name: val("access_import_map_catalogname"),
      price: val("access_import_map_catalogprice"),
      categoryCode: val("access_import_map_catalogcategory"),
    };
    const skipEl = document.getElementById("access_import_catalog_skip_dup");
    if (skipEl) accessImportConfig.catalogImport.skipDuplicates = skipEl.checked;
  }
}

window.accessImportToggleCatalogSection = function () {
  accessImportSyncMappingFromDom();
  accessImportConfig.catalogImport.enabled = document.getElementById(
    "access_import_use_catalog"
  ).checked;
  if (
    accessImportConfig.catalogImport.enabled &&
    !accessImportConfig.catalogImport.table
  ) {
    const names = Object.keys(accessImportTables);
    accessImportConfig.catalogImport.table =
      names.find(
        (n) =>
          n !== accessImportConfig.masterTable &&
          n !== accessImportConfig.repairTable &&
          n !== accessImportConfig.itemsTable
      ) || names[0];
  }
  catalogImportStatus = "idle";
  catalogImportResult = null;
  renderAccessImportBody();
};

window.accessImportCatalogTableChanged = function () {
  accessImportSyncMappingFromDom();
  const val = document.getElementById("access_import_catalog_table").value;
  accessImportConfig.catalogImport.table = val;
  accessImportConfig.catalogImport.mapping = {
    name: "",
    price: "",
    categoryCode: "",
  };
  catalogImportStatus = "idle";
  catalogImportResult = null;
  renderAccessImportBody();
};

// 把舊系統的「維修項目檔」之類的品項清單，匯進 Firebase 共用的 itemCatalog，
// 之後在「維修資料」表單點分類選單就找得到。跟上面客戶/維修紀錄的匯入完全
// 獨立，不需要先選車牌欄位、也不用跑預覽流程，選好欄位按一下就直接寫入。
window.accessImportRunCatalogImport = async function () {
  accessImportSyncMappingFromDom();
  const cfg = accessImportConfig.catalogImport;

  if (!cfg.table || !accessImportTables[cfg.table]) {
    showAppAlert("請先選要匯入的品項清單表。");
    return;
  }
  if (!cfg.mapping.name) {
    showAppAlert("請至少選好「品項名稱」對應到哪個欄位，這是必填的。");
    return;
  }

  catalogImportStatus = "importing";
  catalogImportResult = null;
  renderAccessImportBody();

  const statusEl = document.getElementById("access_import_catalog_progress_status");

  try {
    // 先把每個分類目前已經有的品項名稱抓下來，勾了「跳過重複」才拿來比對，
    // 避免同一份清單重複匯入好幾次，分類選單裡塞出一堆同名品項。
    const existingNamesByCategory = {};
    if (cfg.skipDuplicates) {
      for (const cat of ITEM_CATEGORIES) {
        try {
          const snap = await get(ref(db, "itemCatalog/" + cat));
          const set2 = new Set();
          if (snap.exists()) {
            Object.values(snap.val()).forEach((it) => {
              if (it && it.name) set2.add(String(it.name).trim());
            });
          }
          existingNamesByCategory[cat] = set2;
        } catch (err) {
          existingNamesByCategory[cat] = new Set();
        }
      }
    }

    const rows = accessImportTables[cfg.table].rows;
    let written = 0;
    let skippedDuplicate = 0;
    let skippedNoName = 0;
    let failed = 0;
    let done = 0;

    for (const row of rows) {
      done += 1;
      if (statusEl) statusEl.textContent = `處理中… ${done} / ${rows.length}`;

      const name = String(row[cfg.mapping.name] ?? "").trim();
      if (!name) {
        skippedNoName += 1;
        continue;
      }

      const priceNum = cfg.mapping.price ? Number(row[cfg.mapping.price]) : 0;
      const price = Number.isFinite(priceNum) ? priceNum : 0;

      let category = DEFAULT_MANUAL_ITEM_CATEGORY;
      if (cfg.mapping.categoryCode) {
        const codeNum = Number(row[cfg.mapping.categoryCode]);
        if (Number.isInteger(codeNum) && ITEM_CATEGORIES[codeNum]) {
          category = ITEM_CATEGORIES[codeNum];
        }
      }

      if (cfg.skipDuplicates && existingNamesByCategory[category]?.has(name)) {
        skippedDuplicate += 1;
        continue;
      }

      try {
        const newRef = push(ref(db, "itemCatalog/" + category));
        await set(newRef, { name, price });
        existingNamesByCategory[category]?.add(name);
        written += 1;
      } catch (err) {
        console.error("匯入品項失敗：", name, err);
        failed += 1;
      }
    }

    catalogImportResult = { total: rows.length, written, skippedDuplicate, skippedNoName, failed };
    catalogImportStatus = "done";
    renderAccessImportBody();
  } catch (err) {
    console.error("匯入品項分類清單失敗：", err);
    catalogImportStatus = "idle";
    renderAccessImportBody();
    showAppAlert(`匯入失敗：${err.message || "未知錯誤"}`);
  }
};

window.pickAccessImportFile = async function () {
  const statusEl = document.getElementById("access_import_pick_status");
  try {
    if (!window.electronAPI || !window.electronAPI.pickAccessFile) {
      showAppAlert("這個功能需要在桌面版 App 裡使用。");
      return;
    }
    const filePath = await window.electronAPI.pickAccessFile();
    if (!filePath) return;

    if (statusEl) statusEl.textContent = "讀取中，請稍候…";

    const result = await window.electronAPI.readAccessFile(filePath);
    if (!result || !result.ok) {
      if (statusEl) statusEl.textContent = "";
      showAppAlert(`讀取失敗：${(result && result.error) || "未知錯誤"}`);
      return;
    }

    // 只留有資料的表，選單比較乾淨，也避免使用者選到空表
    const tables = {};
    Object.entries(result.tables).forEach(([name, t]) => {
      if (t.rows.length > 0) tables[name] = t;
    });

    if (Object.keys(tables).length === 0) {
      if (statusEl) statusEl.textContent = "";
      showAppAlert("這個檔案裡沒有找到任何有資料的表格。");
      return;
    }

    resetAccessImportState();
    accessImportTables = tables;
    accessImportConfig.masterTable = Object.keys(tables)[0];
    accessImportStep = "mapping";
    renderAccessImportBody();
  } catch (err) {
    console.error("讀取 Access 檔案失敗：", err);
    if (statusEl) statusEl.textContent = "";
    showAppAlert(`讀取失敗：${err.message || "未知錯誤"}`);
  }
};

// 依照目前的欄位對應設定，把 Access 原始資料整理成「車牌/卡號 → 客戶資料
// + 維修紀錄陣列」的結構，之後預覽跟真正寫入 Firebase 都用這份資料。
// 車籍主檔欄位對應表單只開放 6 個目標欄位（車牌/姓名/電話/會員編號/地址/備註），
// 舊系統裡其餘沒地方對應的欄位（引擎號碼、顏色、生日…）如果直接不管，
// 會在使用者完全沒發現的情況下被默默丟掉。keepExtraColumns 開啟時，
// 把這些「多出來」的欄位整理成「欄名：值」的文字，接在備註最後面，
// 用最小改動（不用改資料庫結構）換到「幾乎不遺失」。
function buildExtraColumnsNoteText(row, masterCols, mapping) {
  const usedCols = new Set(
    [mapping.plate, mapping.name, mapping.phone, mapping.memberId, mapping.address, mapping.notes].filter(
      Boolean
    )
  );
  const lines = [];
  masterCols.forEach((col) => {
    if (usedCols.has(col)) return;
    const raw = row[col];
    const text = String(raw ?? "").trim();
    if (!text) return;
    lines.push(`${col}：${text}`);
  });
  return lines.join("\n");
}

function buildAccessImportPlan() {
  const cfg = accessImportConfig;
  const masterTable = accessImportTables[cfg.masterTable];
  const customers = new Map();
  let skippedMasterCount = 0;

  masterTable.rows.forEach((row) => {
    const key = normalizeImportKey(row[cfg.masterMapping.plate]);
    if (!key) {
      skippedMasterCount += 1;
      return;
    }
    const baseNotes = cfg.masterMapping.notes
      ? String(row[cfg.masterMapping.notes] ?? "").trim()
      : "";
    const extraNotes = cfg.masterMapping.keepExtraColumns
      ? buildExtraColumnsNoteText(row, masterTable.columns, cfg.masterMapping)
      : "";
    const combinedNotes = [baseNotes, extraNotes].filter(Boolean).join("\n");

    customers.set(key, {
      key,
      plateRaw: row[cfg.masterMapping.plate],
      customer: {
        name: cfg.masterMapping.name
          ? String(row[cfg.masterMapping.name] ?? "").trim()
          : "",
        phone: cfg.masterMapping.phone
          ? String(row[cfg.masterMapping.phone] ?? "").trim()
          : "",
        memberId: cfg.masterMapping.memberId
          ? String(row[cfg.masterMapping.memberId] ?? "").trim()
          : "",
        address: cfg.masterMapping.address
          ? String(row[cfg.masterMapping.address] ?? "").trim()
          : "",
        notes: combinedNotes,
      },
      repairs: [],
    });
  });

  // 品項明細表：先依「維修紀錄表主鍵欄位」把明細列分組，等一下組每筆維修紀錄
  // 時才知道要抓哪些品項進來。用 trim 之後原樣比對（不像車牌會去橫線轉大寫），
  // 因為主鍵通常是流水號，保留原樣比對比較準。
  let skippedItemsCount = 0;
  const itemsByRepairKey = new Map();
  if (
    cfg.useRepairTable &&
    cfg.useItemsTable &&
    cfg.itemsTable &&
    cfg.repairMapping.key &&
    cfg.itemsMapping.linkField &&
    accessImportTables[cfg.itemsTable]
  ) {
    const itemsTable = accessImportTables[cfg.itemsTable];
    itemsTable.rows.forEach((row) => {
      const linkKey = String(row[cfg.itemsMapping.linkField] ?? "").trim();
      if (!linkKey) {
        skippedItemsCount += 1;
        return;
      }
      const name = cfg.itemsMapping.name
        ? String(row[cfg.itemsMapping.name] ?? "").trim()
        : "";
      if (!name) {
        skippedItemsCount += 1;
        return;
      }
      const qtyNum = cfg.itemsMapping.qty
        ? Number(row[cfg.itemsMapping.qty])
        : 1;
      const qty = Number.isFinite(qtyNum) && qtyNum !== 0 ? qtyNum : 1;
      const subtotalNum = cfg.itemsMapping.price
        ? Number(row[cfg.itemsMapping.price]) || 0
        : 0;
      // 舊系統「金額」欄位存的通常是這一列的小計，不是單價，所以單價用小計／數量反推
      const price = qty ? subtotalNum / qty : subtotalNum;
      let category = DEFAULT_MANUAL_ITEM_CATEGORY;
      if (cfg.itemsMapping.category) {
        const codeNum = Number(row[cfg.itemsMapping.category]);
        if (Number.isInteger(codeNum) && ITEM_CATEGORIES[codeNum]) {
          category = ITEM_CATEGORIES[codeNum];
        }
      }

      if (!itemsByRepairKey.has(linkKey)) itemsByRepairKey.set(linkKey, []);
      itemsByRepairKey.get(linkKey).push({
        name,
        qty,
        price,
        subtotal: subtotalNum,
        category,
        maintenanceType: DEFAULT_MAINTENANCE_TYPE,
      });
    });
  }

  // 維修紀錄的車牌／卡號如果在車籍主檔裡完全找不到（舊系統本身資料不完整、
  // 車籍主檔漏登），以前的做法是整筆維修紀錄直接略過不匯入，畫面上只會顯示
  // 「有 N 筆對不到客戶」的籠統提示，使用者不知道漏了哪一筆。
  // 現在改成：自動補一筆空白車籍資料（備註會註明是自動建立），維修紀錄照樣
  // 匯進去，事後可以直接在系統裡搜尋這個車牌，把姓名/電話補齊即可，
  // 資料本身不會不見。skippedRepairsCount 只留給「連車牌欄位本身都是空的」
  // 這種真的沒辦法關聯的情況。
  let skippedRepairsCount = 0;
  let autoCreatedFromOrphanRepairs = 0;
  const orphanRepairSamples = [];
  if (cfg.useRepairTable && cfg.repairTable && accessImportTables[cfg.repairTable]) {
    const repairTable = accessImportTables[cfg.repairTable];
    repairTable.rows.forEach((row) => {
      const rawLink = row[cfg.repairMapping.linkField];
      const key = normalizeImportKey(rawLink);
      if (!key) {
        skippedRepairsCount += 1;
        return;
      }
      let target = customers.get(key);
      if (!target) {
        target = {
          key,
          plateRaw: rawLink,
          customer: {
            name: "",
            phone: "",
            memberId: "",
            address: "",
            notes:
              "此車籍資料為匯入時自動建立（原始舊資料庫的車籍主檔查無這個車牌／卡號，只有維修紀錄），姓名／電話等資料請自行補上。",
          },
          repairs: [],
        };
        customers.set(key, target);
        autoCreatedFromOrphanRepairs += 1;
        if (orphanRepairSamples.length < 20) {
          orphanRepairSamples.push({
            plate: rawLink,
            datetime: cfg.repairMapping.datetime ? row[cfg.repairMapping.datetime] : null,
          });
        }
      }
      const costNum = cfg.repairMapping.cost
        ? Number(row[cfg.repairMapping.cost]) || 0
        : 0;
      const mileageRaw = cfg.repairMapping.mileage
        ? row[cfg.repairMapping.mileage]
        : null;
      const mileageNum =
        mileageRaw === null || mileageRaw === "" || mileageRaw === undefined
          ? NaN
          : Number(mileageRaw);
      const mileageMissing = isNaN(mileageNum);

      // 先看這筆維修紀錄的主鍵能不能在品項明細表裡找到對應的品項；
      // 找得到就用真正的品項清單（含分類、單價），找不到才退回用
      // 「維修項目說明」那個文字欄位湊一筆假的品項，避免整筆維修紀錄空白。
      const repairKeyVal = cfg.repairMapping.key
        ? String(row[cfg.repairMapping.key] ?? "").trim()
        : "";
      const matchedItems = repairKeyVal
        ? itemsByRepairKey.get(repairKeyVal)
        : null;

      let itemsText;
      let itemsDetail;
      let finalCost;
      if (matchedItems && matchedItems.length > 0) {
        itemsDetail = matchedItems;
        itemsText = matchedItems.map((it) => `${it.name} x${it.qty}`).join("、");
        finalCost = matchedItems.reduce((sum, it) => sum + it.subtotal, 0);
      } else {
        const fallbackText = cfg.repairMapping.items
          ? String(row[cfg.repairMapping.items] ?? "").trim()
          : "";
        itemsText = fallbackText;
        itemsDetail = fallbackText
          ? [
              {
                name: fallbackText,
                qty: 1,
                price: costNum,
                subtotal: costNum,
                category: DEFAULT_MANUAL_ITEM_CATEGORY,
                maintenanceType: DEFAULT_MAINTENANCE_TYPE,
              },
            ]
          : [];
        finalCost = costNum;
      }

      target.repairs.push({
        datetime: toDatetimeLocalValue(
          cfg.repairMapping.datetime ? row[cfg.repairMapping.datetime] : null
        ),
        items: itemsText,
        itemsDetail,
        mileage: mileageMissing ? null : mileageNum,
        mileageMissing,
        mechanic: cfg.repairMapping.mechanic
          ? String(row[cfg.repairMapping.mechanic] ?? "").trim()
          : "",
        cost: finalCost,
        notes: cfg.repairMapping.notes
          ? String(row[cfg.repairMapping.notes] ?? "").trim()
          : "",
      });
    });
  }

  return {
    customers: Array.from(customers.values()),
    skippedMasterCount,
    skippedRepairsCount,
    skippedItemsCount,
    autoCreatedFromOrphanRepairs,
    orphanRepairSamples,
  };
}

window.accessImportGoToPreview = function () {
  accessImportSyncMappingFromDom();

  if (!accessImportConfig.masterMapping.plate) {
    showAppAlert("請至少選好「車牌／卡號」對應到哪個欄位，這是必填的。");
    return;
  }
  if (
    accessImportConfig.useRepairTable &&
    (!accessImportConfig.repairTable || !accessImportConfig.repairMapping.linkField)
  ) {
    showAppAlert("有勾選維修紀錄表的話，要選表、也要選關聯欄位（對應到車牌/卡號）。");
    return;
  }

  accessImportPlan = buildAccessImportPlan();
  accessImportStep = "preview";
  renderAccessImportBody();
};

window.accessImportBackToMapping = function () {
  accessImportStep = "mapping";
  renderAccessImportBody();
};

window.accessImportToggleOverwrite = function () {
  accessImportConfig.overwriteExisting = document.getElementById(
    "access_import_overwrite"
  ).checked;
};

// 真正寫進 Firebase：一筆一筆處理，每筆都先寫（或略過）客戶資料，
// 再把這筆底下的維修紀錄逐筆 push 進去。用逐筆處理而不是一次性大量
// 寫入，是為了能顯示進度、也讓中途失敗只影響那一筆，不會整批卡住。
window.accessImportRunImport = async function () {
  if (!accessImportPlan) return;
  accessImportStep = "importing";
  renderAccessImportBody();

  const total = accessImportPlan.customers.length;
  let done = 0;
  let customersWritten = 0;
  let customersSkipped = 0;
  let repairsWritten = 0;
  let failed = 0;

  const statusEl = document.getElementById("access_import_progress_status");
  const barEl = document.getElementById("access_import_progress_bar");

  for (const item of accessImportPlan.customers) {
    try {
      const custRef = ref(db, "records/" + item.key + "/customer");
      let writeCustomer = true;

      if (!accessImportConfig.overwriteExisting) {
        const existingSnap = await get(custRef);
        if (existingSnap.exists()) {
          writeCustomer = false;
          customersSkipped += 1;
        }
      }

      if (writeCustomer) {
        await set(custRef, item.customer);
        customersWritten += 1;
      }

      for (const repair of item.repairs) {
        const newRef = push(ref(db, "records/" + item.key + "/repairs"));
        await set(newRef, repair);
        repairsWritten += 1;
      }
    } catch (err) {
      console.error("匯入這筆失敗：", item.key, err);
      failed += 1;
    }

    done += 1;
    if (statusEl) statusEl.textContent = `處理中… ${done} / ${total}`;
    if (barEl) barEl.style.width = `${Math.round((done / total) * 100)}%`;
  }

  accessImportResult = {
    total,
    customersWritten,
    customersSkipped,
    repairsWritten,
    failed,
    skippedMasterCount: accessImportPlan.skippedMasterCount,
    skippedRepairsCount: accessImportPlan.skippedRepairsCount,
    autoCreatedFromOrphanRepairs: accessImportPlan.autoCreatedFromOrphanRepairs,
  };
  accessImportStep = "done";
  renderAccessImportBody();
};

window.accessImportFinish = function () {
  window.closeAccessImportModal();
  // 匯入完成後畫面上的最近紀錄／待補里程都跟新資料無關，不用特別重整；
  // 使用者直接用搜尋框查剛匯入的車牌就看得到。
};

function renderAccessImportBody() {
  const body = document.getElementById("access_import_body");
  if (!body) return;

  if (accessImportStep === "pick") {
    body.innerHTML = `
      <div class="text-center py-12">
        <button onclick="window.pickAccessImportFile()"
          class="bg-indigo-700 text-white px-6 py-3 rounded-lg font-bold hover:bg-indigo-600 shadow transition">
          選擇 Access 檔案（.accdb / .mdb）
        </button>
        <p class="text-gray-400 text-sm mt-3">
          直接選舊系統資料夾裡的資料庫檔案本身，不用先匯出成 Excel
        </p>
        <div id="access_import_pick_status" class="text-sm text-gray-500 mt-4"></div>
      </div>
    `;
    return;
  }

  if (accessImportStep === "mapping") {
    const tableNames = Object.keys(accessImportTables);
    const cfg = accessImportConfig;
    const masterCols = accessImportTables[cfg.masterTable].columns;
    const masterRowCount = accessImportTables[cfg.masterTable].rows.length;

    const masterTableOptions = tableNames
      .map(
        (n) =>
          `<option value="${escapeAttrForBadge(n)}" ${
            n === cfg.masterTable ? "selected" : ""
          }>${escapeAttrForBadge(n)}（${accessImportTables[n].rows.length} 筆）</option>`
      )
      .join("");

    let repairSectionHtml = "";
    if (cfg.useRepairTable) {
      const repairTableName = cfg.repairTable || tableNames[0];
      const repairCols = accessImportTables[repairTableName]
        ? accessImportTables[repairTableName].columns
        : [];
      const repairTableOptions = tableNames
        .map(
          (n) =>
            `<option value="${escapeAttrForBadge(n)}" ${
              n === repairTableName ? "selected" : ""
            }>${escapeAttrForBadge(n)}（${accessImportTables[n].rows.length} 筆，可以跟主檔選同一張）</option>`
        )
        .join("");

      let itemsSectionHtml = "";
      if (cfg.useItemsTable) {
        const itemsTableName = cfg.itemsTable || tableNames[0];
        const itemsCols = accessImportTables[itemsTableName]
          ? accessImportTables[itemsTableName].columns
          : [];
        const itemsTableOptions = tableNames
          .map(
            (n) =>
              `<option value="${escapeAttrForBadge(n)}" ${
                n === itemsTableName ? "selected" : ""
              }>${escapeAttrForBadge(n)}（${accessImportTables[n].rows.length} 筆）</option>`
          )
          .join("");

        itemsSectionHtml = `
          <div class="mt-3 pl-4 border-l-4 border-teal-200 space-y-2">
            <div>
              <label class="text-sm font-bold text-gray-600 block mb-1">品項明細表</label>
              <select id="access_import_items_table" onchange="window.accessImportItemsTableChanged()"
                class="border border-gray-300 rounded px-2 py-1.5 w-full text-sm">
                ${itemsTableOptions}
              </select>
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="text-xs text-gray-500 block mb-1">關聯欄位（對應到上面「本表主鍵欄位」，必填）</label>
                ${accessImportFieldSelect(
                  "access_import_map_itemslink",
                  itemsCols,
                  cfg.itemsMapping.linkField,
                  true
                )}
              </div>
              <div>
                <label class="text-xs text-gray-500 block mb-1">品項名稱（必填）</label>
                ${accessImportFieldSelect(
                  "access_import_map_itemname",
                  itemsCols,
                  cfg.itemsMapping.name,
                  true
                )}
              </div>
              <div>
                <label class="text-xs text-gray-500 block mb-1">數量</label>
                ${accessImportFieldSelect(
                  "access_import_map_itemqty",
                  itemsCols,
                  cfg.itemsMapping.qty,
                  false
                )}
              </div>
              <div>
                <label class="text-xs text-gray-500 block mb-1">金額（這一列的小計，不是單價）</label>
                ${accessImportFieldSelect(
                  "access_import_map_itemprice",
                  itemsCols,
                  cfg.itemsMapping.price,
                  false
                )}
              </div>
              <div class="col-span-2">
                <label class="text-xs text-gray-500 block mb-1">類別代號（選填，對不到系統分類就歸類「其他」）</label>
                ${accessImportFieldSelect(
                  "access_import_map_itemcategory",
                  itemsCols,
                  cfg.itemsMapping.category,
                  false
                )}
              </div>
            </div>
          </div>
        `;
      }

      repairSectionHtml = `
        <div class="mt-3 pl-4 border-l-4 border-indigo-200 space-y-2">
          <div>
            <label class="text-sm font-bold text-gray-600 block mb-1">維修紀錄表</label>
            <select id="access_import_repair_table" onchange="window.accessImportRepairTableChanged()"
              class="border border-gray-300 rounded px-2 py-1.5 w-full text-sm">
              ${repairTableOptions}
            </select>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-xs text-gray-500 block mb-1">關聯欄位（對應到車牌／卡號，必填）</label>
              ${accessImportFieldSelect(
                "access_import_map_repairlink",
                repairCols,
                cfg.repairMapping.linkField,
                true
              )}
            </div>
            <div>
              <label class="text-xs text-gray-500 block mb-1">本表主鍵欄位（例如 NO，給下面的品項明細表關聯用，沒有品項明細表可不填）</label>
              ${accessImportFieldSelect(
                "access_import_map_repairkey",
                repairCols,
                cfg.repairMapping.key,
                false
              )}
            </div>
            <div>
              <label class="text-xs text-gray-500 block mb-1">維修日期／時間</label>
              ${accessImportFieldSelect(
                "access_import_map_datetime",
                repairCols,
                cfg.repairMapping.datetime,
                false
              )}
            </div>
            <div>
              <label class="text-xs text-gray-500 block mb-1">維修項目說明</label>
              ${accessImportFieldSelect(
                "access_import_map_items",
                repairCols,
                cfg.repairMapping.items,
                false
              )}
            </div>
            <div>
              <label class="text-xs text-gray-500 block mb-1">里程數</label>
              ${accessImportFieldSelect(
                "access_import_map_mileage",
                repairCols,
                cfg.repairMapping.mileage,
                false
              )}
            </div>
            <div>
              <label class="text-xs text-gray-500 block mb-1">技師</label>
              ${accessImportFieldSelect(
                "access_import_map_mechanic",
                repairCols,
                cfg.repairMapping.mechanic,
                false
              )}
            </div>
            <div>
              <label class="text-xs text-gray-500 block mb-1">金額</label>
              ${accessImportFieldSelect(
                "access_import_map_cost",
                repairCols,
                cfg.repairMapping.cost,
                false
              )}
            </div>
            <div class="col-span-2">
              <label class="text-xs text-gray-500 block mb-1">備註</label>
              ${accessImportFieldSelect(
                "access_import_map_repairnotes",
                repairCols,
                cfg.repairMapping.notes,
                false
              )}
            </div>
          </div>
          <p class="text-xs text-gray-400">
            如果舊系統只有一張表、每次維修都是新的一列，這裡也可以直接選跟主要資料表一樣的表，
            關聯欄位選同一個車牌／卡號欄位就好。
          </p>

          <label class="flex items-center gap-2 text-sm font-bold text-gray-600 pt-1">
            <input type="checkbox" id="access_import_use_items"
              onchange="window.accessImportToggleItemsSection()" ${
                cfg.useItemsTable ? "checked" : ""
              } />
            另外還有一張品項明細表（例如換了哪些零件），要一起匯進每筆維修紀錄
          </label>
          <p class="text-xs text-gray-400">
            要用這個功能，上面的「本表主鍵欄位」要先選好，明細表才知道要對回哪一筆維修紀錄。
          </p>
          ${itemsSectionHtml}
        </div>
      `;
    }

    let catalogSectionHtml = "";
    if (cfg.catalogImport.enabled) {
      const catalogTableName = cfg.catalogImport.table || tableNames[0];
      const catalogCols = accessImportTables[catalogTableName]
        ? accessImportTables[catalogTableName].columns
        : [];
      const catalogTableOptions = tableNames
        .map(
          (n) =>
            `<option value="${escapeAttrForBadge(n)}" ${
              n === catalogTableName ? "selected" : ""
            }>${escapeAttrForBadge(n)}（${accessImportTables[n].rows.length} 筆）</option>`
        )
        .join("");

      let progressHtml = "";
      if (catalogImportStatus === "importing") {
        progressHtml = `<p id="access_import_catalog_progress_status" class="text-sm text-gray-600 font-bold mt-2">處理中… 0 / 0</p>`;
      } else if (catalogImportStatus === "done" && catalogImportResult) {
        const r = catalogImportResult;
        progressHtml = `
          <div class="text-sm text-gray-600 mt-2 bg-white border border-gray-200 rounded p-2 space-y-0.5">
            <p class="font-bold text-teal-700">匯入完成</p>
            <p>共 ${r.total} 筆，新增 ${r.written} 筆</p>
            ${r.skippedDuplicate ? `<p>已存在、略過重複：${r.skippedDuplicate} 筆</p>` : ""}
            ${r.skippedNoName ? `<p>沒有品項名稱、略過：${r.skippedNoName} 筆</p>` : ""}
            ${r.failed ? `<p class="text-red-600 font-bold">失敗：${r.failed} 筆</p>` : ""}
          </div>
        `;
      }

      catalogSectionHtml = `
        <div class="mt-3 pl-4 border-l-4 border-amber-200 space-y-2">
          <div>
            <label class="text-sm font-bold text-gray-600 block mb-1">品項清單表</label>
            <select id="access_import_catalog_table" onchange="window.accessImportCatalogTableChanged()"
              class="border border-gray-300 rounded px-2 py-1.5 w-full text-sm">
              ${catalogTableOptions}
            </select>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-xs text-gray-500 block mb-1">品項名稱（必填）</label>
              ${accessImportFieldSelect(
                "access_import_map_catalogname",
                catalogCols,
                cfg.catalogImport.mapping.name,
                true
              )}
            </div>
            <div>
              <label class="text-xs text-gray-500 block mb-1">預設金額</label>
              ${accessImportFieldSelect(
                "access_import_map_catalogprice",
                catalogCols,
                cfg.catalogImport.mapping.price,
                false
              )}
            </div>
            <div class="col-span-2">
              <label class="text-xs text-gray-500 block mb-1">類別代號（選填，對不到系統分類就歸類「其他」）</label>
              ${accessImportFieldSelect(
                "access_import_map_catalogcategory",
                catalogCols,
                cfg.catalogImport.mapping.categoryCode,
                false
              )}
            </div>
          </div>
          <label class="flex items-center gap-2 text-xs text-gray-500">
            <input type="checkbox" id="access_import_catalog_skip_dup" onchange="window.accessImportSyncAndRerender()" ${
              cfg.catalogImport.skipDuplicates ? "checked" : ""
            } />
            同分類裡名稱重複的就跳過，不要重複新增
          </label>
          <div class="flex justify-end pt-1">
            <button onclick="window.accessImportRunCatalogImport()" ${
              catalogImportStatus === "importing" ? "disabled" : ""
            }
              class="px-4 py-2 text-sm font-bold rounded shadow transition disabled:opacity-40"
              style="background-color: #b45309; color: #ffffff">
              匯入品項分類清單
            </button>
          </div>
          ${progressHtml}
        </div>
      `;
    }

    body.innerHTML = `
      <div class="space-y-4">
        <div class="bg-gray-50 border border-gray-200 rounded-lg p-3">
          <label class="text-sm font-bold text-gray-600 block mb-1">主要資料表（客戶／車籍，每一列一台車／一位客戶）</label>
          <select id="access_import_master_table" onchange="window.accessImportMasterTableChanged()"
            class="border border-gray-300 rounded px-2 py-1.5 w-full text-sm mb-3">
            ${masterTableOptions}
          </select>
          <p class="text-xs text-gray-400 mb-2">共 ${masterRowCount} 筆資料</p>

          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-xs text-gray-500 block mb-1">車牌／卡號（必填，會拿來當唯一識別碼）</label>
              ${accessImportFieldSelect(
                "access_import_map_plate",
                masterCols,
                cfg.masterMapping.plate,
                true
              )}
            </div>
            <div>
              <label class="text-xs text-gray-500 block mb-1">客戶姓名</label>
              ${accessImportFieldSelect(
                "access_import_map_name",
                masterCols,
                cfg.masterMapping.name,
                false
              )}
            </div>
            <div>
              <label class="text-xs text-gray-500 block mb-1">電話</label>
              ${accessImportFieldSelect(
                "access_import_map_phone",
                masterCols,
                cfg.masterMapping.phone,
                false
              )}
            </div>
            <div>
              <label class="text-xs text-gray-500 block mb-1">會員編號</label>
              ${accessImportFieldSelect(
                "access_import_map_memberId",
                masterCols,
                cfg.masterMapping.memberId,
                false
              )}
            </div>
            <div class="col-span-2">
              <label class="text-xs text-gray-500 block mb-1">地址</label>
              ${accessImportFieldSelect(
                "access_import_map_address",
                masterCols,
                cfg.masterMapping.address,
                false
              )}
            </div>
            <div class="col-span-2">
              <label class="text-xs text-gray-500 block mb-1">備註</label>
              ${accessImportFieldSelect(
                "access_import_map_notes",
                masterCols,
                cfg.masterMapping.notes,
                false
              )}
            </div>
          </div>

          <label class="flex items-start gap-2 text-xs text-gray-500 mt-3 pt-3 border-t border-gray-200">
            <input type="checkbox" id="access_import_keep_extra"
              onchange="window.accessImportSyncAndRerender()" class="mt-0.5" ${
                cfg.masterMapping.keepExtraColumns ? "checked" : ""
              } />
            <span>
              上面沒有對應到的其他欄位（例如引擎號碼、顏色、生日…）自動整理成文字附加到備註最後面，避免舊資料默默遺失
              <span class="text-gray-400">（不勾的話，這些欄位的資料就不會匯入）</span>
            </span>
          </label>
        </div>

        <div class="bg-gray-50 border border-gray-200 rounded-lg p-3">
          <label class="flex items-center gap-2 text-sm font-bold text-gray-600">
            <input type="checkbox" id="access_import_use_repair"
              onchange="window.accessImportToggleRepairSection()" ${
                cfg.useRepairTable ? "checked" : ""
              } />
            另外有一張維修紀錄表要一起匯入
          </label>
          ${repairSectionHtml}
        </div>

        <div class="bg-gray-50 border border-gray-200 rounded-lg p-3">
          <label class="flex items-center gap-2 text-sm font-bold text-gray-600">
            <input type="checkbox" id="access_import_use_catalog"
              onchange="window.accessImportToggleCatalogSection()" ${
                cfg.catalogImport.enabled ? "checked" : ""
              } />
            順便把舊系統的「品項清單」匯進分類選單（跟客戶／維修紀錄無關，是獨立的一步）
          </label>
          ${catalogSectionHtml}
        </div>

        <label class="flex items-center gap-2 text-sm text-gray-600">
          <input type="checkbox" id="access_import_overwrite"
            onchange="window.accessImportToggleOverwrite()" ${
              cfg.overwriteExisting ? "checked" : ""
            } />
          如果車牌／卡號在系統裡已經有客戶資料，用這次匯入的內容覆蓋過去
          （不勾的話：已存在的客戶資料保持不變，但維修紀錄一樣會新增進去）
        </label>

        <div class="flex justify-between pt-2">
          <button onclick="resetAccessImportState(); renderAccessImportBody();"
            class="bg-gray-100 text-gray-600 px-5 py-2.5 text-sm font-bold rounded hover:bg-gray-200 shadow transition">
            重新選檔案
          </button>
          <button onclick="window.accessImportGoToPreview()"
            style="background-color: #0f766e; color: #ffffff"
            class="px-6 py-2.5 text-sm font-bold rounded hover:opacity-90 shadow transition">
            下一步：預覽
          </button>
        </div>
      </div>
    `;
    return;
  }

  if (accessImportStep === "preview") {
    const plan = accessImportPlan;
    const totalRepairs = plan.customers.reduce(
      (sum, c) => sum + c.repairs.length,
      0
    );
    const previewRows = plan.customers.slice(0, 10);

    const rowsHtml = previewRows
      .map(
        (c) => `
        <tr class="border-b border-gray-100">
          <td class="py-1.5 pr-3 font-bold">${escapeAttrForBadge(c.key)}</td>
          <td class="py-1.5 pr-3">${escapeAttrForBadge(c.customer.name || "—")}</td>
          <td class="py-1.5 pr-3">${escapeAttrForBadge(c.customer.phone || "—")}</td>
          <td class="py-1.5 pr-3 text-right">${c.repairs.length}</td>
        </tr>
      `
      )
      .join("");

    const warnings = [];
    if (plan.skippedMasterCount > 0) {
      warnings.push(
        `有 ${plan.skippedMasterCount} 列因為車牌／卡號欄位是空的，已略過不匯入。`
      );
    }
    if (plan.skippedRepairsCount > 0) {
      warnings.push(
        `有 ${plan.skippedRepairsCount} 筆維修紀錄的關聯欄位本身是空的，沒辦法關聯，已略過不匯入。`
      );
    }
    if (plan.autoCreatedFromOrphanRepairs > 0) {
      const sampleText = (plan.orphanRepairSamples || [])
        .slice(0, 8)
        .map((s) => escapeAttrForBadge(String(s.plate ?? "")))
        .join("、");
      const more =
        plan.autoCreatedFromOrphanRepairs > (plan.orphanRepairSamples || []).length
          ? "…等"
          : "";
      warnings.push(
        `有 ${plan.autoCreatedFromOrphanRepairs} 筆維修紀錄在車籍主檔裡查無對應車牌／卡號（車籍主檔本身沒登這台車），系統已自動補建空白車籍資料讓這些維修紀錄照樣匯入，事後請補上姓名／電話。例如：${sampleText}${more}`
      );
    }

    body.innerHTML = `
      <div class="space-y-4">
        <div class="grid grid-cols-2 gap-3 text-center">
          <div class="bg-indigo-50 border border-indigo-200 rounded-lg py-4">
            <div class="text-2xl font-bold text-indigo-700">${plan.customers.length}</div>
            <div class="text-xs text-gray-500 mt-1">筆客戶／車籍資料</div>
          </div>
          <div class="bg-teal-50 border border-teal-200 rounded-lg py-4">
            <div class="text-2xl font-bold text-teal-700">${totalRepairs}</div>
            <div class="text-xs text-gray-500 mt-1">筆維修紀錄</div>
          </div>
        </div>

        ${
          warnings.length > 0
            ? `<div class="bg-yellow-50 border border-yellow-300 text-yellow-800 text-xs rounded-lg p-3 space-y-1">
                ${warnings.map((w) => `<p>${w}</p>`).join("")}
              </div>`
            : ""
        }

        <div>
          <p class="text-xs text-gray-400 mb-1">預覽前 10 筆（車牌／卡號｜姓名｜電話｜維修筆數）：</p>
          <div class="border border-gray-200 rounded-lg overflow-hidden">
            <table class="w-full text-sm">
              <thead class="bg-gray-50 text-gray-500 text-xs">
                <tr>
                  <th class="text-left py-1.5 px-3">車牌／卡號</th>
                  <th class="text-left py-1.5 px-3">姓名</th>
                  <th class="text-left py-1.5 px-3">電話</th>
                  <th class="text-right py-1.5 px-3">維修筆數</th>
                </tr>
              </thead>
              <tbody>${rowsHtml || `<tr><td colspan="4" class="text-center text-gray-400 py-4">沒有可匯入的資料</td></tr>`}</tbody>
            </table>
          </div>
        </div>

        <p class="text-xs text-gray-400">
          同一批資料按「開始匯入」之後不要重複執行，維修紀錄是逐筆新增，重複匯入會造成重複紀錄。
        </p>

        <div class="flex justify-between pt-2">
          <button onclick="window.accessImportBackToMapping()"
            class="bg-gray-100 text-gray-600 px-5 py-2.5 text-sm font-bold rounded hover:bg-gray-200 shadow transition">
            上一步
          </button>
          <button onclick="window.accessImportRunImport()" ${
            plan.customers.length === 0 ? "disabled" : ""
          }
            style="background-color: #0f766e; color: #ffffff"
            class="px-6 py-2.5 text-sm font-bold rounded hover:opacity-90 shadow transition disabled:opacity-40">
            開始匯入
          </button>
        </div>
      </div>
    `;
    return;
  }

  if (accessImportStep === "importing") {
    body.innerHTML = `
      <div class="py-12 text-center">
        <p id="access_import_progress_status" class="text-gray-600 font-bold mb-4">處理中… 0 / 0</p>
        <div class="w-full bg-gray-100 rounded-full h-3 overflow-hidden max-w-sm mx-auto">
          <div id="access_import_progress_bar" style="width:0%; background-color:#0f766e"
            class="h-3 transition-all"></div>
        </div>
        <p class="text-xs text-gray-400 mt-4">匯入中請不要關閉這個視窗</p>
      </div>
    `;
    return;
  }

  if (accessImportStep === "done") {
    const r = accessImportResult;
    body.innerHTML = `
      <div class="py-8 text-center space-y-3">
        <p class="text-lg font-bold text-gray-800">匯入完成</p>
        <div class="text-sm text-gray-600 space-y-1">
          <p>新增客戶資料：${r.customersWritten} 筆</p>
          <p>已存在、略過未覆蓋：${r.customersSkipped} 筆</p>
          <p>新增維修紀錄：${r.repairsWritten} 筆</p>
          ${
            r.autoCreatedFromOrphanRepairs > 0
              ? `<p class="text-yellow-700">其中 ${r.autoCreatedFromOrphanRepairs} 筆的車籍資料是自動補建的空白資料，記得回去搜尋車牌補上姓名／電話</p>`
              : ""
          }
          ${r.failed > 0 ? `<p class="text-red-600 font-bold">失敗：${r.failed} 筆（詳細錯誤可按 F12 看主控台）</p>` : ""}
        </div>
        <button onclick="window.accessImportFinish()"
          style="background-color: #0f766e; color: #ffffff"
          class="px-6 py-2.5 text-sm font-bold rounded hover:opacity-90 shadow transition mt-2">
          完成
        </button>
      </div>
    `;
  }
}
