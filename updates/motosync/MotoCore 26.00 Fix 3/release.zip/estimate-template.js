// ============================================================
// 估價單產生器 —— 完全比照老闆提供的「永鑫車業估價單」Word 範本重建，
// 並把資料庫（Firebase）裡的資料自動填進對應欄位。
//
// 範本裡有些欄位 App 資料庫本來就沒有存（身分證號、型式、定金、餘款、
// 借用車輛區間、簽章），這些欄位一律維持空白，比照原始範本讓店家自己
// 手寫，不會亂編資料進去。
// ============================================================

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  WidthType, BorderStyle, AlignmentType, VerticalAlign, TableLayoutType,
} = require("docx");

// 原始 Word 範本裡「品項總表」那張表格的欄寬（單位：twips），
// 跟老闆提供的範本檔案量出來的完全一樣，這樣兩邊合併儲存格的切法才會對得起來。
const GRID = [704, 2693, 284, 1559, 709, 425, 2010, 542, 1530];
const CONTENT_WIDTH = GRID.reduce((a, b) => a + b, 0); // 10456

function gridWidth(startIdx, count) {
  return GRID.slice(startIdx, startIdx + count).reduce((a, b) => a + b, 0);
}

const FONT = "標楷體";

function border() {
  return { style: BorderStyle.SINGLE, size: 4, color: "000000" };
}
function allBorders() {
  return { top: border(), bottom: border(), left: border(), right: border() };
}

// ------------------------------------------------------------
// 大寫金額轉換：把數字金額轉成「壹貳參...拾佰仟萬」防塗改的中文大寫，
// 對應範本「合計新臺幣＿＿拾＿＿萬＿＿仟＿＿佰＿＿十　元整」那一列。
// 目前只處理到「億」以內，機車行的估價金額不會超過這個範圍。
// ------------------------------------------------------------
const CAP_DIGIT = ["零", "壹", "貳", "參", "肆", "伍", "陸", "柒", "捌", "玖"];
const CAP_UNIT = ["", "拾", "佰", "仟"];
const CAP_BIG_UNIT = ["", "萬", "億"];

function toChineseCapitalAmount(amount) {
  const n = Math.round(Number(amount) || 0);
  if (n === 0) return "零元整";
  if (n < 0) return "負" + toChineseCapitalAmount(-n);

  const s = String(n);
  const groups = [];
  for (let i = s.length; i > 0; i -= 4) {
    groups.unshift(s.slice(Math.max(0, i - 4), i));
  }

  let result = "";
  const groupCount = groups.length;
  groups.forEach((group, gi) => {
    const bigUnit = CAP_BIG_UNIT[groupCount - 1 - gi] || "";
    let groupStr = "";
    let needZero = false;
    for (let i = 0; i < group.length; i++) {
      const digit = Number(group[i]);
      const unitIdx = group.length - 1 - i;
      if (digit === 0) {
        needZero = groupStr.length > 0;
      } else {
        if (needZero) {
          groupStr += "零";
          needZero = false;
        }
        groupStr += CAP_DIGIT[digit] + CAP_UNIT[unitIdx];
      }
    }
    if (groupStr) {
      // 前一組有值、這一組開頭是零（例如 10005 的「萬」跟「元」中間），要補零
      if (result && group[0] === "0" && groupStr[0] !== "零") {
        result += "零";
      }
      result += groupStr + bigUnit;
    } else if (result && bigUnit) {
      // 這個大單位整組都是 0，但後面還有更小的組別有值，補一個零銜接
      if (!result.endsWith("零")) result += "零";
    }
  });

  return result + "元整";
}

// ------------------------------------------------------------
// 小工具：粗體標楷體文字段落
// ------------------------------------------------------------
function boldPara(text, opts = {}) {
  const { size = 20, align = AlignmentType.LEFT, spacingBefore = 60, spacingAfter = 60 } = opts;
  return new Paragraph({
    alignment: align,
    spacing: { before: spacingBefore, after: spacingAfter, line: 240, lineRule: "atLeast" },
    children: [
      new TextRun({ text, bold: true, size, font: FONT }),
    ],
  });
}

function clausePara(text) {
  return new Paragraph({
    spacing: { before: 0, after: 20, line: 200, lineRule: "atLeast" },
    children: [new TextRun({ text, size: 16, font: FONT })],
  });
}

function cell(text, { width, columnSpan = 1, align = AlignmentType.LEFT, bold = true, size = 20, borders } = {}) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    columnSpan,
    verticalAlign: VerticalAlign.CENTER,
    borders: borders || allBorders(),
    margins: { top: 40, bottom: 40, left: 60, right: 60 },
    children: [
      new Paragraph({
        alignment: align,
        children: [new TextRun({ text: text || "", bold, size, font: FONT })],
      }),
    ],
  });
}

// label 有值才加冒號＋內容；沒有值就只顯示欄位名稱本身（跟老闆原本的空白範本一樣)
function labelValue(label, value) {
  return value ? `${label}：${value}` : label;
}

/**
 * data 欄位（全部可省略，省略的欄位就照原始範本留白）：
 * {
 *   entryDate: 'YYYY-MM-DD',   // 進場日期
 *   quoteDate: 'YYYY-MM-DD',   // 報價日期
 *   customerName, phone,       // 姓名／電話（App 顧客資料裡有）
 *   plate,                     // 車牌（查詢用的車牌／卡號）
 *   mileage,                   // 里程（App 維修紀錄裡有）
 *   notes,                     // 備註
 *   items: [{ name, amount }], // 維修項目，最多 30 筆，超過會被截斷
 *   totalAmount,               // 總金額；沒給就用 items 加總
 * }
 */
// ------------------------------------------------------------
// 十條契約條款（跟老闆原始範本逐字相同）——放在模組層級，這樣 docx 版
// 跟 HTML／列印版才能共用同一份文字，不用維護兩份一樣的內容。
// ------------------------------------------------------------
const CLAUSES = [
  "(一) 本估價單僅估價日當月有效，逾期須視材料物價波動等情形，重新報價。",
  "(二) 初估價目不代表最後完修價目，實際內容以拆修後確認或車主同意修復程度為主。",
  "(三) 車輛在維修期間，如遇天災人禍或其他不可抗拒之情況而發生損壞時，本行概不負責。",
  "(四) 委修人同意承修人可因作業上之需要於適當地點進行試車，如有意外以恢復原狀為原則。",
  "(五) 預索取估價單，委修人須先給付一成估價工資於本行，維修後可扣除（30日內有效）。",
  "(六) 委修人同意支付本行道路救援費/車輛暫放保管費/檢測拆裝費/承辦派遣人力等相關費用。所有費用未結清前，承修人有權拒絕交車動作，所施工之料件亦為本行所有。",
  "(七) 委修人同意提供正確車籍資料於本行，若發現失竊車或聯絡不到，即停止施工並請求檢警協助。",
  "(八) 委修人如逾期取車，願負擔車輛保管費每日 50 元，並同意棄車留行，案報警察局處理。",
  "(九) 如有向本行暫借代步車，自借出日至歸還日期間，所有違規或意外事件，借車人願負完全責任。",
  "(十) 維修期間車輛內附件及物品，由委修人自行保管，承修人不負擔保管責任。",
];

async function buildEstimateDocxBuffer(data = {}) {
  const items = Array.isArray(data.items) ? data.items.slice(0, 30) : [];
  const truncated = Array.isArray(data.items) && data.items.length > 30;

  const total =
    data.totalAmount != null
      ? Number(data.totalAmount) || 0
      : items.reduce((sum, it) => sum + (Number(it.amount) || 0), 0);
  const hasAnyAmount = data.totalAmount != null || items.length > 0;

  const [entryY, entryM, entryD] = (data.entryDate || "").split("-");
  const [quoteY, quoteM, quoteD] = (data.quoteDate || "").split("-");

  // ---------------- 標題 ----------------
  const titleParas = [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 40, after: 40, line: 480, lineRule: "exact" },
      children: [new TextRun({ text: data.shopName || "永　鑫　車　業", bold: true, size: 40, font: FONT })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 40, after: 80, line: 480, lineRule: "exact" },
      children: [new TextRun({ text: "估　　價　　單", bold: true, size: 40, font: FONT })],
    }),
  ];

  // 進場日期／報價日期那一行，現在移到姓名／備註資訊表格下方、品項總表上方。
  const dateParas = [
    new Paragraph({
      spacing: { before: 40, after: 100, line: 240, lineRule: "exact" },
      children: [
        new TextRun({
          text: `進場日期：${entryY ? `${entryY}年${entryM}月${entryD}日` : "　　年　　月　　日"}　　　　　　　　　　報價日期：${
            quoteY ? `${quoteY}年${quoteM}月${quoteD}日` : "　　年　　月　　日"
          }`,
          bold: true,
          size: 20,
          font: FONT,
        }),
      ],
    }),
  ];

  // ---------------- 品項總表（30 列，左右各 15 列） ----------------
  const headerRow = new TableRow({
    tableHeader: true,
    children: [
      cell("序號", { width: GRID[0], align: AlignmentType.CENTER }),
      cell("品名", { width: gridWidth(1, 2), columnSpan: 2, align: AlignmentType.CENTER }),
      cell("金額", { width: GRID[3], align: AlignmentType.CENTER }),
      cell("序號", { width: GRID[4], align: AlignmentType.CENTER }),
      cell("品名", { width: gridWidth(5, 3), columnSpan: 3, align: AlignmentType.CENTER }),
      cell("金額", { width: GRID[8], align: AlignmentType.CENTER }),
    ],
  });

  const itemRows = [];
  for (let i = 0; i < 15; i++) {
    const left = items[i];
    const right = items[i + 15];
    itemRows.push(
      new TableRow({
        children: [
          cell(String(i + 1), { width: GRID[0], align: AlignmentType.CENTER, bold: false }),
          cell(left ? left.name : "", { width: gridWidth(1, 2), columnSpan: 2, bold: false }),
          cell(left && left.amount != null ? String(left.amount) : "", {
            width: GRID[3],
            align: AlignmentType.RIGHT,
            bold: false,
          }),
          cell(String(i + 16), { width: GRID[4], align: AlignmentType.CENTER, bold: false }),
          cell(right ? right.name : "", { width: gridWidth(5, 3), columnSpan: 3, bold: false }),
          cell(right && right.amount != null ? String(right.amount) : "", {
            width: GRID[8],
            align: AlignmentType.RIGHT,
            bold: false,
          }),
        ],
      })
    );
  }

  const totalText = hasAnyAmount
    ? `合計新臺幣　${toChineseCapitalAmount(total)}`
    : "合計新臺幣　　拾　　萬　　仟　　佰　　十　元整";

  const summaryRow = new TableRow({
    children: [
      cell(totalText, { width: gridWidth(0, 6), columnSpan: 6, align: AlignmentType.LEFT }),
      cell("定金　　　　元", { width: GRID[6], columnSpan: 1 }),
      cell("餘款　　　　元", { width: gridWidth(7, 2), columnSpan: 2 }),
    ],
  });

  const borrowRow = new TableRow({
    children: [
      cell("借用車輛：", { width: gridWidth(0, 2), columnSpan: 2 }),
      cell("自　　年　　月　　日 起至　　年　　月　　日止", {
        width: gridWidth(2, 7),
        columnSpan: 7,
      }),
    ],
  });

  const SIGN_NOTE_WIDTH = 2800; // 剛好夠「（本單不含5％營業稅）」一行不換行，又不會留太多空白
  const signRow = new TableRow({
    children: [
      cell("已詳讀且同意所有內容簽章：", {
        width: CONTENT_WIDTH - SIGN_NOTE_WIDTH,
        columnSpan: 6,
        borders: { top: border(), bottom: border(), left: border(), right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" } },
      }),
      cell("（本單不含5％營業稅）", {
        width: SIGN_NOTE_WIDTH,
        columnSpan: 3,
        align: AlignmentType.RIGHT,
        borders: { top: border(), bottom: border(), left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" }, right: border() },
      }),
    ],
  });

  const itemTable = new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    columnWidths: GRID,
    layout: TableLayoutType.FIXED,
    rows: [headerRow, ...itemRows, summaryRow, borrowRow, signRow],
  });

  // ---------------- 十條契約條款（跟老闆原始範本逐字相同） ----------------
  const clauseParas = CLAUSES.map((t) => clausePara(t));

  // ---------------- 底部：姓名／身分證號／電話、車牌／里程／型式、備註 ----------------
  const infoCol = Math.floor(10485 / 3);
  const infoTable = new Table({
    width: { size: 10485, type: WidthType.DXA },
    columnWidths: [infoCol, infoCol, 10485 - infoCol * 2],
    layout: TableLayoutType.FIXED,
    rows: [
      new TableRow({
        children: [
          cell(labelValue("姓名", data.customerName), { width: infoCol }),
          cell("身分證號", { width: infoCol }),
          cell(labelValue("電話", data.phone), { width: 10485 - infoCol * 2 }),
        ],
      }),
      new TableRow({
        children: [
          cell(labelValue("車牌", data.plate), { width: infoCol }),
          cell(labelValue("里程", data.mileage != null && data.mileage !== "" ? `${data.mileage} km` : ""), {
            width: infoCol,
          }),
          cell("型式", { width: 10485 - infoCol * 2 }),
        ],
      }),
      new TableRow({
        children: [
          cell(labelValue("備註", data.notes), { width: 10485, columnSpan: 3 }),
        ],
      }),
    ],
  });

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            size: { width: 11906, height: 16838 },
            margin: { top: 720, bottom: 720, left: 720, right: 720 },
          },
        },
        children: [
          ...titleParas,
          infoTable,
          new Paragraph({ spacing: { before: 40, after: 0 }, children: [] }),
          ...dateParas,
          itemTable,
          new Paragraph({ spacing: { before: 40, after: 20 }, children: [] }),
          ...clauseParas,
        ],
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return { buffer, truncated };
}

module.exports = { buildEstimateDocxBuffer, toChineseCapitalAmount, CLAUSES };
