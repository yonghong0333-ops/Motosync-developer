// ============================================================
// MotoSync Bootloader
//
// 這支程式就是「exe 安裝的東西」，本身不含任何業務邏輯（顧客管理、
// 估價單那些畫面），只做：
//   1. 身分驗證（離線金鑰 / Google 登入 / 忘記密碼白名單）
//   2. 版本管理（查詢、下載、驗證、安裝、切換、退回舊版本）
//   3. 決定現在要載入哪一個「軟體邏輯」版本，然後把視窗開起來、
//      把該版本的 main.js 掛進來
//
// 對應設計文件「三、Bootloader 概念」。
// ============================================================

const { app, BrowserWindow, ipcMain, shell, dialog } = require("electron");
const path = require("path");
const http = require("http");
const https = require("https");
const crypto = require("crypto");
const fs = require("fs");

const config = require("./config");
const { UpdateEngine, UpdateError } = require("./update-engine");
const { verifyBossPassword, hasBossPassword, setBossPassword } = require("./boss-auth");

const CHROME_USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
app.userAgentFallback = CHROME_USER_AGENT;

const VERSIONS_DIR = path.join(app.getPath("userData"), "versions");
const engine = new UpdateEngine({ config, baseDir: VERSIONS_DIR });

let mainWindow = null;
let skipCloseConfirmDialog = false;
let currentAppDir = null; // 目前這次執行期間，實際載入的軟體邏輯資料夾
let currentAppVersion = null;

// 暫時的除錯記錄：只為了排查「按 X 沒跳出關閉確認畫面」這個問題，
// 之後確認正常後可以整段拿掉。寫在 userData 資料夾裡，使用者用
// 記事本就能直接打開看，不用開發者工具或終端機。
const DEBUG_LOG_PATH = path.join(app.getPath("userData"), "quit-debug.log");
function debugLog(msg) {
  try {
    fs.appendFileSync(
      DEBUG_LOG_PATH,
      `[${new Date().toISOString()}] ${msg}\n`
    );
  } catch (err) {
    // 記錄失敗也不要影響正常流程
  }
}
let startupVerifyTimer = null;

// ============================================================
// 一、離線登入授權金鑰（原本在 main.js，身分驗證相關，
// 依三層分類原則搬到 bootloader，永遠不會被線上更新動到）
// ============================================================

function offlineLicenseCanonicalString(license) {
  return [
    license.shop || "",
    license.issuedAt || "",
    license.expiresAt || "",
    license.deviceNote || "",
    license.exeHash || "",
  ].join("|");
}

// ⚠️ exeHash 綁的是 config.licenseLockVersion（一個「刻意才手動改」的
// 鎖版本值），不是 package.json 的 version——這樣 bootloader 日常打包、
// 版本號正常往上跳的時候，已經核發出去的舊金鑰不會跟著全部失效。
// 必須跟 generate-license.js 的 currentExeHash() 逐字一致。
const DEVICE_LOCK_ID = crypto
  .createHash("sha256")
  .update(`${config.deviceLockSalt}|${config.licenseLockVersion}`)
  .digest("hex");

function currentExeHash() {
  return DEVICE_LOCK_ID;
}

// Ed25519 公鑰只需要解析一次；config.js 裡的格式不對的話，讓程式一
// 啟動就用明確的錯誤訊息炸掉，比每次驗證金鑰時才發現要好排查。
let offlineLicensePublicKeyObject = null;
try {
  offlineLicensePublicKeyObject = crypto.createPublicKey(config.offlineLicensePublicKey);
} catch (err) {
  throw new Error(
    `config.js 的 offlineLicensePublicKey 格式不正確，無法解析成 Ed25519 公鑰：${err.message}`
  );
}

function verifyOfflineLicenseFile(filePath) {
  const raw = fs.readFileSync(filePath, "utf8");
  const license = JSON.parse(raw);

  if (!license || typeof license !== "object" || !license.sig) {
    throw new Error("金鑰檔案格式不正確");
  }

  // 非對稱簽章驗證：generate-license.js 用私鑰對 canonical string 簽出
  // 一段 hex 字串（crypto.sign(null, buffer, privateKey)），這裡用公鑰
  // 反向驗證這段簽章是不是真的由那把私鑰簽出來的、且內容沒被改過。
  let sigBuffer;
  try {
    sigBuffer = Buffer.from(license.sig, "hex");
  } catch (err) {
    throw new Error("金鑰檔案格式不正確（簽章不是合法的 hex 字串）");
  }

  const isValid = crypto.verify(
    null,
    Buffer.from(offlineLicenseCanonicalString(license), "utf8"),
    offlineLicensePublicKeyObject,
    sigBuffer
  );

  if (!isValid) {
    throw new Error("金鑰檔案無效（簽章不符）");
  }

  if (license.expiresAt) {
    const expiresAt = new Date(license.expiresAt).getTime();
    if (!Number.isNaN(expiresAt) && Date.now() > expiresAt) {
      throw new Error("金鑰已過期，請聯絡管理者重新核發");
    }
  }

  if (license.exeHash) {
    const actualHash = currentExeHash();
    if (!actualHash || actualHash.toLowerCase() !== String(license.exeHash).toLowerCase()) {
      throw new Error("這把金鑰是為其他版本的安裝程式產生的，無法在這個版本使用");
    }
  }

  return license;
}

function offlineLicenseStoragePath() {
  return path.join(app.getPath("userData"), "offline-license.app");
}

function offlineLicenseFolder() {
  const dir = path.join(path.dirname(process.execPath), "offline-license");
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function findValidLicenseInFolder() {
  const dir = offlineLicenseFolder();
  const files = fs.readdirSync(dir).filter((name) => name.toLowerCase().endsWith(".app"));
  let lastError = null;
  for (const name of files) {
    try {
      const license = verifyOfflineLicenseFile(path.join(dir, name));
      return { filePath: path.join(dir, name), license };
    } catch (err) {
      lastError = err;
    }
  }
  if (lastError) throw lastError;
  return null;
}

// ============================================================
// 🩹 治本：資料夾（offline-license）永遠是「真相來源」，userData 裡的
// offline-license.app 只是備援快取，不能反過來蓋過資料夾。
//
// 原本的寫法是「userData 有快取、驗證得過，就直接用快取，完全不看
// 資料夾」。這在「這台電腦的 userData 是從別家店複製/還原過來的」
// 這種情況下會出事：快取本身簽章合法（因為它本來就是別家店的合法
// 金鑰），所以會一直被判定「驗證通過」而優先使用，即使有人事後把
// 這家店正確的 .app 檔案放進 offline-license 資料夾也沒用，因為
// 程式根本不會走到「讀資料夾」那一步。
//
// 改成每次都先看資料夾：
//   1. 資料夾裡有驗證得過的 .app → 一律用它，並覆蓋掉 userData 快取
//      （不管 userData 快取原本是什麼、是不是別家店的，都會被蓋掉）
//   2. 資料夾裡的檔案都驗證不過（格式錯/簽章錯/過期/版本不符）→
//      記住這個錯誤，但不要馬上回報失敗，改去看 userData 快取還能
//      不能用（例如金鑰隨身碟一時沒插、或資料夾檔案被誤刪的過渡期）
//   3. 資料夾根本沒有任何 .app 檔案 → 一樣退回看 userData 快取
//   4. 兩邊都沒有可用的金鑰 → 資料夾那邊如果有明確錯誤原因，優先把
//      那個錯誤丟出去（比「找不到金鑰檔案」更精確，方便排查）
// ============================================================
function resolveLicense() {
  const savedPath = offlineLicenseStoragePath();

  let folderResult = null;
  let folderError = null;
  try {
    folderResult = findValidLicenseInFolder();
  } catch (err) {
    folderError = err;
  }

  if (folderResult) {
    // 資料夾裡有合法金鑰：這才是真相來源，直接用，並且不管 userData
    // 快取原本是什麼（自己的舊版、還是別家店殘留的），一律覆蓋掉。
    try {
      fs.copyFileSync(folderResult.filePath, savedPath);
    } catch (e) {
      // 覆蓋快取失敗不影響這次啟動照樣能用資料夾裡的金鑰，只是下次
      // 資料夾檔案被移除時會少一份備援，不用因此整個開機流程失敗。
    }
    return folderResult.license;
  }

  // 資料夾沒有可用金鑰（不管是完全沒有檔案、還是有檔案但都驗證不過），
  // 退回看 userData 裡的舊快取還能不能用，當作過渡期的備援。
  if (fs.existsSync(savedPath)) {
    try {
      return verifyOfflineLicenseFile(savedPath);
    } catch (err) {
      try {
        fs.unlinkSync(savedPath);
      } catch (e) {}
    }
  }

  // 兩邊都沒有可用金鑰：如果資料夾那邊有明確的錯誤原因（例如「簽章
  // 不符」「已過期」），把那個原因丟出去，比籠統的「找不到金鑰檔案」
  // 更方便排查；資料夾單純是空的話才回傳 null，交給呼叫端顯示
  // 「找不到金鑰檔案」。
  if (folderError) throw folderError;
  return null;
}

ipcMain.handle("check-app-license", async () => {
  try {
    const license = resolveLicense();
    if (!license) {
      return {
        ok: false,
        reason: "找不到金鑰檔案，請把授權金鑰（.app）放進 offline-license 資料夾",
      };
    }
    // key 給「關於軟體」頁顯示＋複製用：直接用這把金鑰檔案本身的簽章（sig）當作
    // 顯示用的授權金鑰字串——每家店的 .app 金鑰簽章都不一樣，一樣是動態從
    // 金鑰檔案讀出來的，不是寫死在程式碼裡的值。
    return {
      ok: true,
      shop: license.shop || null,
      expiresAt: license.expiresAt || null,
      key: license.sig || null,
    };
  } catch (err) {
    // 金鑰檔案存在但無效（簽章不符／已過期／對應到其他版本）
    return { ok: false, reason: err.message || "金鑰檔案無效" };
  }
});

ipcMain.handle("offline-login", async () => {
  const folder = offlineLicenseFolder();
  let license;
  try {
    license = resolveLicense();
  } catch (err) {
    shell.openPath(folder);
    throw new Error(
      `資料夾裡的金鑰檔案無效（${err.message}），已幫你打開 offline-license 資料夾，請確認裡面的 .app 檔案是否正確`
    );
  }
  if (!license) {
    shell.openPath(folder);
    throw new Error("找不到金鑰檔案，已幫你打開 offline-license 資料夾，請把 .app 金鑰檔案放進去");
  }
  return { ok: true, shop: license.shop || null, expiresAt: license.expiresAt || null };
});

// ============================================================
// 二、Google 登入（身分驗證，搬到 bootloader，原理跟原本
// main.js 完全相同：系統瀏覽器 + 本機小伺服器接回授權碼）
// ============================================================

function base64url(buffer) {
  return buffer.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function createOAuthCallbackServer() {
  return new Promise((resolveServer) => {
    let resolveCode, rejectCode;
    const codePromise = new Promise((res, rej) => {
      resolveCode = res;
      rejectCode = rej;
    });
    const server = http.createServer((req, res) => {
      const reqUrl = new URL(req.url, "http://127.0.0.1");
      if (reqUrl.pathname !== "/callback") {
        res.writeHead(404);
        res.end();
        return;
      }
      const code = reqUrl.searchParams.get("code");
      const error = reqUrl.searchParams.get("error");
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(
        error
          ? `<html><body style="font-family:-apple-system,Arial,sans-serif;text-align:center;margin-top:100px;"><h2>登入已取消</h2><p>您可以關閉這個分頁，回到「永鑫機車系統」應用程式。</p></body></html>`
          : `<html><body style="font-family:-apple-system,Arial,sans-serif;text-align:center;margin-top:100px;"><h2>登入成功</h2><p>請關閉這個分頁，回到「永鑫機車系統」應用程式繼續操作。</p></body></html>`
      );
      setTimeout(() => server.close(), 500);
      if (code) resolveCode(code);
      else rejectCode(new Error(error || "no_code_returned"));
    });
    server.listen(0, "127.0.0.1", () => {
      resolveServer({ port: server.address().port, codePromise });
    });
  });
}

function exchangeCodeForTokens(code, codeVerifier, redirectUri) {
  return new Promise((resolve, reject) => {
    const postData = new URLSearchParams({
      code,
      client_id: config.googleClientId,
      client_secret: config.googleClientSecret,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
      code_verifier: codeVerifier,
    }).toString();

    const req = https.request(
      {
        hostname: "oauth2.googleapis.com",
        path: "/token",
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Content-Length": Buffer.byteLength(postData),
        },
      },
      (res) => {
        let body = "";
        res.on("data", (chunk) => (body += chunk));
        res.on("end", () => {
          try {
            const json = JSON.parse(body);
            if (json.error) reject(new Error(json.error_description || json.error));
            else resolve(json);
          } catch (e) {
            reject(e);
          }
        });
      }
    );
    req.on("error", reject);
    req.write(postData);
    req.end();
  });
}

// 抽成獨立函式，因為現在有兩個地方需要「跳出瀏覽器叫使用者用 Google
// 登入」：(1) 軟體邏輯層原本的 google-login IPC，(2) 下面 boot 流程裡
// 「先登入 Google 再去讀老闆密碼設定」的 ensureGoogleSignedIn。
async function doGoogleOAuthLogin() {
  const { port, codePromise } = await createOAuthCallbackServer();
  const redirectUri = `http://127.0.0.1:${port}/callback`;
  const codeVerifier = base64url(crypto.randomBytes(64));
  const codeChallenge = base64url(crypto.createHash("sha256").update(codeVerifier).digest());

  const authUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  authUrl.searchParams.set("client_id", config.googleClientId);
  authUrl.searchParams.set("redirect_uri", redirectUri);
  authUrl.searchParams.set("response_type", "code");
  authUrl.searchParams.set("scope", "openid email profile");
  authUrl.searchParams.set("code_challenge", codeChallenge);
  authUrl.searchParams.set("code_challenge_method", "S256");
  authUrl.searchParams.set("prompt", "select_account");

  await shell.openExternal(authUrl.toString());

  try {
    const code = await codePromise;
    const tokens = await exchangeCodeForTokens(code, codeVerifier, redirectUri);
    if (mainWindow) mainWindow.focus();
    return { idToken: tokens.id_token, accessToken: tokens.access_token };
  } catch (err) {
    if (mainWindow) mainWindow.focus();
    throw err;
  }
}

ipcMain.handle("google-login", () => doGoogleOAuthLogin());

// ============================================================
// 二之一、把 Google 的 id_token 換成分店 Firebase 的 idToken
//
// Google OAuth 給的 id_token，Firebase Realtime Database 的安全規則
// 看不懂（規則檢查的是 Firebase Auth 的 idToken，不是 Google 原生的
// id_token）。要讓 boss-auth.js 的 REST 呼叫在「規則要求已登入」的
// 情況下通過，得先拿 Google id_token 去打 Identity Toolkit 的
// signInWithIdp，換成這家分店 Firebase 專案自己的 idToken，之後
// REST 呼叫網址加上 ?auth=<這個 idToken> 才會被規則放行。
//
// 前提：分店的 Firebase 專案（Authentication → Sign-in method）要
// 開啟 Google 登入方式，且允許的網域/OAuth 用戶端要對得起來。
// ============================================================
function exchangeGoogleIdTokenForFirebaseIdToken(shopFirebaseConfig, googleIdToken) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      postBody: `id_token=${googleIdToken}&providerId=google.com`,
      requestUri: "http://localhost",
      returnIdpCredential: true,
      returnSecureToken: true,
    });
    const req = https.request(
      {
        hostname: "identitytoolkit.googleapis.com",
        path: `/v1/accounts:signInWithIdp?key=${encodeURIComponent(shopFirebaseConfig.apiKey)}`,
        method: "POST",
        headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) },
      },
      (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            const json = JSON.parse(data);
            if (json.error) {
              reject(new Error(json.error.message || "Firebase 登入交換失敗"));
              return;
            }
            resolve(json.idToken); // 這個才是 REST 呼叫要用的 ?auth= 值
          } catch (err) {
            reject(err);
          }
        });
      }
    );
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

// 這次執行期間換到的 Firebase idToken，boss-auth.js 的呼叫都會帶上它
let shopFirebaseIdToken = null;

// ============================================================
// 一之一、開機一開始先叫使用者用 Google 帳號登入，換到分店 Firebase
// 的 idToken，之後 ensureBossPasswordConfigured / 重灌驗證密碼時的
// REST 呼叫才有辦法通過「已登入才能讀寫」的 Firebase 規則。
// ============================================================
function ensureGoogleSignedIn(win) {
  return new Promise((resolve, reject) => {
    debugLog("ensureGoogleSignedIn：送出 boot:need-google-signin");
    win.webContents.send("boot:need-google-signin");

    function registerHandler() {
      ipcMain.handleOnce("boot:google-signin", async () => {
        debugLog("收到 renderer 呼叫 boot:google-signin（使用者按了登入按鈕）");
        try {
          const { idToken: googleIdToken } = await doGoogleOAuthLogin();
          shopFirebaseIdToken = await exchangeGoogleIdTokenForFirebaseIdToken(
            config.shopFirebaseConfig,
            googleIdToken
          );
          debugLog("Google 登入 + Firebase idToken 交換成功");
          resolve();
          return { ok: true };
        } catch (err) {
          debugLog(`Google 登入流程失敗：${err.message}`);
          registerHandler();
          return { ok: false, error: err.message };
        }
      });
    }
    registerHandler();
  });
}

// ============================================================
// 三、忘記密碼驗證碼信件（白名單查詢 + 驗證碼產生/驗證 + 寄信，
// 全部搬到 motosync-reset-backend，exe 本身不持有 Gmail 帳密、
// 不持有白名單、甚至不知道驗證碼本身，只保管一個伺服器簽章過的
// token，驗證時把 token 跟使用者輸入的碼一起送回後端比對。
// 對應 https://github.com/yonghong0333-ops/motosync-reset-backend
// 的 api/send-reset-code.js 與 api/verify-reset-code.js）
// ============================================================

function callResetBackend(pathname, payload) {
  return new Promise((resolve, reject) => {
    let backendUrl;
    try {
      backendUrl = new URL(pathname, config.resetBackend.url);
    } catch (e) {
      reject(new Error("resetBackend.url 設定不正確：" + e.message));
      return;
    }

    const postData = JSON.stringify(payload);
    const req = https.request(
      {
        hostname: backendUrl.hostname,
        path: backendUrl.pathname + backendUrl.search,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(postData),
          "x-api-key": config.resetBackend.apiKey,
        },
      },
      (res) => {
        let body = "";
        res.on("data", (chunk) => (body += chunk));
        res.on("end", () => {
          try {
            const json = body ? JSON.parse(body) : {};
            resolve({ statusCode: res.statusCode, json });
          } catch (e) {
            reject(new Error("後端回應格式錯誤：" + e.message));
          }
        });
      }
    );
    req.on("error", reject);
    req.write(postData);
    req.end();
  });
}

// 這次密碼重設流程拿到的 token（簽章字串，碼本身包在裡面，exe 看不懂
// 也不需要看懂），驗證時要跟使用者輸入的碼一起送回後端。
let pendingResetToken = null;

ipcMain.handle("send-password-reset-code", async (event, recipientEmail, purpose) => {
  const normalizedRecipient = String(recipientEmail || "").trim().toLowerCase();
  pendingResetToken = null;

  try {
    const { statusCode, json: result } = await callResetBackend("/api/send-reset-code", {
      email: normalizedRecipient,
      purpose: purpose || "reset",
      // 各分店自己的 Firebase Realtime Database 網址，後端會去查
      // {firebaseDbUrl}/appSettings/allowedResetEmails.json 這個白名單
      // 節點，判斷這個信箱能不能收驗證碼。
      firebaseDbUrl: config.shopFirebaseConfig.databaseURL,
    });

    if (statusCode !== 200 || !result || result.ok !== true) {
      return { ok: false, error: (result && result.error) || `send_failed(${statusCode})` };
    }

    pendingResetToken = result.token;
    return { ok: true, letterOptions: result.letterOptions };
  } catch (err) {
    console.error("寄送驗證碼失敗：", err);
    pendingResetToken = null;
    return { ok: false, error: err.message };
  }
});

ipcMain.handle("verify-password-reset-code", async (event, inputCode) => {
  if (!pendingResetToken) return { ok: false, reason: "no_code" };

  try {
    const { statusCode, json: result } = await callResetBackend("/api/verify-reset-code", {
      token: pendingResetToken,
      code: String(inputCode || "").trim().toUpperCase(),
    });

    if (statusCode !== 200 || !result) {
      return { ok: false, reason: "verify_failed" };
    }
    // 不論成功、失敗（碼錯、過期、被竄改）都消耗掉這個 token，
    // 跟原本「本機比對完就清掉」的行為一致，避免同一個 token 被
    // 一直拿去猜碼。
    pendingResetToken = null;
    if (result.ok === true) return { ok: true };
    return { ok: false, reason: result.reason || "wrong" };
  } catch (err) {
    console.error("驗證驗證碼失敗：", err);
    pendingResetToken = null;
    return { ok: false, reason: "verify_failed" };
  }
});

// ============================================================
// 四、更新系統 IPC（對應設計文件 七、F12 頁面 + 六、密碼保護節點）
// ============================================================

ipcMain.handle("update:get-current-version", () => {
  return { version: currentAppVersion };
});

// 不用密碼：單純查詢有沒有新版本
ipcMain.handle("update:check", async () => {
  try {
    const latest = await engine.fetchLatestVersion();
    const release = await engine.fetchReleaseJson(latest);
    return {
      ok: true,
      currentVersion: currentAppVersion,
      latestVersion: latest,
      hasUpdate: latest !== currentAppVersion,
      title: release.title || "",
      icon: release.icon || null,
      changelog: release.changelog || "",
      forceUpdate: !!release.forceUpdate,
      sizeBytes: release.sizeBytes || null,
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// 節點 1：按「開始更新」→ 密碼 → 觸發下載
ipcMain.handle("update:start-download", async (event, { password, version }) => {
  const auth = await verifyBossPassword(config.shopFirebaseConfig, password, shopFirebaseIdToken);
  if (!auth.ok) return { ok: false, error: "password_" + auth.reason };

  try {
    const release = await engine.fetchReleaseJson(version);
    const zipPath = await engine.downloadRelease(release, (percent, received, total) => {
      if (mainWindow) {
        mainWindow.webContents.send("update:download-progress", { percent, received, total });
      }
    });
    return { ok: true, zipPath, release };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// 節點 2：按「立即安裝」→ 密碼 → 鎖畫面安裝流程（解壓/驗證/rename）
ipcMain.handle("update:install", async (event, { password, version, zipPath }) => {
  const auth = await verifyBossPassword(config.shopFirebaseConfig, password, shopFirebaseIdToken);
  if (!auth.ok) return { ok: false, error: "password_" + auth.reason };

  try {
    const release = await engine.fetchReleaseJson(version);
    const newDir = await engine.installToNewFolder(release, zipPath);
    const previousVersion = currentAppVersion;
    engine.switchToVersion(version, { previousVersion });

    // 切換完就重啟整個程式，下次開機會直接載入新版本並做啟動驗證。
    setTimeout(() => {
      app.relaunch();
      app.exit(0);
    }, 300);

    return { ok: true, newDir };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// 節點 3：重灌時選擇要安裝「先前系統」還是「最新系統」→ 密碼
ipcMain.handle("update:reinstall-choose", async (event, { password, choice }) => {
  // choice: "previous" | "latest"
  const auth = await verifyBossPassword(config.shopFirebaseConfig, password, shopFirebaseIdToken);
  if (!auth.ok) return { ok: false, error: "password_" + auth.reason };
  return { ok: true };
});

// 「清除所有設定內容（原廠設定）」的最後一步：把本機這個 versions 資料夾
// （所有從 GitHub 下載回來的版本安裝包 .downloads、已解壓縮的 app-vX.X.X
// 資料夾、以及版本 marker 檔 current-version.json）整個砍掉。
//
// 密碼／信箱驗證碼已經在 renderer.js 的 confirmDangerDelete() 裡驗證過
// 才會呼叫到這裡，這裡不再重複要求密碼（跟 local-cache-clear 同一個模式）。
//
// 砍完之後 marker 也一起消失，下次開機 decideBootPlan() 會讀不到本機
// marker，自動走「重灌」流程重新從雲端查授權、抓最新版——等於「軟體
// 邏輯層」也回到跟全新安裝一樣的狀態。因為目前這次執行期間的程式碼就是
// 從被刪掉的資料夾裡讀出來的，刪完必須馬上重啟，不能留在原本畫面上
// 繼續動作，所以這裡砍完立刻 relaunch。
ipcMain.handle("factory-reset-clear-versions", async () => {
  try {
    if (fs.existsSync(VERSIONS_DIR)) {
      fs.rmSync(VERSIONS_DIR, { recursive: true, force: true });
    }
    return { ok: true };
  } catch (err) {
    console.error("清除本機 versions 資料夾失敗：", err);
    return { ok: false, error: err.message };
  }
});

// 給「清除所有設定內容」砍完 versions 資料夾之後用：整個 app 重開，
// 不帶密碼檢查（呼叫這裡之前，renderer 那邊已經驗證過密碼＋信箱驗證碼）。
// 跟 update:install 成功後重啟的寫法一樣。
ipcMain.handle("app:relaunch", () => {
  setTimeout(() => {
    app.relaunch();
    app.exit(0);
  }, 300);
  return true;
});

module.exports.__engine = engine; // 給下面的開機流程使用

// ============================================================
// 五、開機流程：決定要載入哪個版本（對應設計文件 三、八）
// ============================================================

async function decideBootPlan() {
  const marker = engine.readMarker();
  const localDir = engine.getCurrentVersionDir();

  if (marker && localDir) {
    // 正常開機：本機已經有可以用的版本，直接載入，不用等網路。
    return { kind: "normal", version: marker.currentVersion };
  }

  // 沒有本機 marker（第一次安裝，或重灌把 userData 也清掉了）：
  // 查雲端 licenses/{key} 決定是「全新開店」還是「重灌」。
  let licenseRecord = null;
  try {
    licenseRecord = await engine.fetchLicenseRecord(shopFirebaseIdToken);
  } catch (err) {
    return { kind: "error", error: `無法連線到更新伺服器查詢授權狀態：${err.message}` };
  }

  if (!licenseRecord || !licenseRecord.currentVersion) {
    // 全新開店：直接抓最新版，走原廠設定流程，不用密碼
    return { kind: "fresh-install" };
  }

  // 重灌情境：本機找不到任何版本，但雲端記得這把金鑰之前裝到哪一版
  return {
    kind: "reinstall",
    previousVersion: licenseRecord.currentVersion,
  };
}

async function performFreshInstallOrUpdate(version, { onProgress } = {}) {
  const release = await engine.fetchReleaseJson(version);
  const zipPath = await engine.downloadRelease(release, onProgress);
  const previousVersion = currentAppVersion;
  await engine.installToNewFolder(release, zipPath);
  engine.switchToVersion(version, { previousVersion });
}

// 原則六：每次開機比對本機版本 vs 雲端版本，自我校正
async function reconcileVersionWithCloud() {
  try {
    const licenseRecord = await engine.fetchLicenseRecord(shopFirebaseIdToken);
    const cloudVersion = licenseRecord && licenseRecord.currentVersion;
    if (!cloudVersion) return; // 雲端還沒有紀錄，等這次啟動驗證通過再寫

    if (currentAppVersion === cloudVersion) return; // 一致，正常

    if (isVersionLess(currentAppVersion, cloudVersion)) {
      // 本機 < 雲端（例如重灌用了舊安裝檔）→ 自動觸發補更新
      if (mainWindow) {
        mainWindow.webContents.send("update:auto-triggered", { fromVersion: currentAppVersion, toVersion: cloudVersion });
      }
    } else {
      // 本機 > 雲端 → 寫回雲端
      await engine.reportCurrentVersion(currentAppVersion, shopFirebaseIdToken);
    }
  } catch (err) {
    console.error("版本自我校正檢查失敗：", err.message);
  }
}

function isVersionLess(a, b) {
  if (!a) return true;
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na !== nb) return na < nb;
  }
  return false;
}

// ============================================================
// 六、視窗管理（reproduce 原本 createWindow，但改成讀「目前版本
// 資料夾」而不是固定的 __dirname，preload 也改成 bootloader 自己的，
// 由 bootloader preload 內部再去載入該版本自己的 preload.js）
// ============================================================

function startLocalServer(rootDir) {
  return new Promise((resolve) => {
    const MIME = {
      ".html": "text/html; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".json": "application/json; charset=utf-8",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".svg": "image/svg+xml",
      ".ico": "image/x-icon",
    };
    const server = http.createServer((req, res) => {
      let reqPath = decodeURIComponent((req.url || "/").split("?")[0]);
      if (reqPath === "/") reqPath = "/index.html";
      const filePath = path.join(rootDir, reqPath);
      if (!filePath.startsWith(rootDir)) {
        res.writeHead(403);
        res.end("Forbidden");
        return;
      }
      fs.readFile(filePath, (err, data) => {
        if (err) {
          res.writeHead(404);
          res.end("Not found");
          return;
        }
        const ext = path.extname(filePath).toLowerCase();
        res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
        res.end(data);
      });
    });
    server.listen(0, "127.0.0.1", () => resolve(server));
  });
}

async function loadAppVersionIntoWindow(version) {
  const appDir = engine.versionDir(version);
  currentAppDir = appDir;
  currentAppVersion = version;

  const server = await startLocalServer(appDir);
  const port = server.address().port;

  if (!mainWindow) {
    mainWindow = new BrowserWindow({
      width: 1140,
      height: 810,
      useContentSize: true,
      minWidth: 1000,
      minHeight: 700,
      resizable: false,
      autoHideMenuBar: true,
      icon: path.join(__dirname, "build", "icon.ico"),
      show: false,
      webPreferences: {
        preload: path.join(__dirname, "preload.js"),
        contextIsolation: true,
        nodeIntegration: false,
        additionalArguments: [`--motosync-app-preload=${path.join(appDir, "preload.js")}`],
      },
    });

    // 同上一個原因：用 appWindow 記住「這一個」視窗物件本身，避免
    // 前一個視窗（例如 boot 流程的選擇畫面）延遲觸發的 closed 事件
    // 把這個新建的視窗參照誤清成 null。
    const appWindow = mainWindow;
    appWindow.on("closed", () => {
      if (mainWindow === appWindow) mainWindow = null;
    });

    let isQuitConfirmed = false;
    let awaitingQuitConfirm = false;
    mainWindow.on("close", (event) => {
      debugLog(`close event fired. isQuitConfirmed=${isQuitConfirmed} skipCloseConfirmDialog=${skipCloseConfirmDialog}`);
      if (isQuitConfirmed) return;
      if (skipCloseConfirmDialog) {
        isQuitConfirmed = true;
        return;
      }
      event.preventDefault();

      if (awaitingQuitConfirm) return; // 已經跳出來了，等使用者按按鈕，不要重複觸發

      awaitingQuitConfirm = true;
      debugLog("sending motosync:show-quit-confirm to renderer");
      mainWindow.webContents.send("motosync:show-quit-confirm");

      ipcMain.once("quit-confirm-response", (_event, confirmed) => {
        debugLog(`quit-confirm-response received: confirmed=${confirmed}`);
        awaitingQuitConfirm = false;
        if (confirmed) {
          isQuitConfirmed = true;
          mainWindow.close();
        }
      });
    });

    mainWindow.webContents.setWindowOpenHandler(() => ({ action: "allow" }));
    mainWindow.webContents.on("did-create-window", (childWindow) => {
      childWindow.webContents.setUserAgent(CHROME_USER_AGENT);
    });
  }

  mainWindow.webContents.setUserAgent(CHROME_USER_AGENT);
  mainWindow.on("closed", () => server.close());

  // 把該版本的 main.js 掛進來（掛載它自己的業務 IPC handlers）。
  // 一定要在視窗建立「之後」才呼叫，因為它裡面有些 handler
  // （例如另存新檔對話框）一開始就會讀取目前的視窗物件。
  //
  // 這裡包 try/catch 是有事故經驗的：main.js 裡 require 到缺少的
  // 套件（例如上次的 'docx'）、或 main.js 本身結構有問題，都會讓
  // require() 或 registerApp() 同步丟出例外。這種例外原本會一路
  // 往上炸到最外層 app.whenReady().then(...).catch(...)，只顯示
  // 一個「無法啟動」的錯誤框，完全不會嘗試退回舊版本——即使有
  // 好好運作的舊版本可以退，也不會自動救援，只能靠人工去分店電腦
  // 手動清資料夾。改成在這裡直接抓，觸發跟啟動驗證逾時一樣的
  // triggerRollback()，能退就自動退回、重新啟動，不用人工介入。
  let registerApp;
  try {
    registerApp = require(path.join(appDir, "main.js"));
  } catch (err) {
    console.error(`載入版本 ${version} 的 main.js 失敗：`, err);
    debugLog(`載入版本 ${version} 的 main.js 失敗，觸發自動退回：${err.message}`);
    triggerRollback();
    return;
  }

  if (typeof registerApp === "function") {
    try {
      registerApp({
        ipcMain,
        app,
        shell,
        dialog,
        getMainWindow: () => mainWindow,
        appDir,
        shopFirebaseConfig: config.shopFirebaseConfig,
      });
    } catch (err) {
      console.error(`版本 ${version} 的 main.js 初始化時拋出例外：`, err);
      debugLog(`版本 ${version} 初始化失敗，觸發自動退回：${err.message}`);
      triggerRollback();
      return;
    }
  }

  armStartupVerification(version);
  mainWindow.loadURL(`http://localhost:${port}/index.html`);
  const windowToShow = mainWindow;
  windowToShow.once("ready-to-show", () => {
    if (!windowToShow.isDestroyed()) windowToShow.show();
  });
}

// ------------------------------------------------------------
// 原則五：啟動驗證。版本切換完 relaunch 進新版本後，等該版本的
// renderer 呼叫 update:startup-verify-ping 表示「畫面渲染、Firebase
// 連線、license 讀取都正常」，才算真的成功；逾時或載入失敗就自動
// 退回舊版本並再次 relaunch。
// ------------------------------------------------------------

function armStartupVerification(version) {
  const marker = engine.readMarker();
  if (!marker || marker.currentVersion !== version || marker.startupVerified) {
    return; // 這個版本之前已經驗證通過過，不用重驗
  }

  if (startupVerifyTimer) clearTimeout(startupVerifyTimer);
  startupVerifyTimer = setTimeout(() => {
    console.error(`版本 ${version} 啟動驗證逾時，自動退回舊版本`);
    triggerRollback();
  }, 30000);

  const failHandler = () => {
    clearTimeout(startupVerifyTimer);
    console.error(`版本 ${version} 載入失敗，自動退回舊版本`);
    triggerRollback();
  };
  mainWindow.webContents.once("did-fail-load", failHandler);
}

function triggerRollback() {
  try {
    engine.rollbackToPrevious();
  } catch (err) {
    dialog.showErrorBox(
      "更新失敗且無法退回舊版本",
      `新版本啟動驗證失敗，且${err.message}。請聯絡系統管理者。`
    );
    return;
  }
  app.relaunch();
  app.exit(0);
}

ipcMain.handle("update:startup-verify-ping", () => {
  if (startupVerifyTimer) {
    clearTimeout(startupVerifyTimer);
    startupVerifyTimer = null;
  }
  const marker = engine.readMarker();
  if (marker && marker.currentVersion === currentAppVersion && !marker.startupVerified) {
    engine.markStartupVerified(currentAppVersion);
    if (marker.previousVersion) {
      engine.archiveOldVersion(marker.previousVersion);
    }
    engine.reportCurrentVersion(currentAppVersion, shopFirebaseIdToken).catch((err) => {
      console.error("回報版本到雲端失敗：", err.message);
    });
  }
  // 驗證通過後，順便做一次雲端版本自我校正
  reconcileVersionWithCloud();
  return { ok: true };
});

ipcMain.handle("quit-app", () => {
  skipCloseConfirmDialog = true;
  app.quit();
});

// 暫時的除錯用：preload.js 那邊執行到關鍵步驟時會送這個訊息過來，
// 統一寫進同一份 log 檔，方便排查「關閉確認畫面沒跳出來」的問題。
ipcMain.on("motosync:debug-log", (_event, msg) => {
  debugLog(`[renderer] ${msg}`);
});

// ============================================================
// 六之一、原廠系統初次設定：強制設定老闆密碼
//
// 分店的 Firebase 裡如果還沒有 appSettings/bossPasswordHash（全新
// 分店、第一次安裝），就先擋在 boot.html 上叫老闆設一組密碼，
// 設定完才繼續走正常開機流程（版本檢查/安裝/重灌）。
// 這裡只負責「擋住 + 收密碼 + 寫入」，不管後續版本邏輯。
// ============================================================
function ensureBossPasswordConfigured(win) {
  return new Promise(async (resolve, reject) => {
    let alreadySet;
    try {
      alreadySet = await hasBossPassword(config.shopFirebaseConfig, shopFirebaseIdToken);
    } catch (err) {
      reject(err);
      return;
    }

    if (alreadySet) {
      resolve();
      return;
    }

    win.webContents.send("boot:need-boss-password-setup");

    // 每次送出失敗（密碼不一致 / 寫入失敗）都要重新註冊一次
    // handleOnce，不然使用者在畫面上重試第二次會找不到 handler
    function registerHandler() {
      ipcMain.handleOnce("boot:set-boss-password", async (event, { password, confirmPassword }) => {
        if (String(password || "") !== String(confirmPassword || "")) {
          registerHandler();
          return { ok: false, error: "password_mismatch" };
        }

        const result = await setBossPassword(config.shopFirebaseConfig, password, shopFirebaseIdToken);
        if (!result.ok) {
          registerHandler();
          return result;
        }

        resolve();
        return { ok: true };
      });
    }
    registerHandler();
  });
}

// ============================================================
// 七、開機主流程
// ============================================================
async function boot() {
  debugLog("boot() 開始");
  // 先開一個空白視窗顯示開機畫面（boot.html），決定好版本以後再換掉內容
  mainWindow = new BrowserWindow({
    width: 1140,
    height: 810,
    useContentSize: true,
    minWidth: 1000,
    minHeight: 700,
    resizable: false,
    autoHideMenuBar: true,
    icon: path.join(__dirname, "build", "icon.ico"),
    webPreferences: {
      preload: path.join(__dirname, "boot-preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  // 用 bootWindow 記住「這一個」視窗物件本身，"closed" 事件是非同步
  // 觸發的（呼叫 .close() 之後不會馬上發生），如果這裡直接清空外層
  // 共用的 mainWindow 變數，遇到「先 close() 這個視窗、緊接著就建立
  // 下一個視窗」的情境（reinstall 選擇流程就是這樣），舊視窗延遲觸發
  // 的 closed 事件有機會在新視窗建立「之後」才發生，把已經指向新視窗
  // 的 mainWindow 誤清成 null——導致新視窗稍後觸發 ready-to-show 時
  // 讀到 mainWindow.show() 的 mainWindow 是 null 而整個崩潰。這裡先
  // 判斷「現在的 mainWindow 是不是還是我自己」，是才清空。
  const bootWindow = mainWindow;
  bootWindow.on("closed", () => {
    if (mainWindow === bootWindow) mainWindow = null;
  });

  // 除錯用：preload.js 如果本身執行時丟例外（例如打包後路徑不對、
  // require 失敗等），Electron 不會讓整個 app 崩潰，也不會有任何
  // 提示，畫面只會停在 boot.html 的靜態內容不動——之前排查「卡在
  // 正在檢查系統版本」的問題一直找不到原因，就是因為沒有攔截這個
  // preload-error 事件，所以完全不知道 preload 到底有沒有跑起來。
  mainWindow.webContents.on("preload-error", (_event, preloadPath, error) => {
    debugLog(`❌ preload 載入失敗！preloadPath=${preloadPath}，error=${error && error.stack ? error.stack : error}`);
  });

  // 除錯用：boot.html 的 <script> 裡任何沒被 catch 到的例外（例如
  // window.bootAPI 是 undefined 導致的 TypeError），瀏覽器層級的
  // console.error 都會經過這個事件送到 main process，一併寫進同一份
  // log，這樣就算 preload 本身沒問題、是 boot.html 的 script 中途
  // 掛掉，也查得到原因。
  mainWindow.webContents.on("console-message", (_event, level, message, line, sourceId) => {
    if (level >= 2) {
      debugLog(`[renderer console] level=${level} ${sourceId}:${line} ${message}`);
    }
  });

  await mainWindow.loadFile(path.join(__dirname, "boot.html"));
  debugLog("boot.html 載入完成（did-finish-load）");

  try {
    debugLog("開始 ensureGoogleSignedIn");
    await ensureGoogleSignedIn(mainWindow);
    debugLog("ensureGoogleSignedIn 完成");
  } catch (err) {
    debugLog(`ensureGoogleSignedIn 失敗：${err.message}`);
    dialog.showErrorBox("無法啟動", `Google 登入失敗：${err.message}`);
    app.quit();
    return;
  }
  if (!mainWindow) return; // 使用者在登入畫面關掉視窗

  try {
    debugLog("開始 ensureBossPasswordConfigured");
    await ensureBossPasswordConfigured(mainWindow);
    debugLog("ensureBossPasswordConfigured 完成");
  } catch (err) {
    debugLog(`ensureBossPasswordConfigured 失敗：${err.message}`);
    dialog.showErrorBox("無法啟動", `老闆密碼初始設定失敗：${err.message}`);
    app.quit();
    return;
  }
  if (!mainWindow) return; // 使用者在設定密碼畫面關掉視窗

  debugLog("開始 decideBootPlan");
  const plan = await decideBootPlan();
  debugLog(`decideBootPlan 結果：${JSON.stringify(plan)}`);

  if (plan.kind === "error") {
    debugLog(`plan.kind === "error"：${plan.error}`);
    dialog.showErrorBox("無法啟動", plan.error);
    app.quit();
    return;
  }

  if (plan.kind === "normal") {
    debugLog(`plan.kind === "normal"，version=${plan.version}，開始 loadAppVersionIntoWindow`);
    mainWindow.close();
    mainWindow = null;
    await loadAppVersionIntoWindow(plan.version);
    debugLog("loadAppVersionIntoWindow 完成（normal）");
    reconcileVersionWithCloud();
    return;
  }

  if (plan.kind === "fresh-install") {
    debugLog("plan.kind === \"fresh-install\"，開始 fetchLatestVersion");
    const latest = await engine.fetchLatestVersion();
    debugLog(`fetchLatestVersion 完成：${latest}，開始 performFreshInstallOrUpdate`);
    await performFreshInstallOrUpdate(latest, {
      onProgress: (percent) => mainWindow && mainWindow.webContents.send("boot:progress", { percent }),
    });
    debugLog("performFreshInstallOrUpdate 完成，開始 loadAppVersionIntoWindow");
    mainWindow.close();
    mainWindow = null;
    await loadAppVersionIntoWindow(latest);
    debugLog("loadAppVersionIntoWindow 完成（fresh-install）");
    return;
  }

  if (plan.kind === "reinstall") {
    // 顯示「先前系統 / 最新系統」選擇畫面，交給 boot.html 處理，
    // boot.html 會呼叫 bootAPI.reinstallChoose(password, choice)
    const latest = await engine.fetchLatestVersion();
    mainWindow.webContents.send("boot:need-reinstall-choice", {
      previousVersion: plan.previousVersion,
      latestVersion: latest,
    });

    ipcMain.handleOnce("boot:reinstall-choose", async (event, { password, choice }) => {
      const auth = await verifyBossPassword(config.shopFirebaseConfig, password, shopFirebaseIdToken);
      if (!auth.ok) return { ok: false, error: "password_" + auth.reason };

      const version = choice === "latest" ? latest : plan.previousVersion;
      try {
        await performFreshInstallOrUpdate(version, {
          onProgress: (percent) => mainWindow && mainWindow.webContents.send("boot:progress", { percent }),
        });
        mainWindow.close();
        mainWindow = null;
        await loadAppVersionIntoWindow(version);
        return { ok: true };
      } catch (err) {
        return { ok: false, error: err.message };
      }
    });
  }
}

app.whenReady().then(() => {
  boot().catch((err) => {
    console.error("開機流程發生未預期的錯誤：", err);
    dialog.showErrorBox("無法啟動", `開機流程發生未預期的錯誤：${err.message}`);
  });
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      boot().catch((err) => {
        console.error("開機流程發生未預期的錯誤：", err);
        dialog.showErrorBox("無法啟動", `開機流程發生未預期的錯誤：${err.message}`);
      });
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
