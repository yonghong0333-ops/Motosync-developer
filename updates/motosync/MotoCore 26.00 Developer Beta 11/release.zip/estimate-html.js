// ============================================================
// 估價單 HTML 版本 —— 跟 estimate-template.js（Word 版）走同一份資料、
// 同樣的版面順序（標題 → 姓名/備註資訊 → 進場/報價日期 → 品項總表 →
// 十條契約條款），只是輸出成一個獨立的 HTML 頁面。
//
// 用途：交給隱藏的 BrowserWindow 載入後，用 Chromium 內建的
// webContents.printToPDF()／webContents.print() 直接產生 PDF 或送出
// 系統列印，不需要額外安裝 LibreOffice/Word 之類的外部程式做轉檔。
// ============================================================

const { toChineseCapitalAmount, CLAUSES } = require("./estimate-template");

function esc(text) {
  return String(text == null ? "" : text).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
}

function labelValue(label, value) {
  return value ? `${label}：${esc(value)}` : label;
}

/**
 * data 欄位跟 estimate-template.js 的 buildEstimateDocxBuffer 完全一樣，
 * 方便前端組同一包 payload 就能同時支援 Word／PDF／列印三種輸出。
 */
function buildEstimateHtml(data = {}) {
  const items = Array.isArray(data.items) ? data.items.slice(0, 30) : [];

  const total =
    data.totalAmount != null
      ? Number(data.totalAmount) || 0
      : items.reduce((sum, it) => sum + (Number(it.amount) || 0), 0);
  const hasAnyAmount = data.totalAmount != null || items.length > 0;

  const [entryY, entryM, entryD] = (data.entryDate || "").split("-");
  const [quoteY, quoteM, quoteD] = (data.quoteDate || "").split("-");

  const dateLine = `進場日期：${
    entryY ? `${entryY}年${entryM}月${entryD}日` : "　　年　　月　　日"
  }　　　　　　　　　　報價日期：${
    quoteY ? `${quoteY}年${quoteM}月${quoteD}日` : "　　年　　月　　日"
  }`;

  const totalText = hasAnyAmount
    ? `合計新臺幣　${toChineseCapitalAmount(total)}`
    : "合計新臺幣　　拾　　萬　　仟　　佰　　十　元整";

  // 15 列一組，左右各排一組（跟 docx 版的排列方式一樣）
  let itemRowsHtml = "";
  for (let i = 0; i < 15; i++) {
    const left = items[i];
    const right = items[i + 15];
    itemRowsHtml += `
      <tr>
        <td class="c">${i + 1}</td>
        <td class="l" colspan="2">${esc(left ? left.name : "")}</td>
        <td class="r">${left && left.amount != null ? esc(left.amount) : ""}</td>
        <td class="c">${i + 16}</td>
        <td class="l" colspan="3">${esc(right ? right.name : "")}</td>
        <td class="r">${right && right.amount != null ? esc(right.amount) : ""}</td>
      </tr>`;
  }

  const clausesHtml = CLAUSES.map((t) => `<p class="clause">${esc(t)}</p>`).join("\n");

  const mileageText =
    data.mileage != null && data.mileage !== "" ? `${data.mileage} km` : "";

  return `<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="UTF-8" />
<title>估價單</title>
<style>
  @page { size: A4; margin: 12mm; }
  * { box-sizing: border-box; }
  body {
    font-family: "標楷體", "DFKai-SB", "BiauKai", serif;
    color: #000;
    margin: 0;
    font-size: 11pt;
  }
  .title-shop { text-align: center; font-size: 22pt; font-weight: bold; letter-spacing: 6px; margin: 2mm 0; }
  .title-doc { text-align: center; font-size: 20pt; font-weight: bold; letter-spacing: 10px; margin: 2mm 0 4mm; }
  table { width: 100%; border-collapse: collapse; table-layout: fixed; }
  .info-table td, .item-table td, .item-table th {
    border: 1px solid #000;
    padding: 1.2mm 1.5mm;
    vertical-align: middle;
    font-size: 10.5pt;
  }
  .info-table { margin-bottom: 3mm; }
  .item-table { margin-top: 1mm; }
  .item-table th { text-align: center; font-weight: bold; }
  .item-table td.c { text-align: center; }
  .item-table td.l { text-align: left; }
  .item-table td.r { text-align: right; }
  .date-line { font-weight: bold; margin: 2mm 0 2mm; font-size: 10.5pt; }
  .sign-row td { font-weight: bold; }
  .sign-row .sign-left { border-right: none; }
  .sign-row .sign-right { border-left: none; text-align: right; white-space: nowrap; }
  .clause { margin: 0 0 0.6mm; font-size: 8.5pt; line-height: 1.35; }
</style>
</head>
<body>
  <div class="title-shop">永　鑫　車　業</div>
  <div class="title-doc">估　　價　　單</div>

  <table class="info-table">
    <tr>
      <td style="width:33%">${labelValue("姓名", data.customerName)}</td>
      <td style="width:34%">身分證號</td>
      <td style="width:33%">${labelValue("電話", data.phone)}</td>
    </tr>
    <tr>
      <td>${labelValue("車牌", data.plate)}</td>
      <td>${labelValue("里程", mileageText)}</td>
      <td>型式</td>
    </tr>
    <tr>
      <td colspan="3">${labelValue("備註", data.notes)}</td>
    </tr>
  </table>

  <div class="date-line">${dateLine}</div>

  <table class="item-table">
    <colgroup>
      <col style="width:6.7%"><col style="width:25.8%"><col style="width:2.7%">
      <col style="width:14.9%"><col style="width:6.8%"><col style="width:4.1%">
      <col style="width:19.2%"><col style="width:5.2%"><col style="width:14.6%">
    </colgroup>
    <tr>
      <th>序號</th><th colspan="2">品名</th><th>金額</th>
      <th>序號</th><th colspan="3">品名</th><th>金額</th>
    </tr>
    ${itemRowsHtml}
    <tr>
      <td colspan="6" class="l">${esc(totalText)}</td>
      <td colspan="1" class="l">定金　　　　元</td>
      <td colspan="2" class="l">餘款　　　　元</td>
    </tr>
    <tr>
      <td colspan="2" class="l">借用車輛：</td>
      <td colspan="7" class="l">自　　年　　月　　日 起至　　年　　月　　日止</td>
    </tr>
    <tr class="sign-row">
      <td colspan="6" class="l sign-left">已詳讀且同意所有內容簽章：</td>
      <td colspan="3" class="sign-right">（本單不含5％營業稅）</td>
    </tr>
  </table>

  <div style="margin-top:2mm">
    ${clausesHtml}
  </div>
</body>
</html>`;
}

module.exports = { buildEstimateHtml };
