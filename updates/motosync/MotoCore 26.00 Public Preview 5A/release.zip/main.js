// ============================================================
// 永鑫機車系統 —— 軟體邏輯層（跑在 MotoSync bootloader 裡的「掛件」）
//
// 這支 main.js 不是獨立的 Electron 進入點，是被 motosync-bootloader
// 的 main.js 用 require() 載入、再呼叫這裡匯出的函式，把底下這些
// ipcMain handler 註冊進 bootloader 已經開好的那個視窗裡。
//
// 依照三層分類原則，以下這些邏輯已經搬去 bootloader、不在這支檔案
// 裡（不要在這裡重複註冊，Electron 同一個 channel 註冊兩次 handler
// 會直接丟例外，整個開機流程會壞掉）：
//   - Google 登入（google-login）
//   - 離線授權金鑰驗證（check-app-license / offline-login）
//   - 忘記密碼驗證碼（send-password-reset-code / verify-password-reset-code，
//     現在改打 motosync-reset-backend，不再是這支檔案裡的 nodemailer）
//   - 視窗建立、關閉確認對話框、User-Agent 偽裝、本機靜態檔案伺服器
//     （bootloader 的 loadAppVersionIntoWindow() 已經處理）
//   - 「關閉系統」（quit-app）
//
// 這支檔案只保留「業務邏輯」本身：離線佇列/本機快取、舊系統資料匯入、
// 估價單產生（docx/PDF/列印）、Wi-Fi／電量／網路診斷推播。
// ============================================================

const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const https = require("https");
const { exec } = require("child_process");
const { Worker } = require("worker_threads");
const { BrowserWindow } = require("electron"); // 只用來開估價單 PDF/列印用的隱藏視窗
const { buildEstimateDocxBuffer } = require("./estimate-template");
const { buildEstimateHtml } = require("./estimate-html");

module.exports = function registerApp({ ipcMain, app, shell, dialog, getMainWindow, appDir, shopFirebaseConfig, shopSettings, licenseKey }) {
  // ============================================================
  // 🔑 分店 Firebase 金鑰只活在 bootloader 的 config.js 裡（「外殼」），
  // 這支「軟體邏輯層」的 main.js 由 bootloader 用 require() 動態載入，
  // 整包（含 renderer.js）都會被 OTA 更新覆蓋、甚至上傳/散佈出去，
  // 絕對不能把金鑰寫死在這裡面。bootloader 呼叫 registerApp() 時已經把
  // shopFirebaseConfig 當參數傳進來了，這裡單純轉一手開放給 renderer.js
  // 用 IPC 拿，renderer.js 不再自己 hardcode 一份。
  // ============================================================
  ipcMain.handle("get-shop-firebase-config", () => shopFirebaseConfig);

  // ============================================================
  // 🏪 同樣道理：Google 登入白名單信箱、估價單抬頭店名，也是「這家店
  // 專屬」的東西，不能寫死在會被整份 OTA 散佈出去的 renderer.js /
  // estimate-template.js / estimate-html.js 裡（不然每家店都會看到同一組
  // 信箱白名單、印出同一個店名）。改成一樣從外殼的 config.js 注入。
  // shopSettings 可能是 undefined（例如舊版外殼還沒加這個參數），這裡給
  // 一個空物件 fallback，避免 renderer.js 那邊直接壞掉。
  // ============================================================
  ipcMain.handle("get-shop-settings", () => shopSettings || {});

  // ============================================================
  // 「關於軟體」頁要顯示的授權金鑰字串：來自外殼 config.js 的
  // licenseKey，透過 bootloader 呼叫 registerApp() 時當參數傳進來
  // （見 main-bootloader.js），這裡單純轉一手開放給 renderer.js 用
  // IPC 拿，同樣不寫死在會被 OTA 覆蓋的檔案裡。
  // ============================================================
  ipcMain.handle("get-license-key", () => licenseKey || "");

  // ============================================================
  // 離線維修紀錄佇列 —— 改存在磁碟的資料夾裡（不再用瀏覽器 localStorage）
  //
  // 位置：%APPDATA%\yongxin-motorcycle-shop\offline-data\pending-repairs.json
  // （每台電腦的實際路徑用 app.getPath("userData") 取得，程式碼裡不用寫死路徑）
  //
  // 這個資料夾/檔案就是真正的「暫存區」：離線時新增的維修紀錄會先寫進這裡，
  // 等偵測到恢復網路連線，才會依序把裡面的紀錄補傳回 Firebase，成功一筆
  // 才從這個檔案裡刪掉一筆，確保就算應用程式重開機、電腦重開機，離線期間
  // 存的資料也不會不見。
  // ============================================================
  // ============================================================
  // 🛡️ 硬碟寫入要「不管電腦怎麼被關掉」都不會壞掉——包含強制關機、拔電源、
  // 應用程式被工作管理員砍掉這種「寫到一半」的情況。
  //
  // 如果直接 fs.writeFileSync(檔案, 新內容)，萬一寫到一半電腦就斷電，
  // 檔案會變成「寫一半」的殘缺 JSON，下次開機讀取會直接解析失敗，等於
  // 把「之前好好的資料」也一起弄壞、整份丟掉。
  //
  // 正確做法是「先寫暫存檔、寫完確認真的落盤、再改名蓋過去正式檔案」：
  // 1. 寫進同一個資料夾底下的 .tmp 暫存檔
  // 2. fsync 強制作業系統把資料真的寫進硬碟（不是只留在系統快取裡）
  // 3. 用「改名」把 .tmp 蓋過正式檔案——改名這個動作本身幾乎是瞬間完成、
  //    不可能寫到一半，所以不管什麼時候斷電，正式檔案永遠只會是「完全
  //    是新的」或「完全還是舊的」，不會有寫一半的中間狀態。
  // ============================================================
  function writeFileAtomic(filePath, content) {
    const tmpPath = filePath + ".tmp";
    const fd = fs.openSync(tmpPath, "w");
    try {
      fs.writeSync(fd, content, 0, "utf8");
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
    fs.renameSync(tmpPath, filePath);
  }

  // ============================================================
  // 🧵 大檔案的硬碟寫入交給獨立的背景執行緒（worker_thread）做，不要佔用
  // main process 自己的事件迴圈——這支 App 所有頁面的 IPC（存檔、列印、
  // 開對話框…）都是靠這個 main process 處理的，如果直接在這裡同步把一大包
  // 資料 JSON.stringify 完再整份寫進硬碟（還要 fsync 等實際落盤完成），
  // main process 這段時間會被整個卡住，導致「其他頁面」當下不管按什麼都
  // 沒反應，看起來就像當掉。
  //
  // 改成丟給一個獨立的背景執行緒做完整個 stringify + 寫檔案的動作，
  // main process 全程保持空閒，可以繼續處理其他頁面同時送過來的請求。
  // 只有「本機硬碟資料快取」這個會隨資料量變大的大檔案才需要這樣處理；
  // 「離線佇列」通常只有幾筆待補傳的維修紀錄，檔案很小，維持原本同步
  // 寫入就好，不用另外開執行緒。
  // ============================================================
  function writeFileAtomicInBackground(filePath, data) {
    return new Promise((resolve, reject) => {
      const workerCode = `
        const { parentPort, workerData } = require("worker_threads");
        const fs = require("fs");
        const { filePath, data } = workerData;
        try {
          const content = JSON.stringify(data);
          const tmpPath = filePath + ".tmp";
          const fd = fs.openSync(tmpPath, "w");
          try {
            fs.writeSync(fd, content, 0, "utf8");
            fs.fsyncSync(fd);
          } finally {
            fs.closeSync(fd);
          }
          fs.renameSync(tmpPath, filePath);
          parentPort.postMessage({ ok: true });
        } catch (err) {
          parentPort.postMessage({ ok: false, error: err.message || String(err) });
        }
      `;
      const worker = new Worker(workerCode, { eval: true, workerData: { filePath, data } });
      worker.once("message", (msg) => {
        worker.terminate();
        if (msg.ok) resolve();
        else reject(new Error(msg.error));
      });
      worker.once("error", (err) => {
        worker.terminate();
        reject(err);
      });
    });
  }

  // 讀取時如果正式檔案壞掉（理論上不該發生，但還是留一手保險），
  // 嘗試讀殘留的 .tmp 檔案救回最後一次寫入的內容。
  function readJsonWithFallback(filePath) {
    if (fs.existsSync(filePath)) {
      try {
        return JSON.parse(fs.readFileSync(filePath, "utf8"));
      } catch (err) {
        console.error(`讀取 ${filePath} 失敗，嘗試從暫存檔救回：`, err);
      }
    }
    const tmpPath = filePath + ".tmp";
    if (fs.existsSync(tmpPath)) {
      try {
        return JSON.parse(fs.readFileSync(tmpPath, "utf8"));
      } catch (err) {
        console.error(`暫存檔 ${tmpPath} 也讀取失敗：`, err);
      }
    }
    return undefined;
  }

  function offlineQueueDir() {
    const dir = path.join(app.getPath("userData"), "offline-data");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return dir;
  }

  ipcMain.handle("open-local-data-folder", () => {
    const dir = offlineQueueDir();
    shell.openPath(dir);
    return dir;
  });

  function offlineQueueFilePath() {
    return path.join(offlineQueueDir(), "pending-repairs.json");
  }

  ipcMain.handle("offline-queue-read", () => {
    const filePath = offlineQueueFilePath();
    const parsed = readJsonWithFallback(filePath);
    if (parsed === undefined) return [];
    return Array.isArray(parsed) ? parsed : [];
  });

  ipcMain.handle("offline-queue-write", (event, queue) => {
    const filePath = offlineQueueFilePath();
    writeFileAtomic(filePath, JSON.stringify(queue, null, 2));
    return true;
  });

  // ============================================================
  // 🗂️ 通用離線寫入佇列（pending-writes.json）
  //
  // 上面的「離線佇列」只涵蓋「新增維修紀錄」這一種操作。實際上系統裡
  // 還有將近 40 個地方會直接寫 Firebase（顧客資料修改、估價單刪除、
  // 車牌變更、商品目錄增刪、庫存出入、系統設定…），這些原本完全沒有
  // 離線保護：沒網路時 Firebase SDK 的 set/update/remove/push 不會
  // 馬上失敗，而是整個卡住等到有網路才會繼續（Realtime Database SDK
  // 的預設行為），使用者會看到畫面卡住轉圈圈；如果這時候使用者把程式
  // 關掉，這筆還沒送出去的資料就會直接遺失，永遠不會補傳。
  //
  // 這裡是同一套「先寫本機硬碟、有網路再自動補傳」精神的通用版本，
  // 存在同一個 offline-data 資料夾底下的 pending-writes.json，
  // 檔案格式是陣列，每一筆是 { opId, kind, path, op, payload, meta,
  // createdAt }。跟 pending-repairs.json 分開存放，兩份佇列互不影響、
  // 各自補傳，就算其中一份檔案壞掉也不會拖累另一份。
  // ============================================================
  function pendingWritesFilePath() {
    return path.join(offlineQueueDir(), "pending-writes.json");
  }

  ipcMain.handle("pending-writes-read", () => {
    const filePath = pendingWritesFilePath();
    const parsed = readJsonWithFallback(filePath);
    if (parsed === undefined) return [];
    return Array.isArray(parsed) ? parsed : [];
  });

  ipcMain.handle("pending-writes-write", (event, queue) => {
    const filePath = pendingWritesFilePath();
    writeFileAtomic(filePath, JSON.stringify(queue, null, 2));
    return true;
  });

  // ============================================================
  // 📴 離線庫存異動佇列（pending-stock-adjustments.json）
  //
  // 庫存扣減／進貨一定要用 runTransaction（讀現在的數字→比較→寫回）
  // 才能保證多台電腦同時異動同一項庫存不會互相蓋掉、算錯，這跟上面
  // pending-writes.json 那種「直接把同一個 set/update/remove/push
  // 操作原封不動再送一次」的補傳方式不一樣——一筆 runTransaction 沒辦法
  // 只靠重送原始 payload 復原，所以獨立存放一份，格式是陣列，每一筆是
  // { opId, itemName, delta, meta, createdAt }（見 renderer.js 的
  // adjustItemStock / queueOfflineStockAdjustment / syncStockDeltaQueue）。
  // 一樣放在同一個 offline-data 資料夾底下，但檔名不同、各自補傳，
  // 互不影響。
  // ============================================================
  function stockDeltaQueueFilePath() {
    return path.join(offlineQueueDir(), "pending-stock-adjustments.json");
  }

  ipcMain.handle("stock-delta-queue-read", () => {
    const filePath = stockDeltaQueueFilePath();
    const parsed = readJsonWithFallback(filePath);
    if (parsed === undefined) return [];
    return Array.isArray(parsed) ? parsed : [];
  });

  ipcMain.handle("stock-delta-queue-write", (event, queue) => {
    const filePath = stockDeltaQueueFilePath();
    writeFileAtomic(filePath, JSON.stringify(queue, null, 2));
    return true;
  });

  // ============================================================
  // 本機硬碟資料快取 —— 把整個「車籍／維修紀錄」資料庫完整存一份在硬碟上。
  //
  // 位置：%APPDATA%\yongxin-motorcycle-shop\offline-data\records-cache.json
  //
  // 用途：跟上面的「離線佇列」不一樣，那個只存「離線時新增、還沒上傳」的
  // 紀錄；這個是把 Firebase 上「已經存在」的完整資料庫鏡像一份到硬碟，
  // 讓這台電腦不管有沒有連過網路查過某筆車籍，只要曾經完整同步過一次，
  // 之後就算突然斷網、甚至換了一顆全新的硬碟重新安裝本程式，只要能再連上
  // 網路完整同步一次，接下來離線時都能照樣查得到資料。
  // 每次成功連上 Firebase 時（登入成功／恢復網路連線），renderer.js 都會
  // 呼叫這裡把最新的完整資料庫存一份下來，覆蓋舊的快取檔案。
  // ============================================================
  function localRecordsCacheFilePath() {
    return path.join(offlineQueueDir(), "records-cache.json");
  }

  ipcMain.handle("local-cache-read", () => {
    const filePath = localRecordsCacheFilePath();
    const parsed = readJsonWithFallback(filePath);
    return parsed === undefined ? null : parsed;
  });

  ipcMain.handle("local-cache-write", async (event, data) => {
    const filePath = localRecordsCacheFilePath();
    // 這份資料是整個車籍／維修紀錄資料庫，可能很大，交給背景執行緒寫，
    // 不要卡住 main process，讓其他頁面的操作（列印、存檔…）可以照常進行。
    await writeFileAtomicInBackground(filePath, data);
    return true;
  });

  ipcMain.handle("local-cache-clear", () => {
    const filePath = localRecordsCacheFilePath();
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    if (fs.existsSync(filePath + ".tmp")) fs.unlinkSync(filePath + ".tmp");
    return true;
  });

  // 「清除資料」流程順便把 Chromium 這個 webContents 的 HTTP 快取／storage
  // 也一起清掉（跟上面那份「車籍資料 JSON 快取檔」是兩回事），確保清除
  // 資料之後不會有殘留的舊畫面資源或殘留的 Firebase Auth session 之類的東西。
  ipcMain.handle("clear-browser-cache", async () => {
    try {
      const win = getMainWindow ? getMainWindow() : null;
      const ses = win && !win.isDestroyed() ? win.webContents.session : require("electron").session.defaultSession;
      await ses.clearCache();
      await ses.clearStorageData();
      return true;
    } catch (err) {
      console.error("清除瀏覽器快取失敗：", err);
      return false;
    }
  });

  ipcMain.handle("local-cache-info", () => {
    const filePath = localRecordsCacheFilePath();
    if (!fs.existsSync(filePath)) return null;
    try {
      const stat = fs.statSync(filePath);
      return { sizeBytes: stat.size, mtime: stat.mtimeMs };
    } catch (err) {
      console.error("讀取本機硬碟資料快取狀態失敗：", err);
      return null;
    }
  });

  // ============================================================
  // 💽 本機硬碟空間：查這台電腦「放程式資料那顆磁碟」的實際總容量／可用空間，
  // 設定頁的「本機空間」用這個數字（跟上面的「硬碟快取檔案大小」不一樣，
  // 那個只是我們自己這份快取檔案的大小；這裡是整顆磁碟的容量）。
  //
  // 優先用 Node 內建的 fs.statfsSync（跨平台、不用另外開子程序），萬一這台
  // 電腦的 Node/Electron 版本不支援，才退回用系統指令（Windows 用 wmic，
  // macOS／Linux 用 df）當備用方案。
  // ============================================================
  ipcMain.handle("get-disk-space", async () => {
    const targetPath = app.getPath("userData");

    try {
      if (typeof fs.statfsSync === "function") {
        const stats = fs.statfsSync(targetPath);
        return {
          totalBytes: stats.blocks * stats.bsize,
          freeBytes: stats.bfree * stats.bsize,
        };
      }
    } catch (err) {
      console.error("fs.statfsSync 查詢磁碟空間失敗，改用系統指令：", err);
    }

    return new Promise((resolve) => {
      if (process.platform === "win32") {
        const driveLetter = path.parse(targetPath).root.replace(/\\$/, ""); // 例如 'C:'
        exec(
          `wmic logicaldisk where "DeviceID='${driveLetter}'" get Size,FreeSpace /format:value`,
          (err, stdout) => {
            if (err) {
              console.error("wmic 查詢磁碟空間失敗：", err);
              resolve(null);
              return;
            }
            const sizeMatch = /Size=(\d+)/.exec(stdout);
            const freeMatch = /FreeSpace=(\d+)/.exec(stdout);
            if (sizeMatch && freeMatch) {
              resolve({
                totalBytes: Number(sizeMatch[1]),
                freeBytes: Number(freeMatch[1]),
              });
            } else {
              resolve(null);
            }
          }
        );
      } else {
        exec(`df -k "${targetPath}"`, (err, stdout) => {
          if (err) {
            console.error("df 查詢磁碟空間失敗：", err);
            resolve(null);
            return;
          }
          const lines = stdout.trim().split("\n");
          const parts = lines[lines.length - 1].trim().split(/\s+/);
          const totalKB = Number(parts[1]);
          const availKB = Number(parts[3]);
          if (!isNaN(totalKB) && !isNaN(availKB)) {
            resolve({ totalBytes: totalKB * 1024, freeBytes: availKB * 1024 });
          } else {
            resolve(null);
          }
        });
      }
    });
  });

  // ============================================================
  // 📥 舊系統資料匯入（Microsoft Access .accdb / .mdb）
  //
  // 用 mdb-reader 這套純 JavaScript 套件直接讀 Access 資料庫檔案本身，
  // 不需要安裝 Access、不需要 ODBC 驅動、也不用先手動匯出成 Excel/CSV——
  // 業主只要把舊系統資料夾裡的 .accdb 或 .mdb 檔案直接選起來就好。
  //
  // 這裡只負責「讀檔案、把資料表內容整理成前端看得懂的格式」，實際要怎麼
  // 對應欄位、寫進 Firebase，是在 renderer.js 那邊做的（因為 Firebase 的
  // 連線是在網頁端），main.js 這邊完全不碰 Firebase。
  // ============================================================

  // 讀取/儲存這種要跟作業系統互動的視窗，一律用一般小視窗，不要全螢幕
  // （不然原生的檔案選取視窗在全螢幕模式下容易被蓋住或跑版）。
  // 所有會跳出系統原生視窗（開檔、存檔、列印）的地方，呼叫前都先叫這支。
  function exitFullScreenForOSDialog() {
    const win = getMainWindow();
    if (win && win.isFullScreen()) win.setFullScreen(false);
  }

  // 選擇 Access 檔案：跳出系統的「開啟檔案」視窗，只能選 .accdb / .mdb
  ipcMain.handle("access-import-pick-file", async () => {
    exitFullScreenForOSDialog();
    const result = await dialog.showOpenDialog(getMainWindow(), {
      title: "選擇舊系統的 Access 資料庫檔案",
      properties: ["openFile"],
      filters: [
        { name: "Access 資料庫", extensions: ["accdb", "mdb"] },
        { name: "所有檔案", extensions: ["*"] },
      ],
    });
    if (result.canceled || result.filePaths.length === 0) return null;
    return result.filePaths[0];
  });

  // 把 mdb-reader 讀出來的值轉成能安全透過 IPC 傳到網頁端的型別：
  // Date 轉成 ISO 字串、二進位內容（OLE 物件／附件欄位）直接跳過不傳，
  // 這兩種格式的原始值都沒辦法直接被前端用來對應到文字欄位。
  function sanitizeAccessCellValue(value) {
    if (value === null || value === undefined) return null;
    if (value instanceof Date) return value.toISOString();
    if (Buffer.isBuffer(value)) return "[二進位內容，無法匯入]";
    if (typeof value === "bigint") return value.toString();
    return value;
  }

  // 讀取整個 Access 檔案：回傳每一張資料表的欄位名稱 + 全部資料列。
  // 舊系統的資料庫通常不大（一個機車行的客戶/維修紀錄，頂多幾千筆），
  // 一次整包讀出來給前端做欄位對應跟預覽，不用再另外分頁讀取。
  ipcMain.handle("access-import-read-file", async (event, filePath) => {
    try {
      const buffer = fs.readFileSync(filePath);
      const { default: MDBReader } = await import("mdb-reader");
      const reader = new MDBReader(buffer);

      const tableNames = reader.getTableNames({
        normalTables: true,
        systemTables: false,
        linkedTables: false,
      });

      const tables = {};
      for (const name of tableNames) {
        const table = reader.getTable(name);
        const columns = table.getColumnNames();
        const rawRows = table.getData();
        const rows = rawRows.map((row) => {
          const clean = {};
          for (const col of columns) {
            clean[col] = sanitizeAccessCellValue(row[col]);
          }
          return clean;
        });
        tables[name] = { columns, rows };
      }

      return { ok: true, tables };
    } catch (err) {
      console.error("讀取 Access 檔案失敗：", err);
      return {
        ok: false,
        error: err.message || "無法讀取這個檔案，請確認檔案沒有損毀、也不是加密過的資料庫",
      };
    }
  });

  // ============================================================
  // 📄 產生估價單（Word .docx）
  //
  // 前端（renderer.js）把目前選到的顧客／車輛／維修項目資料整理成一包
  // JSON 傳進來，這裡負責套用「估價單範本」（estimate-template.js，跟
  // 老闆提供的原始 Word 範本逐一比對過欄位與版面）產生真正的 .docx 檔案，
  // 跳出「另存新檔」視窗讓使用者選存檔位置，存完直接用系統預設的 Word
  // 開啟，方便馬上檢查、列印或簽名。
  // ============================================================
  ipcMain.handle("generate-estimate-docx", async (event, payload) => {
    try {
      const { buffer, truncated } = await buildEstimateDocxBuffer(payload || {});

      const safePlate = (payload && payload.plate ? payload.plate : "")
        .replace(/[\\/:*?"<>|]/g, "")
        .trim();
      const safeDate = (payload && (payload.entryDate || payload.quoteDate)) || "";
      const defaultName = `估價單${safePlate ? "_" + safePlate : ""}${
        safeDate ? "_" + safeDate : ""
      }.docx`;

      exitFullScreenForOSDialog();
      const result = await dialog.showSaveDialog(getMainWindow(), {
        title: "儲存估價單",
        defaultPath: defaultName,
        filters: [
          { name: "Word 文件", extensions: ["docx"] },
          { name: "所有檔案", extensions: ["*"] },
        ],
      });
      if (result.canceled || !result.filePath) {
        return { ok: false, canceled: true };
      }

      try {
        fs.writeFileSync(result.filePath, buffer);
      } catch (writeErr) {
        // EBUSY／EPERM：目標檔案通常是「已經在 Word 開著」被鎖住，不是程式本身壞掉。
        // 給比較看得懂的訊息，而不是直接丟英文系統錯誤給店家看。
        if (writeErr && (writeErr.code === "EBUSY" || writeErr.code === "EPERM")) {
          return {
            ok: false,
            error: `這個檔案目前已經在 Word 開著，請先把它關閉（不要存檔覆蓋），再重新產生一次估價單。\n檔案位置：${result.filePath}`,
          };
        }
        throw writeErr;
      }
      shell.openPath(result.filePath); // 存完直接開啟，方便老闆馬上看／列印

      return { ok: true, filePath: result.filePath, truncated };
    } catch (err) {
      console.error("產生估價單失敗：", err);
      return { ok: false, error: err.message || String(err) };
    }
  });

  // 開一個看不到的隱藏視窗，載入估價單的 HTML 版本（estimate-html.js），
  // 給 PDF 匯出／直接列印共用──兩者都需要先把同一份 HTML 渲染出來，
  // 差別只在後面是呼叫 printToPDF() 還是 print()。
  function createHiddenEstimateWindow(html) {
    return new Promise((resolve, reject) => {
      const win = new BrowserWindow({ show: false, webPreferences: { sandbox: true } });
      win.webContents.once("did-finish-load", () => resolve(win));
      win.webContents.once("did-fail-load", (_event, _code, desc) => {
        reject(new Error(desc || "估價單頁面載入失敗"));
      });
      win.loadURL("data:text/html;charset=UTF-8," + encodeURIComponent(html));
    });
  }

  // ============================================================
  // 📄 產生估價單（PDF）
  //
  // 跟 Word 版走同一包 payload，但改用 estimate-html.js 產生 HTML，
  // 交給 Chromium 內建的 printToPDF() 轉成 PDF——不需要額外裝 LibreOffice
  // 或 Word 才能轉檔，Electron 本身就有這個能力。
  // ============================================================
  ipcMain.handle("generate-estimate-pdf", async (event, payload) => {
    let win;
    try {
      const html = buildEstimateHtml(payload || {});
      win = await createHiddenEstimateWindow(html);
      const pdfBuffer = await win.webContents.printToPDF({
        pageSize: "A4",
        printBackground: true,
        preferCSSPageSize: true,
        margins: { marginType: "none" },
      });

      const safePlate = (payload && payload.plate ? payload.plate : "")
        .replace(/[\\/:*?"<>|]/g, "")
        .trim();
      const safeDate = (payload && (payload.entryDate || payload.quoteDate)) || "";
      const defaultName = `估價單${safePlate ? "_" + safePlate : ""}${
        safeDate ? "_" + safeDate : ""
      }.pdf`;

      exitFullScreenForOSDialog();
      const result = await dialog.showSaveDialog(getMainWindow(), {
        title: "儲存估價單（PDF）",
        defaultPath: defaultName,
        filters: [
          { name: "PDF 文件", extensions: ["pdf"] },
          { name: "所有檔案", extensions: ["*"] },
        ],
      });
      if (result.canceled || !result.filePath) {
        return { ok: false, canceled: true };
      }

      try {
        fs.writeFileSync(result.filePath, pdfBuffer);
      } catch (writeErr) {
        if (writeErr && (writeErr.code === "EBUSY" || writeErr.code === "EPERM")) {
          return {
            ok: false,
            error: `這個檔案目前已經開著（可能還開在 PDF 閱讀器裡），請先關閉，再重新產生一次估價單。\n檔案位置：${result.filePath}`,
          };
        }
        throw writeErr;
      }
      shell.openPath(result.filePath);

      return { ok: true, filePath: result.filePath };
    } catch (err) {
      console.error("產生估價單 PDF 失敗：", err);
      return { ok: false, error: err.message || String(err) };
    } finally {
      if (win && !win.isDestroyed()) win.destroy();
    }
  });

  // ============================================================
  // 🖨️ 直接列印估價單
  //
  // 一樣先產生 HTML，再叫出系統原生的列印視窗，讓使用者自己選印表機、
  // 份數等等——不用先存成檔案再手動開啟列印，省一道手續。
  // ============================================================
  ipcMain.handle("print-estimate", async (event, payload) => {
    let win;
    try {
      const html = buildEstimateHtml(payload || {});
      win = await createHiddenEstimateWindow(html);

      exitFullScreenForOSDialog();
      const { success, errorType } = await new Promise((resolve) => {
        win.webContents.print({ silent: false, printBackground: true }, (ok, errType) => {
          resolve({ success: ok, errorType: errType });
        });
      });

      if (!success && errorType && errorType !== "cancelled") {
        return { ok: false, error: errorType };
      }
      return { ok: true, canceled: !success };
    } catch (err) {
      console.error("列印估價單失敗：", err);
      return { ok: false, error: err.message || String(err) };
    } finally {
      if (win && !win.isDestroyed()) win.destroy();
    }
  });

  // ============================================================
  // 📶 網路狀態（整個應用程式視窗右下角的訊號格圖示要用）
  //
  // 格數改用「PING 值」決定（連到 8.8.8.8 量測來回時間），比單純看
  // WiFi 訊號百分比更準：訊號滿格但網路很塞一樣會 ping 很慢，格數
  // 也能反映出來；有線網路雖然沒有「訊號強度」這種東西，但一樣可以
  // 用 ping 快慢來評分。
  //
  // 另外用 netsh 判斷「目前是不是用 WiFi 連線」，只是用來決定畫面
  // 要顯示哪一種圖示（WiFi 圖示 vs. 有線網路的訊號格圖示），格數
  // 本身不看這個百分比。
  //
  // Node/Electron 本身沒有跨平台的 API 可以判斷是不是連 WiFi，
  // 目前只在 Windows 上用系統內建的 netsh 指令去讀（這台程式本來就
  // 是包成 Windows 安裝檔給店家用），其他平台（例如開發時用 Mac 測試）
  // 就直接當作「不是 WiFi」處理。
  // ============================================================
  function isConnectedViaWifi() {
    return new Promise((resolve) => {
      if (process.platform !== "win32") {
        resolve(false);
        return;
      }
      exec("netsh wlan show interfaces", { timeout: 5000 }, (error, stdout) => {
        // 只要抓得到「已連線的無線網卡」（輸出裡會有訊號百分比），就算 WiFi。
        // 沒開 WiFi、電腦沒有無線網卡、或指令失敗，都當作不是 WiFi（走有線圖示）。
        resolve(!error && !!stdout && /\d{1,3}\s*%/.test(stdout));
      });
    });
  }

  // 量測到 8.8.8.8 的 PING 值（毫秒）。只抓輸出裡第一個「數字 + ms」，
  // 不去比對「時間」或「time」這個欄位名稱本身——一樣是因為 Windows
  // 系統語言不同、ping 指令的輸出文字會跟著變（英文版 time=15ms，
  // 中文版 時間=15ms），比對文字容易抓不到；而這個指令的輸出裡第一個
  // 出現「ms」的地方就是來回時間，用這個規律最穩定。
  function getPingMs() {
    return new Promise((resolve) => {
      const cmd =
        process.platform === "win32"
          ? "ping -n 1 -w 2000 8.8.8.8"
          : "ping -c 1 -W 2 8.8.8.8";
      exec(cmd, { timeout: 4000 }, (error, stdout) => {
        if (error || !stdout) {
          resolve(null); // 斷線、逾時、或指令失敗，都當作「沒有網路」
          return;
        }
        const match = stdout.match(/(\d+(?:\.\d+)?)\s*ms/);
        resolve(match ? Math.round(parseFloat(match[1])) : null);
      });
    });
  }

  // -----------------------------------------------------------------
  // 🔋 判斷這台電腦是「桌上型電腦」還是「筆記型電腦」，如果是筆記型電腦
  // 就順便讀出目前的電量百分比、有沒有在充電。
  //
  // 做法：查詢 Windows 內建的 Win32_Battery 這個系統資訊類別——桌上型電腦
  // 通常查不到任何一筆資料（沒有電池），筆記型電腦則會查到一筆，裡面帶著
  // BatteryStatus（電池狀態代碼）跟 EstimatedChargeRemaining（電量百分比）。
  // 只在 Windows 上查（這台程式本來就是包成 Windows 安裝檔給店家用），
  // 其他平台（例如開發時用 Mac 測試）就直接當作「沒有電池」＝桌上型電腦。
  //
  // BatteryStatus 代碼意義（Windows 官方定義）：
  //   1 = 用電池放電中（沒插電）       4 = 電量低       5 = 電量嚴重不足
  //   2 = 有插電、不是靠電池供電        10 = 未定義       11 = 部分充電
  //   3 = 已充飽                        6/7/8/9 = 充電中（依電量高低細分）
  // 只要代碼落在「有插電」或「充電中」那幾種，就當作正在充電。
  // -----------------------------------------------------------------
  function getBatteryInfo() {
    return new Promise((resolve) => {
      if (process.platform !== "win32") {
        resolve({ hasBattery: false });
        return;
      }
      const cmd =
        'powershell -NoProfile -NonInteractive -Command ' +
        '"Get-CimInstance -ClassName Win32_Battery | ' +
        'Select-Object -First 1 BatteryStatus,EstimatedChargeRemaining | ' +
        'ConvertTo-Json -Compress"';
      exec(cmd, { timeout: 5000, windowsHide: true }, (error, stdout) => {
        if (error || !stdout || !stdout.trim()) {
          resolve({ hasBattery: false }); // 查不到電池資料，當作桌上型電腦
          return;
        }
        try {
          let data = JSON.parse(stdout.trim());
          if (Array.isArray(data)) data = data[0];
          if (!data || typeof data.BatteryStatus === "undefined") {
            resolve({ hasBattery: false });
            return;
          }
          const status = Number(data.BatteryStatus);
          const charging = [2, 6, 7, 8, 9].includes(status);
          const level =
            typeof data.EstimatedChargeRemaining === "number"
              ? data.EstimatedChargeRemaining
              : null;
          resolve({ hasBattery: true, level, charging });
        } catch (e) {
          resolve({ hasBattery: false });
        }
      });
    });
  }

  ipcMain.handle("get-battery-info", async () => {
    return getBatteryInfo();
  });

  // 定時把目前的電池／設備狀態推播給畫面（跟 WiFi 訊號格用同一顆計時器
  // 邏輯，但獨立一個 interval，避免兩邊互相影響）。
  function startBatteryBroadcast(win) {
    const sendUpdate = async () => {
      if (win.isDestroyed()) return;
      const info = await getBatteryInfo();
      if (!win.isDestroyed()) {
        win.webContents.send("battery-update", info);
      }
    };
    sendUpdate();
    const timer = setInterval(sendUpdate, 20000); // 每 20 秒更新一次
    win.on("closed", () => clearInterval(timer));
  }

  // -----------------------------------------------------------------
  // 📶 網路詳細診斷：連續 ping 8.8.8.8 好幾次（而不是只 ping 一次），

  // 藉此算出「封包遺失率」跟「PING 抖動（jitter）」這兩個只 ping 一次
  // 量不出來的指標：
  //   - 封包遺失率：直接讀 ping 指令自己算好的統計數字（Windows 是
  //     「Lost = N (X% loss)」，macOS/Linux 是「X% packet loss」）。
  //   - 抖動：把每一次 ping 抓到的時間，跟「前一次」的時間相減取絕對值，
  //     再全部平均——這是業界常見的「連續封包間抖動」算法，數字越小代表
  //     每次來回時間越穩定，數字越大代表忽快忽慢（例如訊號不穩的 WiFi）。
  // 兩個作業系統的文字輸出格式不一樣，但都會出現「time=15ms」這種格式，
  // 用同一個規則就能抓出每一次的時間，不用分平台寫兩套邏輯。
  // -----------------------------------------------------------------
  function getNetworkDiagnostics() {
    return new Promise((resolve) => {
      const count = 8;
      const cmd =
        process.platform === "win32"
          ? `ping -n ${count} -w 1000 8.8.8.8`
          : `ping -c ${count} -W 1 8.8.8.8`;
      exec(cmd, { timeout: 15000 }, (error, stdout) => {
        const output = stdout || "";

        // ⚠️ 不能用「time=」「loss」這幾個英文字去抓資料：Windows 在非英文
        // 系統語言下，這幾個字會被翻譯掉（例如繁體中文版是「時間=15ms」、
        // 統計那行是「遺失」不是「loss」），照抓英文字會完全抓不到、變成
        // 每次都顯示「無法量測」、封包遺失率誤判成 100%。
        // 改成找「TTL=」這個欄位——不管哪一種語言的 Windows、或 macOS／
        // Linux，這個縮寫都不會被翻譯，只要那一行有 TTL 就代表「這一次有
        // 收到回應」，再從同一行裡抓出「=數字ms」或「<数字ms」那段當作
        // 這一次的來回時間，同樣不用管前面那個字是英文的 time 還是中文的
        // 時間，只認「=／< + 數字 + ms」這個固定不變的格式。
        const lines = output.split(/\r?\n/);
        const samples = [];
        lines.forEach((line) => {
          if (!/ttl\s*=/i.test(line)) return;
          const m = line.match(/[=<]\s*(\d+(?:\.\d+)?)\s*ms\b/i);
          if (m) samples.push(parseFloat(m[1]));
        });

        // 封包遺失率：自己用「原本打算送出幾次」跟「實際收到幾次回應」
        // 算出來，不去讀 ping 指令本身翻譯過的統計文字，才不會因為系統
        // 語言不同而讀錯。
        const lossPercent = Math.round(((count - samples.length) / count) * 100);

        let avgPing = null;
        let jitterMs = null;
        if (samples.length > 0) {
          avgPing = samples.reduce((a, b) => a + b, 0) / samples.length;
          if (samples.length > 1) {
            let diffSum = 0;
            for (let i = 1; i < samples.length; i++) {
              diffSum += Math.abs(samples[i] - samples[i - 1]);
            }
            jitterMs = diffSum / (samples.length - 1);
          } else {
            jitterMs = 0;
          }
        }

        resolve({
          pingMs: avgPing !== null ? Math.round(avgPing) : null,
          lossPercent,
          jitterMs: jitterMs !== null ? Math.round(jitterMs * 10) / 10 : null,
        });
      });
    });
  }

  ipcMain.handle("get-network-diagnostics", async () => {
    const [isWifi, diag] = await Promise.all([
      isConnectedViaWifi(),
      getNetworkDiagnostics(),
    ]);
    return { isWifi, ...diag };
  });

  // -----------------------------------------------------------------
  // ⬆️ 上傳速度測試：實際上傳一段隨機資料到公開的測速伺服器（Cloudflare
  // 的 speed.cloudflare.com/__up，跟很多瀏覽器測速工具用的是同一個公開
  // 端點，不需要金鑰），從「開始送出」到「伺服器回應收完」算出耗費的
  // 時間，換算成 Mbps。量不到（離線、逾時、連線失敗）就回傳 null，
  // 畫面那邊會顯示「無法量測」。
  // -----------------------------------------------------------------
  function measureUploadSpeedMbps() {
    return new Promise((resolve) => {
      try {
        const sizeBytes = 4 * 1024 * 1024; // 4MB，量測時間跟準確度的折衷
        const payload = crypto.randomBytes(sizeBytes);
        const start = Date.now();
        const req = https.request(
          {
            hostname: "speed.cloudflare.com",
            path: "/__up",
            method: "POST",
            headers: {
              "Content-Type": "application/octet-stream",
              "Content-Length": payload.length,
            },
            timeout: 10000,
          },
          (res) => {
            res.on("data", () => {}); // 不需要回應內容，只在意花了多久
            res.on("end", () => {
              const elapsedSec = (Date.now() - start) / 1000;
              if (!elapsedSec || elapsedSec <= 0) {
                resolve(null);
                return;
              }
              const mbps = (sizeBytes * 8) / elapsedSec / 1_000_000;
              resolve(Math.round(mbps * 10) / 10);
            });
          }
        );
        req.on("timeout", () => {
          req.destroy();
          resolve(null);
        });
        req.on("error", () => resolve(null));
        req.write(payload);
        req.end();
      } catch (e) {
        resolve(null);
      }
    });
  }

  // -----------------------------------------------------------------
  // 📊 給狀態動態島「點擊網路圖示展開」的詳細面板用：一次把 PING、延遲、
  // 抖動、封包遺失率、上傳速度、伺服器資訊、連線類型全部量好、包成一個
  // 物件回傳，畫面只要呼叫這一支就好，不用自己兜好幾支 IPC。
  // ping／抖動／封包遺失率量的都是同一台伺服器（Google DNS），所以
  // 「伺服器資訊」就照實顯示那台伺服器的位址。
  // -----------------------------------------------------------------
  async function getNetworkPanelDiagnostics() {
    const [isWifi, diag, uploadMbps] = await Promise.all([
      isConnectedViaWifi(),
      getNetworkDiagnostics(),
      measureUploadSpeedMbps(),
    ]);
    return {
      isWifi,
      pingMs: diag.pingMs,
      jitterMs: diag.jitterMs,
      lossPercent: diag.lossPercent,
      uploadMbps,
      serverInfo: "Google DNS（8.8.8.8）",
    };
  }

  ipcMain.handle("get-network-panel-diagnostics", async () => {
    return getNetworkPanelDiagnostics();
  });

  // 背景持續量測完整診斷（含上傳速度測試），讓畫面那顆狀態膠囊隨時都有
  // 現成的數據可以顯示，使用者點開面板不用再等「量測中…」。
  // 這組量測比訊號格用的單純 PING 重很多（含一次真的 4MB 上傳），所以
  // 間隔拉長到 60 秒一次，不跟訊號格的 10 秒 PING 用同一個頻率，
  // 避免背景一直佔頻寬。視窗關掉要記得清掉計時器，跟其他背景廣播一樣。
  function startNetworkPanelDiagnosticsBroadcast(win) {
    const sendUpdate = async () => {
      if (win.isDestroyed()) return;
      const result = await getNetworkPanelDiagnostics();
      if (!win.isDestroyed()) {
        win.webContents.send("network-panel-diagnostics-update", result);
      }
    };
    sendUpdate();
    const timer = setInterval(sendUpdate, 60000); // 每 60 秒更新一次
    win.on("closed", () => clearInterval(timer));
  }

  // 每隔一段時間主動把最新的網路狀態（PING 值 + 是不是 WiFi）推播給
  // 畫面，畫面不用自己一直呼叫 IPC 去問。視窗關掉時要記得把計時器
  // 清掉，不然視窗物件沒辦法被釋放（記憶體洩漏）。
  function startWifiStrengthBroadcast(win) {
    const sendUpdate = async () => {
      if (win.isDestroyed()) return;
      const [isWifi, pingMs] = await Promise.all([
        isConnectedViaWifi(),
        getPingMs(),
      ]);
      if (!win.isDestroyed()) {
        win.webContents.send("wifi-strength-update", { isWifi, pingMs });
      }
    };
    sendUpdate();
    const timer = setInterval(sendUpdate, 10000); // 每 10 秒更新一次
    win.on("closed", () => clearInterval(timer));
  }

  ipcMain.handle("get-wifi-strength", async () => {
    const [isWifi, pingMs] = await Promise.all([isConnectedViaWifi(), getPingMs()]);
    return { isWifi, pingMs };
  });

  // 給網頁端切換「主視窗全螢幕」用的入口，例如進入維修項目的分類選單時全螢幕、
  // 離開時恢復一般視窗大小。跟作業系統互動的讀取／儲存視窗（開檔、存檔、列印）
  // 一律維持一般小視窗，不會呼叫這支——見上面各個 dialog 呼叫前的
  // exitFullScreenForOSDialog()。
  ipcMain.handle("set-fullscreen", (event, shouldBeFullScreen) => {
    const win = getMainWindow();
    if (!win) return false;
    win.setFullScreen(!!shouldBeFullScreen);
    return win.isFullScreen();
  });
  // ------------------------------------------------------------
  // 掛上這個視窗之後，立刻開始推播 Wi-Fi 訊號格 / 電量狀態
  // （原本在 createWindow() 裡視窗建好後馬上呼叫，現在改成
  // registerApp() 被呼叫的當下——bootloader 一定是先建好視窗、
  // 才 require 這支檔案並呼叫這個函式，所以這裡拿到的視窗已經是
  // 真正要用的那一個）。
  // ------------------------------------------------------------
  const win = getMainWindow();
  if (win) {
    startWifiStrengthBroadcast(win);
    startBatteryBroadcast(win);
    startNetworkPanelDiagnosticsBroadcast(win);
  }
};
