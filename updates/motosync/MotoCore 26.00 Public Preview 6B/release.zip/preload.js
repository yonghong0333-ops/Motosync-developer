const { contextBridge, ipcRenderer } = require("electron");

// 開放一個安全、範圍很小的介面給網頁端（renderer.js）呼叫：
// 網頁端只能「請求開始 Google 登入」，其他 Node.js / 系統層級的能力
// 完全不會開放出去，符合 contextIsolation 的安全設計。
contextBridge.exposeInMainWorld("electronAPI", {
  getShopFirebaseConfig: () => ipcRenderer.invoke("get-shop-firebase-config"),
  getShopSettings: () => ipcRenderer.invoke("get-shop-settings"),
  getLicenseKey: () => ipcRenderer.invoke("get-license-key"),
  loginWithGoogle: () => ipcRenderer.invoke("google-login"),
  offlineLogin: () => ipcRenderer.invoke("offline-login"),
  checkLicense: () => ipcRenderer.invoke("check-app-license"),
  // 「關於軟體」頁專用：讀開機那次驗證留下的授權資料，供店家名稱／
  // 授權金鑰／啟用狀態顯示用（見 renderer.js 的 settingsCurrentPage
  // === "about"）。
  getAboutSoftwareInfo: () => ipcRenderer.invoke("get-about-software-info"),
  readOfflineQueue: () => ipcRenderer.invoke("offline-queue-read"),
  writeOfflineQueue: (queue) => ipcRenderer.invoke("offline-queue-write", queue),
  // 通用離線寫入佇列（涵蓋維修紀錄新增以外的所有寫入操作，見 renderer.js
  // 的 dbWriteQueued / syncPendingWrites）
  readPendingWrites: () => ipcRenderer.invoke("pending-writes-read"),
  writePendingWrites: (queue) => ipcRenderer.invoke("pending-writes-write", queue),
  // 離線庫存異動佇列（庫存要用 runTransaction 才能保證正確，跟上面兩份
  // 佇列的「直接補送同一個操作」不同，所以獨立存放，見 renderer.js 的
  // adjustItemStock / syncStockDeltaQueue）
  readStockDeltaQueue: () => ipcRenderer.invoke("stock-delta-queue-read"),
  writeStockDeltaQueue: (queue) => ipcRenderer.invoke("stock-delta-queue-write", queue),
  readLocalCache: () => ipcRenderer.invoke("local-cache-read"),
  writeLocalCache: (data) => ipcRenderer.invoke("local-cache-write", data),
  clearLocalCache: () => ipcRenderer.invoke("local-cache-clear"),
  clearLocalVersions: () => ipcRenderer.invoke("factory-reset-clear-versions"),
  relaunchApp: () => ipcRenderer.invoke("app:relaunch"),
  clearBrowserCache: () => ipcRenderer.invoke("clear-browser-cache"),
  getLocalCacheInfo: () => ipcRenderer.invoke("local-cache-info"),
  getDiskSpace: () => ipcRenderer.invoke("get-disk-space"),
  openLocalDataFolder: () => ipcRenderer.invoke("open-local-data-folder"),
  pickAccessFile: () => ipcRenderer.invoke("access-import-pick-file"),
  readAccessFile: (filePath) =>
    ipcRenderer.invoke("access-import-read-file", filePath),
  generateEstimateDocx: (payload) =>
    ipcRenderer.invoke("generate-estimate-docx", payload),
  generateEstimatePdf: (payload) =>
    ipcRenderer.invoke("generate-estimate-pdf", payload),
  printEstimate: (payload) => ipcRenderer.invoke("print-estimate", payload),
  quitApp: () => ipcRenderer.invoke("quit-app"),
  // 視窗改成 frame: false（不用 Windows 原生外框）之後，最小化／關閉
  // 這兩顆按鈕要自己畫、自己送 IPC 給殼（main.js）處理。
  minimizeWindow: () => ipcRenderer.send("window:minimize"),
  closeWindow: () => ipcRenderer.send("window:close"),
  getWifiStrength: () => ipcRenderer.invoke("get-wifi-strength"),
  getNetworkDiagnostics: () => ipcRenderer.invoke("get-network-diagnostics"),
  getNetworkPanelDiagnostics: () =>
    ipcRenderer.invoke("get-network-panel-diagnostics"),
  sendPasswordResetCode: (recipientEmail, purpose) =>
    ipcRenderer.invoke("send-password-reset-code", recipientEmail, purpose),
  verifyPasswordResetCode: (code) =>
    ipcRenderer.invoke("verify-password-reset-code", code),
  onWifiStrength: (callback) =>
    ipcRenderer.on("wifi-strength-update", (_event, percent) => callback(percent)),
  getBatteryInfo: () => ipcRenderer.invoke("get-battery-info"),
  onBatteryUpdate: (callback) =>
    ipcRenderer.on("battery-update", (_event, info) => callback(info)),
  onNetworkPanelDiagnosticsUpdate: (callback) =>
    ipcRenderer.on("network-panel-diagnostics-update", (_event, result) =>
      callback(result)
    ),
  setFullScreen: (shouldBeFullScreen) =>
    ipcRenderer.invoke("set-fullscreen", !!shouldBeFullScreen),
  // 軟體更新的全螢幕安裝鎖：安裝開始/結束時通知主行程，安裝中連視窗
  // 關閉（含 Alt+F4）都要擋下，避免使用者中途關程式造成安裝損毀。
  setUpdateInstallLock: (locked) => ipcRenderer.send("update:set-install-lock", !!locked),
  // 啟動驗證：bootloader 切版之後會等這個 ping，30 秒內沒收到就自動
  // 判定「這個版本壞掉了」退回舊版本（見 renderer.js 的
  // checkAppLicenseOnStartup()，通過授權檢查後會呼叫這個）。
  notifyStartupVerified: () => ipcRenderer.invoke("update:startup-verify-ping"),
});

// ============================================================
// Ctrl + 滑鼠滾輪縮放視窗
//
// 主行程（main-bootloader.js）收不到滑鼠滾輪事件，所以在這裡（畫面
// 端）直接攔截 wheel 事件：按著 Ctrl 滾動時，擋掉瀏覽器原生的縮放/
// 捲動行為，改成送 IPC 給主行程統一處理（跟 Ctrl+ / Ctrl- 快捷鍵共用
// 同一套 applyWindowZoom 邏輯，縮放級距、視窗尺寸同步都一致）。
//
// deltaY < 0 代表滾輪往前推（遠離使用者），對應「放大」；
// deltaY > 0 代表滾輪往後推（靠近使用者），對應「縮小」，
// 這跟一般瀏覽器 Ctrl+滾輪的方向習慣一致。
//
// { capture: true } 讓事件在最外層就先攔到，不管游標在頁面裡哪個
// 元素上滾動都會生效；{ passive: false } 是因為要呼叫
// preventDefault()，被動監聽器沒辦法擋下原生行為。
// ============================================================
window.addEventListener(
  "wheel",
  (event) => {
    if (!event.ctrlKey) return;
    event.preventDefault();
    ipcRenderer.send("window:zoom-wheel", event.deltaY < 0 ? "in" : "out");
  },
  { passive: false, capture: true }
);

// ============================================================
// 接收主行程送來的縮放倍率，直接對 <body> 套用 CSS transform: scale()
//
// 沒有用 Electron 內建的 webContents.setZoomFactor()（瀏覽器層級縮放）
// 是因為實測不夠可靠：視窗外框尺寸變了，但畫面內容沒有跟著放大，
// 變成內容擠在左上角、其餘空間空白一片。改成自己控制 transform，
// 縮放倍率跟主行程算視窗尺寸用的是同一個數字，保證同步。
//
// body 先固定成設計基準尺寸（1140x810，要跟 main-bootloader.js 的
// BASE_WINDOW_WIDTH/BASE_WINDOW_HEIGHT 一致，這裡改用主行程傳過來的
// 數字，不自己寫死，避免以後兩邊改了其中一處就對不上），再用
// transform-origin: top left 從左上角等比例放大/縮小，縮放後的實際
// 尺寸剛好等於視窗內容區大小（因為視窗那邊也是拿同一個倍率乘出來
// 的），兩邊嚴格對齊，不會有空白或裁切。
//
// <body> 本身套用 transform 之後，會變成它所有子元素（包含
// position:fixed 的自訂標題列 #titlebar）的新定位基準，所以 fixed
// 元素也會正確一起縮放，不會維持原本大小、跟其他內容脫節。
// ============================================================
function applyBodyZoom(scale, baseWidth, baseHeight) {
  const body = document.body;
  if (!body) return;
  body.style.width = `${baseWidth}px`;
  body.style.height = `${baseHeight}px`;
  body.style.transformOrigin = "top left";
  body.style.transform = `scale(${scale})`;
  // 避免 body 縮放後，外層 html 元素因為預設 overflow 而跑出捲軸、
  // 或縮小時背景露出非預期的邊界顏色。
  body.style.overflow = "hidden";
  body.style.margin = "0";
}

let pendingZoom = null;
ipcRenderer.on("motosync:apply-zoom", (_event, scale, baseWidth, baseHeight) => {
  if (document.body) {
    applyBodyZoom(scale, baseWidth, baseHeight);
  } else {
    // 主行程送這個訊息的時機，理論上都是 did-finish-load 之後（DOM
    // 一定已經好了），但保留這個保險：萬一真的太早收到，先記下來，
    // 等 DOMContentLoaded 再補套用一次，不要整個訊息被丟掉。
    pendingZoom = { scale, baseWidth, baseHeight };
    window.addEventListener(
      "DOMContentLoaded",
      () => {
        if (pendingZoom) applyBodyZoom(pendingZoom.scale, pendingZoom.baseWidth, pendingZoom.baseHeight);
      },
      { once: true }
    );
  }
});
