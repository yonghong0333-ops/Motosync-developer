const { contextBridge, ipcRenderer } = require("electron");

// 開放一個安全、範圍很小的介面給網頁端（renderer.js）呼叫：
// 網頁端只能「請求開始 Google 登入」，其他 Node.js / 系統層級的能力
// 完全不會開放出去，符合 contextIsolation 的安全設計。
contextBridge.exposeInMainWorld("electronAPI", {
  getShopFirebaseConfig: () => ipcRenderer.invoke("get-shop-firebase-config"),
  getShopSettings: () => ipcRenderer.invoke("get-shop-settings"),
  getLicenseKey: () => ipcRenderer.invoke("get-license-key"),
  loginWithGoogle: () => ipcRenderer.invoke("google-login"),
  offlineLogin: () => ipcRenderer.invoke("offline-login"),
  checkLicense: () => ipcRenderer.invoke("check-app-license"),
  // 「關於軟體」頁專用：讀開機那次驗證留下的授權資料，供店家名稱／
  // 授權金鑰／啟用狀態顯示用（見 renderer.js 的 settingsCurrentPage
  // === "about"）。
  getAboutSoftwareInfo: () => ipcRenderer.invoke("get-about-software-info"),
  readOfflineQueue: () => ipcRenderer.invoke("offline-queue-read"),
  writeOfflineQueue: (queue) => ipcRenderer.invoke("offline-queue-write", queue),
  // 通用離線寫入佇列（涵蓋維修紀錄新增以外的所有寫入操作，見 renderer.js
  // 的 dbWriteQueued / syncPendingWrites）
  readPendingWrites: () => ipcRenderer.invoke("pending-writes-read"),
  writePendingWrites: (queue) => ipcRenderer.invoke("pending-writes-write", queue),
  // 離線庫存異動佇列（庫存要用 runTransaction 才能保證正確，跟上面兩份
  // 佇列的「直接補送同一個操作」不同，所以獨立存放，見 renderer.js 的
  // adjustItemStock / syncStockDeltaQueue）
  readStockDeltaQueue: () => ipcRenderer.invoke("stock-delta-queue-read"),
  writeStockDeltaQueue: (queue) => ipcRenderer.invoke("stock-delta-queue-write", queue),
  readLocalCache: () => ipcRenderer.invoke("local-cache-read"),
  writeLocalCache: (data) => ipcRenderer.invoke("local-cache-write", data),
  clearLocalCache: () => ipcRenderer.invoke("local-cache-clear"),
  clearLocalVersions: () => ipcRenderer.invoke("factory-reset-clear-versions"),
  relaunchApp: () => ipcRenderer.invoke("app:relaunch"),
  clearBrowserCache: () => ipcRenderer.invoke("clear-browser-cache"),
  getLocalCacheInfo: () => ipcRenderer.invoke("local-cache-info"),
  getDiskSpace: () => ipcRenderer.invoke("get-disk-space"),
  openLocalDataFolder: () => ipcRenderer.invoke("open-local-data-folder"),
  pickAccessFile: () => ipcRenderer.invoke("access-import-pick-file"),
  readAccessFile: (filePath) =>
    ipcRenderer.invoke("access-import-read-file", filePath),
  generateEstimateDocx: (payload) =>
    ipcRenderer.invoke("generate-estimate-docx", payload),
  generateEstimatePdf: (payload) =>
    ipcRenderer.invoke("generate-estimate-pdf", payload),
  printEstimate: (payload) => ipcRenderer.invoke("print-estimate", payload),
  quitApp: () => ipcRenderer.invoke("quit-app"),
  // 視窗改成 frame: false（不用 Windows 原生外框）之後，最小化／關閉
  // 這兩顆按鈕要自己畫、自己送 IPC 給殼（main.js）處理。
  minimizeWindow: () => ipcRenderer.send("window:minimize"),
  closeWindow: () => ipcRenderer.send("window:close"),
  getWifiStrength: () => ipcRenderer.invoke("get-wifi-strength"),
  getNetworkDiagnostics: () => ipcRenderer.invoke("get-network-diagnostics"),
  getNetworkPanelDiagnostics: () =>
    ipcRenderer.invoke("get-network-panel-diagnostics"),
  sendPasswordResetCode: (recipientEmail, purpose) =>
    ipcRenderer.invoke("send-password-reset-code", recipientEmail, purpose),
  verifyPasswordResetCode: (code) =>
    ipcRenderer.invoke("verify-password-reset-code", code),
  onWifiStrength: (callback) =>
    ipcRenderer.on("wifi-strength-update", (_event, percent) => callback(percent)),
  getBatteryInfo: () => ipcRenderer.invoke("get-battery-info"),
  onBatteryUpdate: (callback) =>
    ipcRenderer.on("battery-update", (_event, info) => callback(info)),
  onNetworkPanelDiagnosticsUpdate: (callback) =>
    ipcRenderer.on("network-panel-diagnostics-update", (_event, result) =>
      callback(result)
    ),
  setFullScreen: (shouldBeFullScreen) =>
    ipcRenderer.invoke("set-fullscreen", !!shouldBeFullScreen),
  // 軟體更新的全螢幕安裝鎖：安裝開始/結束時通知主行程，安裝中連視窗
  // 關閉（含 Alt+F4）都要擋下，避免使用者中途關程式造成安裝損毀。
  setUpdateInstallLock: (locked) => ipcRenderer.send("update:set-install-lock", !!locked),
  // 啟動驗證：bootloader 切版之後會等這個 ping，30 秒內沒收到就自動
  // 判定「這個版本壞掉了」退回舊版本（見 renderer.js 的
  // checkAppLicenseOnStartup()，通過授權檢查後會呼叫這個）。
  notifyStartupVerified: () => ipcRenderer.invoke("update:startup-verify-ping"),
  // Ctrl+滾輪整體縮放（見 renderer.js 開頭的縮放控制邏輯）：這裡刻意
  // 不是自己在 preload 用 webFrame.setZoomFactor() 處理，因為那樣只會
  // 放大「視窗裡面的網頁內容」，視窗本身的大小完全不變——使用者要的是
  // 「整個應用程式」（連視窗外框）一起變大/變小。真正的視窗尺寸只有
  // main process 的 BrowserWindow 能改，所以改成請 main process
  // （main-bootloader.js 的 set-app-window-scale）同時處理「視窗本身
  // 縮放」跟「裡面內容套用同一個倍率」這兩件事。
  setAppScale: (scale) => ipcRenderer.invoke("set-app-window-scale", scale),
  getAppScale: () => ipcRenderer.invoke("get-app-window-scale"),
});
