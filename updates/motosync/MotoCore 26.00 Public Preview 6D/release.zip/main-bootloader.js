// ============================================================
// MotoSync Bootloader
//
// 這支程式就是「exe 安裝的東西」，本身不含任何業務邏輯（顧客管理、
// 估價單那些畫面），只做：
//   1. 身分驗證（離線金鑰 / Google 登入 / 忘記密碼白名單）
//   2. 版本管理（查詢、下載、驗證、安裝、切換、退回舊版本）
//   3. 決定現在要載入哪一個「軟體邏輯」版本，然後把視窗開起來、
//      把該版本的 main.js 掛進來
//
// 對應設計文件「三、Bootloader 概念」。
// ============================================================

const { app, BrowserWindow, ipcMain, shell, dialog, screen } = require("electron");
const path = require("path");
const http = require("http");
const https = require("https");
const crypto = require("crypto");
const fs = require("fs");

const config = require("./config");
const { UpdateEngine, UpdateError } = require("./update-engine");
const { verifyBossPassword, hasBossPassword, setBossPassword } = require("./boss-auth");

const CHROME_USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
app.userAgentFallback = CHROME_USER_AGENT;

const VERSIONS_DIR = path.join(app.getPath("userData"), "versions");
const engine = new UpdateEngine({ config, baseDir: VERSIONS_DIR });

let mainWindow = null;
let skipCloseConfirmDialog = false;
// 軟體更新「安裝中」鎖：安裝畫面全螢幕鎖定期間設為 true，關閉視窗一律
// 直接擋下（連確認對話框都不跳），避免使用者在安裝到一半時關掉程式
// 造成軟體損毀（見 renderer.js 的 swuEnterFullscreenInstallLock）。
let updateInstallLockActive = false;
let currentAppDir = null; // 目前這次執行期間，實際載入的軟體邏輯資料夾
let currentAppVersion = null;
// Ctrl+滾輪整體縮放用：記住主視窗「原本、100% 時」的大小（也就是
// getAdaptiveWindowSize() 算出來、還沒套用任何縮放倍率的尺寸），
// 縮放時都是拿這組基準尺寸乘上倍率，而不是拿「上一次已經被縮放過」
// 的尺寸再繼續乘，才不會每縮一次誤差疊加、比例慢慢跑掉。
let appWindowBaseSize = null;
let appWindowScale = 1;

// 暫時的除錯記錄：只為了排查「按 X 沒跳出關閉確認畫面」這個問題，
// 之後確認正常後可以整段拿掉。寫在 userData 資料夾裡，使用者用
// 記事本就能直接打開看，不用開發者工具或終端機。
const DEBUG_LOG_PATH = path.join(app.getPath("userData"), "quit-debug.log");
function debugLog(msg) {
  try {
    fs.appendFileSync(
      DEBUG_LOG_PATH,
      `[${new Date().toISOString()}] ${msg}\n`
    );
  } catch (err) {
    // 記錄失敗也不要影響正常流程
  }
}
let startupVerifyTimer = null;

// ============================================================
// 🌐 離線容錯共用工具
//
// Google 登入、老闆密碼設定檢查這兩步都需要連網，原本完全沒有離線
// 判斷：沒網路時，Google 登入畫面打不開/轉不出授權碼會一直卡住等使用者
// 自己放棄，或是網路請求丟出例外被當成「登入失敗」直接 app.quit()——
// 不管是哪一種，結果都是「沒網路就開不了機」，即使本機其實已經裝好、
// 能離線正常運作的版本也一樣。下面兩個函式讓 boot() 可以：
//   1. hasNetworkConnectivity()：在真的跳出 Google 登入視窗之前，先花
//      最多幾秒鐘判斷「現在到底有沒有網路」，不用等 OAuth 逾時才知道。
//   2. withTimeout()：幫任何一個「理論上需要連網、但沒有自帶逾時」的
//      非同步操作加一個明確的逾時上限，避免真的卡死整個開機流程。
// ============================================================

// 打一個很小的連線探測請求（Google 的連通性偵測端點，回應快、幾乎
// 不耗流量），限制在 timeoutMs 內一定要有結果，逾時或任何錯誤都視為
// 「沒有網路」，不讓這個判斷本身變成新的卡住點。
function hasNetworkConnectivity(timeoutMs = 4000) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (ok) => {
      if (settled) return;
      settled = true;
      resolve(ok);
    };
    try {
      const req = https.get(
        { hostname: "clients3.google.com", path: "/generate_204", timeout: timeoutMs },
        (res) => {
          res.resume(); // 把回應內容消耗掉，讓 socket 正常釋放，不留著不管
          finish(true);
        }
      );
      req.on("timeout", () => {
        req.destroy();
        finish(false);
      });
      req.on("error", () => finish(false));
    } catch (err) {
      finish(false);
    }
  });
}

// 幫任何一個 Promise 加上逾時：逾時就 reject，不影響原本的 Promise
// 繼續在背景跑（例如 Google 登入視窗使用者可能還在慢慢輸入帳密），
// 只是 boot() 這裡不會繼續傻等，逾時之後會依「本機有沒有可離線開機的
// 版本」決定要繼續離線開機，還是顯示錯誤退出。
function withTimeout(promise, ms, timeoutMessage) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(timeoutMessage || `操作逾時（超過 ${ms}ms）`));
    }, ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      }
    );
  });
}

// Google 登入是使用者要主動在瀏覽器裡操作的（輸入帳密、可能還有兩步驟
// 驗證），給比較長的時間；老闆密碼設定檢查只是一個 REST API 呼叫，
// 正常有網路的話應該幾秒內就有結果，逾時上限給短一點，才不會讓「其實
// 已經斷線」的情況一直卡到 3 分鐘才被發現。
const GOOGLE_SIGNIN_TIMEOUT_MS = 3 * 60 * 1000;
const BOSS_PASSWORD_CHECK_TIMEOUT_MS = 10 * 1000;

// ============================================================
// 🖥️ 依螢幕大小自動決定視窗尺寸（比例固定，不會變形）
//
// 原本視窗大小是寫死的 1140x810。在解析度比較小的電腦上（例如常見的
// 1366x768 筆電，扣掉工作列後可用高度可能還不到 810），視窗會比可用
// 畫面還高，一開起來就被螢幕邊界卡住、下面內容看不到、也拖不動（因為
// resizable 本來就是 false）。
//
// 做法：把 1140x810 當作「設計時的標準大小」（也是長寬比的基準：
// 1140:810），開視窗之前先讀目前螢幕扣掉工作列/Dock 之後的可用範圍，
// 如果標準大小放不下，就依照同一個長寬比等比縮小到剛好放得下為止；
// 螢幕夠大的話（一般桌上型螢幕都夠），維持原本 1140x810，不會反過來
// 被放大成比原本設計還大、比例當然也完全不變——單純等比縮放，不是
// 分別調整寬高，所以畫面配置不會跑掉、變形。
// ============================================================
const BASE_WINDOW_WIDTH = 1140;
const BASE_WINDOW_HEIGHT = 810;
const WINDOW_ASPECT_RATIO = BASE_WINDOW_WIDTH / BASE_WINDOW_HEIGHT;

function getAdaptiveWindowSize() {
  try {
    const display = screen.getPrimaryDisplay();
    const workArea = display.workAreaSize; // 已經扣掉工作列/Dock，是「真的可以拿來放視窗」的範圍

    // 螢幕邊緣留一點餘裕（90%），避免視窗剛好頂到工作列或螢幕邊界，
    // 看起來太擠、標題列貼著頂端不好拖動。
    const maxWidth = workArea.width * 0.9;
    const maxHeight = workArea.height * 0.9;

    // 寬度、高度兩個限制都要同時滿足，取比較嚴格（縮得比較多）的那個
    // 倍率；並且不超過 1——螢幕夠大時就維持原本設計大小，不會放大。
    const scale = Math.min(1, maxWidth / BASE_WINDOW_WIDTH, maxHeight / BASE_WINDOW_HEIGHT);

    const width = Math.round(BASE_WINDOW_WIDTH * scale);
    // 高度用「寬度 ÷ 比例」反推，而不是各自獨立乘 scale 後四捨五入，
    // 避免兩次四捨五入誤差讓比例跑掉（雖然機率很低，但這樣寫比較嚴謹）。
    const height = Math.round(width / WINDOW_ASPECT_RATIO);

    debugLog(
      `getAdaptiveWindowSize：螢幕可用範圍 ${workArea.width}x${workArea.height}，` +
        `scale=${scale.toFixed(3)}，最終視窗尺寸 ${width}x${height}`
    );
    return { width, height };
  } catch (err) {
    // screen 模組理論上不會失敗，但萬一真的拿不到螢幕資訊，退回原本
    // 寫死的預設值，不要讓開機流程因為這個卡住。
    debugLog(`getAdaptiveWindowSize 失敗，改用預設尺寸：${err.message}`);
    return { width: BASE_WINDOW_WIDTH, height: BASE_WINDOW_HEIGHT };
  }
}

// ============================================================
// 🔍 Ctrl + 滾輪：整個應用程式縮放（視窗本身變大/變小，不是只把
// 視窗裡面的內容放大塞在同一個固定大小的視窗框裡）
//
// 因為視窗本身 resizable 是 false（開機時用 getAdaptiveWindowSize()
// 依螢幕大小算好一個固定尺寸，見上面那段），所以「整個應用程式」的
// 縮放要做兩件事，缺一不可：
//   1. 真的去改變視窗本身的尺寸（BrowserWindow.setSize），讓視窗在
//      螢幕上看起來變大/變小——這是使用者講的「整個應用程式縮放」，
//      不是縮放裡面的網頁內容。
//   2. 同時用 webContents.setZoomFactor() 把裡面的網頁內容也用同一個
//      倍率放大/縮小，這樣網頁版面才會剛好填滿變大/變小之後的視窗，
//      而不是視窗變大了、裡面內容還是原本那麼大，只是四周多出一圈
//      空白（那樣就變成「裡面的東西沒變、只有外框變大」，不是使用者
//      要的效果）。
// 兩者用同一個倍率，所以視窗跟裡面的內容永遠是 1:1 貼合，版面彼此的
// 比例（長寬比、每個元素相對位置）完全不變，只有整體顯示的百分比在變。
//
// 每次都是拿 appWindowBaseSize（開機時、100% 時的原始尺寸）去乘上
// 目前的倍率，而不是拿「上一次縮放後」的尺寸再繼續乘，避免多次縮放
// 之后因為四捨五入誤差疊加、長寬比慢慢跑掉。
// ============================================================
const APP_SCALE_MIN = 0.5;
const APP_SCALE_MAX = 2.0;

// 縮放上限還要看目前螢幕放不放得下：不能讓視窗放大到超出螢幕範圍、
// 使用者反而看不到、拖不動（resizable 是 false，使用者自己也搬不動）。
// 邏輯跟 getAdaptiveWindowSize() 算「開機初始尺寸」時一樣，抓螢幕可用
// 範圍的 95% 當上限，反推出「這個螢幕最多能放大到幾倍」。
function getMaxScaleForCurrentScreen() {
  if (!appWindowBaseSize) return APP_SCALE_MAX;
  try {
    const display = mainWindow
      ? screen.getDisplayMatching(mainWindow.getBounds())
      : screen.getPrimaryDisplay();
    const workArea = display.workAreaSize;
    const maxWidth = workArea.width * 0.95;
    const maxHeight = workArea.height * 0.95;
    const screenLimit = Math.min(
      maxWidth / appWindowBaseSize.width,
      maxHeight / appWindowBaseSize.height
    );
    return Math.max(APP_SCALE_MIN, Math.min(APP_SCALE_MAX, screenLimit));
  } catch (err) {
    debugLog(`getMaxScaleForCurrentScreen 失敗，改用預設上限：${err.message}`);
    return APP_SCALE_MAX;
  }
}

ipcMain.handle("set-app-window-scale", (event, requestedScale) => {
  if (!mainWindow || mainWindow.isDestroyed() || !appWindowBaseSize) {
    return { scale: appWindowScale };
  }

  const maxScale = getMaxScaleForCurrentScreen();
  const clamped = Math.min(maxScale, Math.max(APP_SCALE_MIN, requestedScale));
  const rounded = Math.round(clamped * 100) / 100;

  const newWidth = Math.round(appWindowBaseSize.width * rounded);
  // 高度用「寬度 ÷ 基準比例」反推（不是分別各自乘倍率再四捨五入），
  // 理由跟 getAdaptiveWindowSize() 一樣：避免兩次四捨五入誤差讓長寬比
  // 跑掉。
  const baseAspectRatio = appWindowBaseSize.width / appWindowBaseSize.height;
  const newHeight = Math.round(newWidth / baseAspectRatio);

  // resizable 雖然是 false，但那只擋「使用者用滑鼠拖曳邊框」，程式自己
  // 呼叫 setSize() 一樣有效；不過視窗建立時設過 minWidth/maxWidth 鎖死
  // 在原始尺寸，所以要縮放之前，要先放寬這兩個限制到新的尺寸，
  // setSize() 才不會被自己先前設的上下限卡住、縮放不了。
  mainWindow.setMinimumSize(newWidth, newHeight);
  mainWindow.setMaximumSize(newWidth, newHeight);
  mainWindow.setSize(newWidth, newHeight, true);
  // 從畫面中心變大/變小，感覺才會像「整個應用程式」在縮放，而不是
  // 視窗固定左上角、只往右下角長大，導致視窗跑出螢幕範圍外。
  mainWindow.center();

  // 視窗裡面的網頁內容也套用同一個倍率，讓內容剛好貼合縮放後的視窗，
  // 版面比例維持不變、只是顯示的百分比變了。
  mainWindow.webContents.setZoomFactor(rounded);

  appWindowScale = rounded;
  return { scale: rounded };
});

ipcMain.handle("get-app-window-scale", () => ({ scale: appWindowScale }));

// 只有在「本機有可以離線開機的版本」而且「重新確認過，此時此刻真的
// 沒有網路」這兩個條件同時成立時，才放行讓開機流程跳過 Google 登入／
// 老闆密碼檢查繼續往下走。刻意不是「只要這一步失敗就放行」——例如
// 使用者自己在登入視窗按取消、Google 帳號本身設定有問題，這些失敗
// 跟「有沒有網路」無關，即使本機有快取版本，也不該因此悄悄跳過身分
// 驗證，維持原本「明確告知失敗、結束程式」的行為，避免變成一個可以
// 繞過登入的漏洞。
async function shouldFallbackToOfflineBoot(hasCachedVersion) {
  if (!hasCachedVersion) return false;
  const stillOnline = await hasNetworkConnectivity();
  return !stillOnline;
}

// ============================================================
// 一、離線登入授權金鑰（原本在 main.js，身分驗證相關，
// 依三層分類原則搬到 bootloader，永遠不會被線上更新動到）
// ============================================================

function offlineLicenseCanonicalString(license) {
  return [
    license.shop || "",
    license.issuedAt || "",
    license.expiresAt || "",
    license.deviceNote || "",
    license.exeHash || "",
  ].join("|");
}

// ⚠️ exeHash 綁的是 config.licenseLockVersion（一個「刻意才手動改」的
// 鎖版本值），不是 package.json 的 version——這樣 bootloader 日常打包、
// 版本號正常往上跳的時候，已經核發出去的舊金鑰不會跟著全部失效。
// 必須跟 generate-license.js 的 currentExeHash() 逐字一致。
const DEVICE_LOCK_ID = crypto
  .createHash("sha256")
  .update(`${config.deviceLockSalt}|${config.licenseLockVersion}`)
  .digest("hex");

function currentExeHash() {
  return DEVICE_LOCK_ID;
}

// Ed25519 公鑰只需要解析一次；config.js 裡的格式不對的話，讓程式一
// 啟動就用明確的錯誤訊息炸掉，比每次驗證金鑰時才發現要好排查。
let offlineLicensePublicKeyObject = null;
try {
  offlineLicensePublicKeyObject = crypto.createPublicKey(config.offlineLicensePublicKey);
} catch (err) {
  throw new Error(
    `config.js 的 offlineLicensePublicKey 格式不正確，無法解析成 Ed25519 公鑰：${err.message}`
  );
}

function verifyOfflineLicenseFile(filePath) {
  const raw = fs.readFileSync(filePath, "utf8");
  const license = JSON.parse(raw);

  if (!license || typeof license !== "object" || !license.sig) {
    throw new Error("金鑰檔案格式不正確");
  }

  // 非對稱簽章驗證：generate-license.js 用私鑰對 canonical string 簽出
  // 一段 hex 字串（crypto.sign(null, buffer, privateKey)），這裡用公鑰
  // 反向驗證這段簽章是不是真的由那把私鑰簽出來的、且內容沒被改過。
  let sigBuffer;
  try {
    sigBuffer = Buffer.from(license.sig, "hex");
  } catch (err) {
    throw new Error("金鑰檔案格式不正確（簽章不是合法的 hex 字串）");
  }

  const isValid = crypto.verify(
    null,
    Buffer.from(offlineLicenseCanonicalString(license), "utf8"),
    offlineLicensePublicKeyObject,
    sigBuffer
  );

  if (!isValid) {
    throw new Error("金鑰檔案無效（簽章不符）");
  }

  if (license.expiresAt) {
    const expiresAt = new Date(license.expiresAt).getTime();
    if (!Number.isNaN(expiresAt) && Date.now() > expiresAt) {
      throw new Error("金鑰已過期，請聯絡管理者重新核發");
    }
  }

  if (license.exeHash) {
    const actualHash = currentExeHash();
    if (!actualHash || actualHash.toLowerCase() !== String(license.exeHash).toLowerCase()) {
      throw new Error("這把金鑰是為其他版本的安裝程式產生的，無法在這個版本使用");
    }
  }

  return license;
}

function offlineLicenseStoragePath() {
  return path.join(app.getPath("userData"), "offline-license.app");
}

// ============================================================
// 🗂️ 「關於軟體」專用快照檔：只在開機驗證（checkAppLicenseOnStartup）
// 那一次 resolveLicense() 成功／失敗之後寫一次，之後「關於軟體」頁面
// 一律只讀這份快照，不再自己重新呼叫 resolveLicense() 重新掃一次
// offline-license 資料夾。
//
// 原因：resolveLicense() 內部的 findValidLicenseInFolder() 是「資料夾
// 裡第一個驗證得過的 .app 就用它」，如果資料夾裡不小心留了不只一個
// 能通過簽章驗證的 .app（例如舊金鑰、別家店的金鑰忘記清掉），每次
// 重新掃描挑到的檔案理論上都可能不是使用者以為的那一把。改成「開機
// 那次掃描出來的結果」是唯一真相來源、寫成檔案存起來，「關於軟體」
// 頁面看到的永遠跟「這次開機、這個當下真正在跑」的授權金鑰一致，不會
// 因為之後又讀一次資料夾而顯示出不一樣的店家。
// ============================================================
function activeLicenseSnapshotPath() {
  return path.join(app.getPath("userData"), "active-license-snapshot.json");
}

function writeActiveLicenseSnapshot(result) {
  try {
    fs.writeFileSync(
      activeLicenseSnapshotPath(),
      JSON.stringify({ ...result, resolvedAt: new Date().toISOString() }),
      "utf8"
    );
  } catch (err) {
    // 快照寫檔失敗不影響本次開機（開機驗證用的是 resolveLicense() 當下
    // 的結果，不依賴這份快照），只是「關於軟體」頁之後可能讀不到資料。
  }
}

function offlineLicenseFolder() {
  const dir = path.join(path.dirname(process.execPath), "offline-license");
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function findValidLicenseInFolder() {
  const dir = offlineLicenseFolder();
  const files = fs.readdirSync(dir).filter((name) => name.toLowerCase().endsWith(".app"));
  let lastError = null;
  for (const name of files) {
    try {
      const license = verifyOfflineLicenseFile(path.join(dir, name));
      return { filePath: path.join(dir, name), license };
    } catch (err) {
      lastError = err;
    }
  }
  if (lastError) throw lastError;
  return null;
}

// ============================================================
// 🩹 治本：資料夾（offline-license）永遠是「真相來源」，userData 裡的
// offline-license.app 只是備援快取，不能反過來蓋過資料夾。
//
// 原本的寫法是「userData 有快取、驗證得過，就直接用快取，完全不看
// 資料夾」。這在「這台電腦的 userData 是從別家店複製/還原過來的」
// 這種情況下會出事：快取本身簽章合法（因為它本來就是別家店的合法
// 金鑰），所以會一直被判定「驗證通過」而優先使用，即使有人事後把
// 這家店正確的 .app 檔案放進 offline-license 資料夾也沒用，因為
// 程式根本不會走到「讀資料夾」那一步。
//
// 改成每次都先看資料夾：
//   1. 資料夾裡有驗證得過的 .app → 一律用它，並覆蓋掉 userData 快取
//      （不管 userData 快取原本是什麼、是不是別家店的，都會被蓋掉）
//   2. 資料夾裡的檔案都驗證不過（格式錯/簽章錯/過期/版本不符）→
//      記住這個錯誤，但不要馬上回報失敗，改去看 userData 快取還能
//      不能用（例如金鑰隨身碟一時沒插、或資料夾檔案被誤刪的過渡期）
//   3. 資料夾根本沒有任何 .app 檔案 → 一樣退回看 userData 快取
//   4. 兩邊都沒有可用的金鑰 → 資料夾那邊如果有明確錯誤原因，優先把
//      那個錯誤丟出去（比「找不到金鑰檔案」更精確，方便排查）
// ============================================================
function resolveLicense() {
  const savedPath = offlineLicenseStoragePath();

  let folderResult = null;
  let folderError = null;
  try {
    folderResult = findValidLicenseInFolder();
  } catch (err) {
    folderError = err;
  }

  if (folderResult) {
    // 資料夾裡有合法金鑰：這才是真相來源，直接用，並且不管 userData
    // 快取原本是什麼（自己的舊版、還是別家店殘留的），一律覆蓋掉。
    try {
      fs.copyFileSync(folderResult.filePath, savedPath);
    } catch (e) {
      // 覆蓋快取失敗不影響這次啟動照樣能用資料夾裡的金鑰，只是下次
      // 資料夾檔案被移除時會少一份備援，不用因此整個開機流程失敗。
    }
    return folderResult.license;
  }

  // 資料夾沒有可用金鑰（不管是完全沒有檔案、還是有檔案但都驗證不過），
  // 退回看 userData 裡的舊快取還能不能用，當作過渡期的備援。
  if (fs.existsSync(savedPath)) {
    try {
      return verifyOfflineLicenseFile(savedPath);
    } catch (err) {
      try {
        fs.unlinkSync(savedPath);
      } catch (e) {}
    }
  }

  // 兩邊都沒有可用金鑰：如果資料夾那邊有明確的錯誤原因（例如「簽章
  // 不符」「已過期」），把那個原因丟出去，比籠統的「找不到金鑰檔案」
  // 更方便排查；資料夾單純是空的話才回傳 null，交給呼叫端顯示
  // 「找不到金鑰檔案」。
  if (folderError) throw folderError;
  return null;
}

ipcMain.handle("check-app-license", async () => {
  let result;
  try {
    const license = resolveLicense();
    if (!license) {
      result = {
        ok: false,
        reason: "找不到金鑰檔案，請把授權金鑰（.app）放進 offline-license 資料夾",
      };
    } else {
      // key 給「關於軟體」頁顯示＋複製用：直接用這把金鑰檔案本身的簽章（sig）當作
      // 顯示用的授權金鑰字串——每家店的 .app 金鑰簽章都不一樣，一樣是動態從
      // 金鑰檔案讀出來的，不是寫死在程式碼裡的值。
      result = {
        ok: true,
        shop: license.shop || null,
        expiresAt: license.expiresAt || null,
        key: license.sig || null,
      };
    }
  } catch (err) {
    // 金鑰檔案存在但無效（簽章不符／已過期／對應到其他版本）
    result = { ok: false, reason: err.message || "金鑰檔案無效" };
  }
  // 這是開機驗證（checkAppLicenseOnStartup）唯一會呼叫這個 handler 的
  // 時機，把這次的結果寫成快照，之後「關於軟體」頁一律讀快照，見下面
  // get-about-software-info。
  writeActiveLicenseSnapshot(result);
  return result;
});

// 「關於軟體」頁專用：只讀開機那次寫下的快照，不再重新掃 offline-license
// 資料夾，避免資料夾裡有一個以上能驗證通過的 .app 時，每次重新掃描
// 挑到的檔案跟開機當下實際在用的不一致。
ipcMain.handle("get-about-software-info", async () => {
  try {
    const raw = fs.readFileSync(activeLicenseSnapshotPath(), "utf8");
    return JSON.parse(raw);
  } catch (err) {
    return {
      ok: false,
      reason: "尚未讀取到開機授權快照，請重新啟動程式後再試一次",
    };
  }
});

ipcMain.handle("offline-login", async () => {
  const folder = offlineLicenseFolder();
  let license;
  try {
    license = resolveLicense();
  } catch (err) {
    shell.openPath(folder);
    throw new Error(
      `資料夾裡的金鑰檔案無效（${err.message}），已幫你打開 offline-license 資料夾，請確認裡面的 .app 檔案是否正確`
    );
  }
  if (!license) {
    shell.openPath(folder);
    throw new Error("找不到金鑰檔案，已幫你打開 offline-license 資料夾，請把 .app 金鑰檔案放進去");
  }
  return { ok: true, shop: license.shop || null, expiresAt: license.expiresAt || null };
});

// ============================================================
// 二、Google 登入（身分驗證，搬到 bootloader，原理跟原本
// main.js 完全相同：系統瀏覽器 + 本機小伺服器接回授權碼）
// ============================================================

function base64url(buffer) {
  return buffer.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function createOAuthCallbackServer() {
  return new Promise((resolveServer) => {
    let resolveCode, rejectCode;
    const codePromise = new Promise((res, rej) => {
      resolveCode = res;
      rejectCode = rej;
    });
    const server = http.createServer((req, res) => {
      const reqUrl = new URL(req.url, "http://127.0.0.1");
      if (reqUrl.pathname !== "/callback") {
        res.writeHead(404);
        res.end();
        return;
      }
      const code = reqUrl.searchParams.get("code");
      const error = reqUrl.searchParams.get("error");
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(
        error
          ? `<html><body style="font-family:-apple-system,Arial,sans-serif;text-align:center;margin-top:100px;"><h2>登入已取消</h2><p>您可以關閉這個分頁，回到「永鑫機車系統」應用程式。</p></body></html>`
          : `<html><body style="font-family:-apple-system,Arial,sans-serif;text-align:center;margin-top:100px;"><h2>登入成功</h2><p>請關閉這個分頁，回到「永鑫機車系統」應用程式繼續操作。</p></body></html>`
      );
      setTimeout(() => server.close(), 500);
      if (code) resolveCode(code);
      else rejectCode(new Error(error || "no_code_returned"));
    });
    server.listen(0, "127.0.0.1", () => {
      resolveServer({ port: server.address().port, codePromise });
    });
  });
}

function exchangeCodeForTokens(code, codeVerifier, redirectUri) {
  return new Promise((resolve, reject) => {
    const postData = new URLSearchParams({
      code,
      client_id: config.googleClientId,
      client_secret: config.googleClientSecret,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
      code_verifier: codeVerifier,
    }).toString();

    const req = https.request(
      {
        hostname: "oauth2.googleapis.com",
        path: "/token",
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Content-Length": Buffer.byteLength(postData),
        },
      },
      (res) => {
        let body = "";
        res.on("data", (chunk) => (body += chunk));
        res.on("end", () => {
          try {
            const json = JSON.parse(body);
            if (json.error) reject(new Error(json.error_description || json.error));
            else resolve(json);
          } catch (e) {
            reject(e);
          }
        });
      }
    );
    req.on("error", reject);
    req.write(postData);
    req.end();
  });
}

// 抽成獨立函式，因為現在有兩個地方需要「跳出瀏覽器叫使用者用 Google
// 登入」：(1) 軟體邏輯層原本的 google-login IPC，(2) 下面 boot 流程裡
// 「先登入 Google 再去讀老闆密碼設定」的 ensureGoogleSignedIn。
async function doGoogleOAuthLogin() {
  const { port, codePromise } = await createOAuthCallbackServer();
  const redirectUri = `http://127.0.0.1:${port}/callback`;
  const codeVerifier = base64url(crypto.randomBytes(64));
  const codeChallenge = base64url(crypto.createHash("sha256").update(codeVerifier).digest());

  const authUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  authUrl.searchParams.set("client_id", config.googleClientId);
  authUrl.searchParams.set("redirect_uri", redirectUri);
  authUrl.searchParams.set("response_type", "code");
  authUrl.searchParams.set("scope", "openid email profile");
  authUrl.searchParams.set("code_challenge", codeChallenge);
  authUrl.searchParams.set("code_challenge_method", "S256");
  authUrl.searchParams.set("prompt", "select_account");

  await shell.openExternal(authUrl.toString());

  try {
    const code = await codePromise;
    const tokens = await exchangeCodeForTokens(code, codeVerifier, redirectUri);
    if (mainWindow) mainWindow.focus();
    return { idToken: tokens.id_token, accessToken: tokens.access_token };
  } catch (err) {
    if (mainWindow) mainWindow.focus();
    throw err;
  }
}

ipcMain.handle("google-login", () => doGoogleOAuthLogin());

// ============================================================
// 二之一、把 Google 的 id_token 換成分店 Firebase 的 idToken
//
// Google OAuth 給的 id_token，Firebase Realtime Database 的安全規則
// 看不懂（規則檢查的是 Firebase Auth 的 idToken，不是 Google 原生的
// id_token）。要讓 boss-auth.js 的 REST 呼叫在「規則要求已登入」的
// 情況下通過，得先拿 Google id_token 去打 Identity Toolkit 的
// signInWithIdp，換成這家分店 Firebase 專案自己的 idToken，之後
// REST 呼叫網址加上 ?auth=<這個 idToken> 才會被規則放行。
//
// 前提：分店的 Firebase 專案（Authentication → Sign-in method）要
// 開啟 Google 登入方式，且允許的網域/OAuth 用戶端要對得起來。
// ============================================================
function exchangeGoogleIdTokenForFirebaseIdToken(shopFirebaseConfig, googleIdToken) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      postBody: `id_token=${googleIdToken}&providerId=google.com`,
      requestUri: "http://localhost",
      returnIdpCredential: true,
      returnSecureToken: true,
    });
    const req = https.request(
      {
        hostname: "identitytoolkit.googleapis.com",
        path: `/v1/accounts:signInWithIdp?key=${encodeURIComponent(shopFirebaseConfig.apiKey)}`,
        method: "POST",
        headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) },
      },
      (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            const json = JSON.parse(data);
            if (json.error) {
              reject(new Error(json.error.message || "Firebase 登入交換失敗"));
              return;
            }
            resolve(json.idToken); // 這個才是 REST 呼叫要用的 ?auth= 值
          } catch (err) {
            reject(err);
          }
        });
      }
    );
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

// 這次執行期間換到的 Firebase idToken，boss-auth.js 的呼叫都會帶上它
let shopFirebaseIdToken = null;

// ============================================================
// 一之一、開機一開始先叫使用者用 Google 帳號登入，換到分店 Firebase
// 的 idToken，之後 ensureBossPasswordConfigured / 重灌驗證密碼時的
// REST 呼叫才有辦法通過「已登入才能讀寫」的 Firebase 規則。
// ============================================================
function ensureGoogleSignedIn(win) {
  return new Promise((resolve, reject) => {
    debugLog("ensureGoogleSignedIn：送出 boot:need-google-signin");
    win.webContents.send("boot:need-google-signin");

    function registerHandler() {
      ipcMain.handleOnce("boot:google-signin", async () => {
        debugLog("收到 renderer 呼叫 boot:google-signin（使用者按了登入按鈕）");
        try {
          const { idToken: googleIdToken } = await doGoogleOAuthLogin();
          shopFirebaseIdToken = await exchangeGoogleIdTokenForFirebaseIdToken(
            config.shopFirebaseConfig,
            googleIdToken
          );
          debugLog("Google 登入 + Firebase idToken 交換成功");
          resolve();
          return { ok: true };
        } catch (err) {
          debugLog(`Google 登入流程失敗：${err.message}`);
          registerHandler();
          return { ok: false, error: err.message };
        }
      });
    }
    registerHandler();
  });
}

// ============================================================
// 三、忘記密碼驗證碼信件（白名單查詢 + 驗證碼產生/驗證 + 寄信，
// 全部搬到 motosync-reset-backend，exe 本身不持有 Gmail 帳密、
// 不持有白名單、甚至不知道驗證碼本身，只保管一個伺服器簽章過的
// token，驗證時把 token 跟使用者輸入的碼一起送回後端比對。
// 對應 https://github.com/yonghong0333-ops/motosync-reset-backend
// 的 api/send-reset-code.js 與 api/verify-reset-code.js）
// ============================================================

function callResetBackend(pathname, payload) {
  return new Promise((resolve, reject) => {
    let backendUrl;
    try {
      backendUrl = new URL(pathname, config.resetBackend.url);
    } catch (e) {
      reject(new Error("resetBackend.url 設定不正確：" + e.message));
      return;
    }

    const postData = JSON.stringify(payload);
    const req = https.request(
      {
        hostname: backendUrl.hostname,
        path: backendUrl.pathname + backendUrl.search,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(postData),
          "x-api-key": config.resetBackend.apiKey,
        },
      },
      (res) => {
        let body = "";
        res.on("data", (chunk) => (body += chunk));
        res.on("end", () => {
          try {
            const json = body ? JSON.parse(body) : {};
            resolve({ statusCode: res.statusCode, json });
          } catch (e) {
            reject(new Error("後端回應格式錯誤：" + e.message));
          }
        });
      }
    );
    req.on("error", reject);
    req.write(postData);
    req.end();
  });
}

// 這次密碼重設流程拿到的 token（簽章字串，碼本身包在裡面，exe 看不懂
// 也不需要看懂），驗證時要跟使用者輸入的碼一起送回後端。
let pendingResetToken = null;

ipcMain.handle("send-password-reset-code", async (event, recipientEmail, purpose) => {
  const normalizedRecipient = String(recipientEmail || "").trim().toLowerCase();
  pendingResetToken = null;

  try {
    const { statusCode, json: result } = await callResetBackend("/api/send-reset-code", {
      email: normalizedRecipient,
      purpose: purpose || "reset",
      // 各分店自己的 Firebase Realtime Database 網址，後端會去查
      // {firebaseDbUrl}/appSettings/allowedResetEmails.json 這個白名單
      // 節點，判斷這個信箱能不能收驗證碼。
      firebaseDbUrl: config.shopFirebaseConfig.databaseURL,
    });

    if (statusCode !== 200 || !result || result.ok !== true) {
      return { ok: false, error: (result && result.error) || `send_failed(${statusCode})` };
    }

    pendingResetToken = result.token;
    return { ok: true, letterOptions: result.letterOptions };
  } catch (err) {
    console.error("寄送驗證碼失敗：", err);
    pendingResetToken = null;
    return { ok: false, error: err.message };
  }
});

ipcMain.handle("verify-password-reset-code", async (event, inputCode) => {
  if (!pendingResetToken) return { ok: false, reason: "no_code" };

  try {
    const { statusCode, json: result } = await callResetBackend("/api/verify-reset-code", {
      token: pendingResetToken,
      code: String(inputCode || "").trim().toUpperCase(),
    });

    if (statusCode !== 200 || !result) {
      return { ok: false, reason: "verify_failed" };
    }
    // 不論成功、失敗（碼錯、過期、被竄改）都消耗掉這個 token，
    // 跟原本「本機比對完就清掉」的行為一致，避免同一個 token 被
    // 一直拿去猜碼。
    pendingResetToken = null;
    if (result.ok === true) return { ok: true };
    return { ok: false, reason: result.reason || "wrong" };
  } catch (err) {
    console.error("驗證驗證碼失敗：", err);
    pendingResetToken = null;
    return { ok: false, reason: "verify_failed" };
  }
});

// ============================================================
// 四、更新系統 IPC（對應設計文件 七、F12 頁面 + 六、密碼保護節點）
// ============================================================

ipcMain.handle("update:get-current-version", () => {
  return { version: currentAppVersion };
});

// 全螢幕安裝畫面進出時呼叫：見 preload.js 的 setUpdateInstallLock、
// renderer.js 的 swuEnterFullscreenInstallLock / swuExitFullscreenInstallLock。
ipcMain.on("update:set-install-lock", (event, locked) => {
  updateInstallLockActive = !!locked;
  debugLog(`updateInstallLockActive set to ${updateInstallLockActive}`);
});

// 不用密碼：單純查詢有沒有新版本
ipcMain.handle("update:check", async () => {
  try {
    const latest = await engine.fetchLatestVersion();
    const release = await engine.fetchReleaseJson(latest);
    return {
      ok: true,
      currentVersion: currentAppVersion,
      latestVersion: latest,
      hasUpdate: latest !== currentAppVersion,
      title: release.title || "",
      icon: release.icon || null,
      changelog: release.changelog || "",
      forceUpdate: !!release.forceUpdate,
      sizeBytes: release.sizeBytes || null,
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// 節點 1：按「開始更新」→ 密碼 → 觸發下載
ipcMain.handle("update:start-download", async (event, { password, version }) => {
  const auth = await verifyBossPassword(config.shopFirebaseConfig, password, shopFirebaseIdToken);
  if (!auth.ok) return { ok: false, error: "password_" + auth.reason };

  try {
    const release = await engine.fetchReleaseJson(version);
    const zipPath = await engine.downloadRelease(release, (percent, received, total) => {
      if (mainWindow) {
        mainWindow.webContents.send("update:download-progress", { percent, received, total });
      }
    });
    return { ok: true, zipPath, release };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// 節點 2：按「立即安裝」→ 密碼 → 鎖畫面安裝流程（解壓/驗證/rename）
ipcMain.handle("update:install", async (event, { password, version, zipPath }) => {
  const auth = await verifyBossPassword(config.shopFirebaseConfig, password, shopFirebaseIdToken);
  if (!auth.ok) return { ok: false, error: "password_" + auth.reason };

  try {
    const release = await engine.fetchReleaseJson(version);
    const newDir = await engine.installToNewFolder(release, zipPath);
    const previousVersion = currentAppVersion;
    engine.switchToVersion(version, { previousVersion });

    // 切換完就重啟整個程式，下次開機會直接載入新版本並做啟動驗證。
    setTimeout(() => {
      app.relaunch();
      app.exit(0);
    }, 300);

    return { ok: true, newDir };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// 節點 3：重灌時選擇要安裝「先前系統」還是「最新系統」→ 密碼
ipcMain.handle("update:reinstall-choose", async (event, { password, choice }) => {
  // choice: "previous" | "latest"
  const auth = await verifyBossPassword(config.shopFirebaseConfig, password, shopFirebaseIdToken);
  if (!auth.ok) return { ok: false, error: "password_" + auth.reason };
  return { ok: true };
});

// 「清除所有設定內容（原廠設定）」的最後一步：把本機這個 versions 資料夾
// （所有從 GitHub 下載回來的版本安裝包 .downloads、已解壓縮的 app-vX.X.X
// 資料夾、以及版本 marker 檔 current-version.json）整個砍掉。
//
// 密碼／信箱驗證碼已經在 renderer.js 的 confirmDangerDelete() 裡驗證過
// 才會呼叫到這裡，這裡不再重複要求密碼（跟 local-cache-clear 同一個模式）。
//
// 砍完之後 marker 也一起消失，下次開機 decideBootPlan() 會讀不到本機
// marker，自動走「重灌」流程重新從雲端查授權、抓最新版——等於「軟體
// 邏輯層」也回到跟全新安裝一樣的狀態。因為目前這次執行期間的程式碼就是
// 從被刪掉的資料夾裡讀出來的，刪完必須馬上重啟，不能留在原本畫面上
// 繼續動作，所以這裡砍完立刻 relaunch。
ipcMain.handle("factory-reset-clear-versions", async () => {
  try {
    if (fs.existsSync(VERSIONS_DIR)) {
      fs.rmSync(VERSIONS_DIR, { recursive: true, force: true });
    }
    return { ok: true };
  } catch (err) {
    console.error("清除本機 versions 資料夾失敗：", err);
    return { ok: false, error: err.message };
  }
});

// 給「清除所有設定內容」砍完 versions 資料夾之後用：整個 app 重開，
// 不帶密碼檢查（呼叫這裡之前，renderer 那邊已經驗證過密碼＋信箱驗證碼）。
// 跟 update:install 成功後重啟的寫法一樣。
ipcMain.handle("app:relaunch", () => {
  setTimeout(() => {
    app.relaunch();
    app.exit(0);
  }, 300);
  return true;
});

module.exports.__engine = engine; // 給下面的開機流程使用

// ============================================================
// 五、開機流程：決定要載入哪個版本（對應設計文件 三、八）
// ============================================================

async function decideBootPlan() {
  const marker = engine.readMarker();
  const localDir = engine.getCurrentVersionDir();

  if (marker && localDir) {
    // 正常開機：本機已經有可以用的版本，直接載入，不用等網路。
    return { kind: "normal", version: marker.currentVersion };
  }

  // 沒有本機 marker（第一次安裝，或重灌把 userData 也清掉了）：
  // 查雲端 licenses/{key} 決定是「全新開店」還是「重灌」。
  let licenseRecord = null;
  try {
    licenseRecord = await engine.fetchLicenseRecord(shopFirebaseIdToken);
  } catch (err) {
    return { kind: "error", error: `無法連線到更新伺服器查詢授權狀態：${err.message}` };
  }

  if (!licenseRecord || !licenseRecord.currentVersion) {
    // 全新開店：直接抓最新版，走原廠設定流程，不用密碼
    return { kind: "fresh-install" };
  }

  // 重灌情境：本機找不到任何版本，但雲端記得這把金鑰之前裝到哪一版
  return {
    kind: "reinstall",
    previousVersion: licenseRecord.currentVersion,
  };
}

async function performFreshInstallOrUpdate(version, { onProgress } = {}) {
  const release = await engine.fetchReleaseJson(version);
  const zipPath = await engine.downloadRelease(release, onProgress);
  const previousVersion = currentAppVersion;
  await engine.installToNewFolder(release, zipPath);
  engine.switchToVersion(version, { previousVersion });
}

// 原則六：每次開機比對本機版本 vs 雲端版本，自我校正
async function reconcileVersionWithCloud() {
  try {
    const licenseRecord = await engine.fetchLicenseRecord(shopFirebaseIdToken);
    const cloudVersion = licenseRecord && licenseRecord.currentVersion;
    if (!cloudVersion) return; // 雲端還沒有紀錄，等這次啟動驗證通過再寫

    if (currentAppVersion === cloudVersion) return; // 一致，正常

    if (isVersionLess(currentAppVersion, cloudVersion)) {
      // 本機 < 雲端（例如重灌用了舊安裝檔）→ 自動觸發補更新
      if (mainWindow) {
        mainWindow.webContents.send("update:auto-triggered", { fromVersion: currentAppVersion, toVersion: cloudVersion });
      }
    } else {
      // 本機 > 雲端 → 寫回雲端
      await engine.reportCurrentVersion(currentAppVersion, shopFirebaseIdToken);
    }
  } catch (err) {
    console.error("版本自我校正檢查失敗：", err.message);
  }
}

function isVersionLess(a, b) {
  if (!a) return true;
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na !== nb) return na < nb;
  }
  return false;
}

// ============================================================
// 六、視窗管理（reproduce 原本 createWindow，但改成讀「目前版本
// 資料夾」而不是固定的 __dirname，preload 也改成 bootloader 自己的，
// 由 bootloader preload 內部再去載入該版本自己的 preload.js）
// ============================================================

function startLocalServer(rootDir) {
  return new Promise((resolve) => {
    const MIME = {
      ".html": "text/html; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".json": "application/json; charset=utf-8",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".svg": "image/svg+xml",
      ".ico": "image/x-icon",
    };
    const server = http.createServer((req, res) => {
      let reqPath = decodeURIComponent((req.url || "/").split("?")[0]);
      if (reqPath === "/") reqPath = "/index.html";
      const filePath = path.join(rootDir, reqPath);
      if (!filePath.startsWith(rootDir)) {
        res.writeHead(403);
        res.end("Forbidden");
        return;
      }
      fs.readFile(filePath, (err, data) => {
        if (err) {
          res.writeHead(404);
          res.end("Not found");
          return;
        }
        const ext = path.extname(filePath).toLowerCase();
        res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
        res.end(data);
      });
    });
    server.listen(0, "127.0.0.1", () => resolve(server));
  });
}

async function loadAppVersionIntoWindow(version) {
  const appDir = engine.versionDir(version);
  currentAppDir = appDir;
  currentAppVersion = version;

  const server = await startLocalServer(appDir);
  const port = server.address().port;

  if (!mainWindow) {
    const { width, height } = getAdaptiveWindowSize();
    appWindowBaseSize = { width, height };
    appWindowScale = 1;
    mainWindow = new BrowserWindow({
      width,
      height,
      useContentSize: true,
      // resizable 是 false，min/max 理論上不影響使用者操作，但還是設成
      // 跟目前尺寸一樣，避免 Electron 在某些平台上用舊的寫死下限
      // （1000x700）把已經算好、故意縮小過的尺寸又「校正」回去。
      minWidth: width,
      minHeight: height,
      maxWidth: width,
      maxHeight: height,
      resizable: false,
      autoHideMenuBar: true,
      icon: path.join(__dirname, "build", "icon.ico"),
      show: false,
      webPreferences: {
        preload: path.join(__dirname, "preload.js"),
        contextIsolation: true,
        nodeIntegration: false,
        additionalArguments: [`--motosync-app-preload=${path.join(appDir, "preload.js")}`],
      },
    });

    // 同上一個原因：用 appWindow 記住「這一個」視窗物件本身，避免
    // 前一個視窗（例如 boot 流程的選擇畫面）延遲觸發的 closed 事件
    // 把這個新建的視窗參照誤清成 null。
    const appWindow = mainWindow;
    appWindow.on("closed", () => {
      if (mainWindow === appWindow) mainWindow = null;
    });

    let isQuitConfirmed = false;
    let awaitingQuitConfirm = false;
    mainWindow.on("close", (event) => {
      debugLog(`close event fired. isQuitConfirmed=${isQuitConfirmed} skipCloseConfirmDialog=${skipCloseConfirmDialog} updateInstallLockActive=${updateInstallLockActive}`);
      // 安裝鎖定中：不跳確認對話框、不給任何關閉方式，直接擋下（含
      // Alt+F4 等系統層級關閉），等安裝流程自己解鎖或重啟程式為止。
      if (updateInstallLockActive) {
        event.preventDefault();
        return;
      }
      if (isQuitConfirmed) return;
      if (skipCloseConfirmDialog) {
        isQuitConfirmed = true;
        return;
      }
      event.preventDefault();

      if (awaitingQuitConfirm) return; // 已經跳出來了，等使用者按按鈕，不要重複觸發

      awaitingQuitConfirm = true;
      debugLog("sending motosync:show-quit-confirm to renderer");
      mainWindow.webContents.send("motosync:show-quit-confirm");

      ipcMain.once("quit-confirm-response", (_event, confirmed) => {
        debugLog(`quit-confirm-response received: confirmed=${confirmed}`);
        awaitingQuitConfirm = false;
        if (confirmed) {
          isQuitConfirmed = true;
          mainWindow.close();
        }
      });
    });

    mainWindow.webContents.setWindowOpenHandler(() => ({ action: "allow" }));
    mainWindow.webContents.on("did-create-window", (childWindow) => {
      childWindow.webContents.setUserAgent(CHROME_USER_AGENT);
    });
  }

  mainWindow.webContents.setUserAgent(CHROME_USER_AGENT);
  mainWindow.on("closed", () => server.close());

  // 把該版本的 main.js 掛進來（掛載它自己的業務 IPC handlers）。
  // 一定要在視窗建立「之後」才呼叫，因為它裡面有些 handler
  // （例如另存新檔對話框）一開始就會讀取目前的視窗物件。
  //
  // 這裡包 try/catch 是有事故經驗的：main.js 裡 require 到缺少的
  // 套件（例如上次的 'docx'）、或 main.js 本身結構有問題，都會讓
  // require() 或 registerApp() 同步丟出例外。這種例外原本會一路
  // 往上炸到最外層 app.whenReady().then(...).catch(...)，只顯示
  // 一個「無法啟動」的錯誤框，完全不會嘗試退回舊版本——即使有
  // 好好運作的舊版本可以退，也不會自動救援，只能靠人工去分店電腦
  // 手動清資料夾。改成在這裡直接抓，觸發跟啟動驗證逾時一樣的
  // triggerRollback()，能退就自動退回、重新啟動，不用人工介入。
  let registerApp;
  try {
    registerApp = require(path.join(appDir, "main.js"));
  } catch (err) {
    console.error(`載入版本 ${version} 的 main.js 失敗：`, err);
    debugLog(`載入版本 ${version} 的 main.js 失敗，觸發自動退回：${err.message}`);
    triggerRollback();
    return;
  }

  if (typeof registerApp === "function") {
    try {
      registerApp({
        ipcMain,
        app,
        shell,
        dialog,
        getMainWindow: () => mainWindow,
        appDir,
        shopFirebaseConfig: config.shopFirebaseConfig,
        // ⚠️ 這兩個原本就宣告在 main.js 的 registerApp() 參數裡、也有各自的
        // ipcMain.handle 在等著回傳，卻從來沒有從這裡傳進去——結果
        // get-shop-settings 永遠回傳 {}（Google 登入白名單、估價單店名都
        // 讀不到值），get-license-key 永遠回傳 ""（「關於軟體」頁原本想
        // 顯示的欄位一直是空的）。補上以修正這兩個一直存在的斷點。
        shopSettings: config.shopSettings,
        licenseKey: config.licenseKey,
      });
    } catch (err) {
      console.error(`版本 ${version} 的 main.js 初始化時拋出例外：`, err);
      debugLog(`版本 ${version} 初始化失敗，觸發自動退回：${err.message}`);
      triggerRollback();
      return;
    }
  }

  armStartupVerification(version);
  mainWindow.loadURL(`http://localhost:${port}/index.html`);
  const windowToShow = mainWindow;
  windowToShow.once("ready-to-show", () => {
    if (!windowToShow.isDestroyed()) windowToShow.show();
  });
}

// ------------------------------------------------------------
// 原則五：啟動驗證。版本切換完 relaunch 進新版本後，等該版本的
// renderer 呼叫 update:startup-verify-ping 表示「畫面渲染、Firebase
// 連線、license 讀取都正常」，才算真的成功；逾時或載入失敗就自動
// 退回舊版本並再次 relaunch。
// ------------------------------------------------------------

function armStartupVerification(version) {
  const marker = engine.readMarker();
  if (!marker || marker.currentVersion !== version || marker.startupVerified) {
    return; // 這個版本之前已經驗證通過過，不用重驗
  }

  if (startupVerifyTimer) clearTimeout(startupVerifyTimer);
  startupVerifyTimer = setTimeout(() => {
    console.error(`版本 ${version} 啟動驗證逾時，自動退回舊版本`);
    triggerRollback();
  }, 30000);

  const failHandler = () => {
    clearTimeout(startupVerifyTimer);
    console.error(`版本 ${version} 載入失敗，自動退回舊版本`);
    triggerRollback();
  };
  mainWindow.webContents.once("did-fail-load", failHandler);
}

function triggerRollback() {
  try {
    engine.rollbackToPrevious();
  } catch (err) {
    dialog.showErrorBox(
      "更新失敗且無法退回舊版本",
      `新版本啟動驗證失敗，且${err.message}。請聯絡系統管理者。`
    );
    return;
  }
  app.relaunch();
  app.exit(0);
}

ipcMain.handle("update:startup-verify-ping", () => {
  if (startupVerifyTimer) {
    clearTimeout(startupVerifyTimer);
    startupVerifyTimer = null;
  }
  const marker = engine.readMarker();
  if (marker && marker.currentVersion === currentAppVersion && !marker.startupVerified) {
    engine.markStartupVerified(currentAppVersion);
    if (marker.previousVersion) {
      engine.archiveOldVersion(marker.previousVersion);
    }
    engine.reportCurrentVersion(currentAppVersion, shopFirebaseIdToken).catch((err) => {
      console.error("回報版本到雲端失敗：", err.message);
    });
  }
  // 驗證通過後，順便做一次雲端版本自我校正
  reconcileVersionWithCloud();
  return { ok: true };
});

ipcMain.handle("quit-app", () => {
  skipCloseConfirmDialog = true;
  app.quit();
});

// 暫時的除錯用：preload.js 那邊執行到關鍵步驟時會送這個訊息過來，
// 統一寫進同一份 log 檔，方便排查「關閉確認畫面沒跳出來」的問題。
ipcMain.on("motosync:debug-log", (_event, msg) => {
  debugLog(`[renderer] ${msg}`);
});

// ============================================================
// 六之一、原廠系統初次設定：強制設定老闆密碼
//
// 分店的 Firebase 裡如果還沒有 appSettings/bossPasswordHash（全新
// 分店、第一次安裝），就先擋在 boot.html 上叫老闆設一組密碼，
// 設定完才繼續走正常開機流程（版本檢查/安裝/重灌）。
// 這裡只負責「擋住 + 收密碼 + 寫入」，不管後續版本邏輯。
// ============================================================
function ensureBossPasswordConfigured(win) {
  return new Promise(async (resolve, reject) => {
    let alreadySet;
    try {
      alreadySet = await hasBossPassword(config.shopFirebaseConfig, shopFirebaseIdToken);
    } catch (err) {
      reject(err);
      return;
    }

    if (alreadySet) {
      resolve();
      return;
    }

    win.webContents.send("boot:need-boss-password-setup");

    // 每次送出失敗（密碼不一致 / 寫入失敗）都要重新註冊一次
    // handleOnce，不然使用者在畫面上重試第二次會找不到 handler
    function registerHandler() {
      ipcMain.handleOnce("boot:set-boss-password", async (event, { password, confirmPassword }) => {
        if (String(password || "") !== String(confirmPassword || "")) {
          registerHandler();
          return { ok: false, error: "password_mismatch" };
        }

        const result = await setBossPassword(config.shopFirebaseConfig, password, shopFirebaseIdToken);
        if (!result.ok) {
          registerHandler();
          return result;
        }

        resolve();
        return { ok: true };
      });
    }
    registerHandler();
  });
}

// ============================================================
// 七、開機主流程
// ============================================================
async function boot() {
  debugLog("boot() 開始");
  // 先開一個空白視窗顯示開機畫面（boot.html），決定好版本以後再換掉內容
  const { width: bootWidth, height: bootHeight } = getAdaptiveWindowSize();
  mainWindow = new BrowserWindow({
    width: bootWidth,
    height: bootHeight,
    useContentSize: true,
    // resizable 是 false，min/max 設成跟目前尺寸一樣就好，理由跟
    // loadAppVersionIntoWindow() 那邊一致，見那邊的註解。
    minWidth: bootWidth,
    minHeight: bootHeight,
    maxWidth: bootWidth,
    maxHeight: bootHeight,
    resizable: false,
    autoHideMenuBar: true,
    icon: path.join(__dirname, "build", "icon.ico"),
    webPreferences: {
      preload: path.join(__dirname, "boot-preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  // 用 bootWindow 記住「這一個」視窗物件本身，"closed" 事件是非同步
  // 觸發的（呼叫 .close() 之後不會馬上發生），如果這裡直接清空外層
  // 共用的 mainWindow 變數，遇到「先 close() 這個視窗、緊接著就建立
  // 下一個視窗」的情境（reinstall 選擇流程就是這樣），舊視窗延遲觸發
  // 的 closed 事件有機會在新視窗建立「之後」才發生，把已經指向新視窗
  // 的 mainWindow 誤清成 null——導致新視窗稍後觸發 ready-to-show 時
  // 讀到 mainWindow.show() 的 mainWindow 是 null 而整個崩潰。這裡先
  // 判斷「現在的 mainWindow 是不是還是我自己」，是才清空。
  const bootWindow = mainWindow;
  bootWindow.on("closed", () => {
    if (mainWindow === bootWindow) mainWindow = null;
  });

  // 除錯用：preload.js 如果本身執行時丟例外（例如打包後路徑不對、
  // require 失敗等），Electron 不會讓整個 app 崩潰，也不會有任何
  // 提示，畫面只會停在 boot.html 的靜態內容不動——之前排查「卡在
  // 正在檢查系統版本」的問題一直找不到原因，就是因為沒有攔截這個
  // preload-error 事件，所以完全不知道 preload 到底有沒有跑起來。
  mainWindow.webContents.on("preload-error", (_event, preloadPath, error) => {
    debugLog(`❌ preload 載入失敗！preloadPath=${preloadPath}，error=${error && error.stack ? error.stack : error}`);
  });

  // 除錯用：boot.html 的 <script> 裡任何沒被 catch 到的例外（例如
  // window.bootAPI 是 undefined 導致的 TypeError），瀏覽器層級的
  // console.error 都會經過這個事件送到 main process，一併寫進同一份
  // log，這樣就算 preload 本身沒問題、是 boot.html 的 script 中途
  // 掛掉，也查得到原因。
  mainWindow.webContents.on("console-message", (_event, level, message, line, sourceId) => {
    if (level >= 2) {
      debugLog(`[renderer console] level=${level} ${sourceId}:${line} ${message}`);
    }
  });

  await mainWindow.loadFile(path.join(__dirname, "boot.html"));
  debugLog("boot.html 載入完成（did-finish-load）");

  // ------------------------------------------------------------
  // 🩹 離線容錯：Google 登入 + 老闆密碼設定檢查都需要連網，原本兩步
  // 都是「失敗就整個 app.quit()」，沒有任何離線退路——只要店裡「連續
  // 斷網 N 天」剛好遇到一次重開機，即使本機其實已經裝好、能離線正常
  // 運作的版本，軟體也會直接開不了機。
  //
  // 判斷「就算這兩步都失敗/逾時，本機有沒有辦法照樣把程式開起來」的
  // 依據，完全不連網、只看本機檔案：只要 marker 檔（記著目前版本號）
  // 跟該版本實際解壓縮出來的資料夾都在，decideBootPlan() 等一下就會
  // 判斷成 kind:"normal"，不需要 shopFirebaseIdToken 也能直接載入該
  // 版本——這正是下面 hasCachedVersion 為 true 時可以放心跳過/放行
  // 這兩步的原因。只有「本機完全沒有任何版本可以用」（第一次安裝，或
  // 使用者自己清空重灌）才是真的沒有退路，這種情況本來就非得連網下載
  // 不可，開不了機也是預期中的事，只是要給清楚、跟「純粹沒網路」不同
  // 的錯誤訊息，方便店家自己判斷該做什麼。
  // ------------------------------------------------------------
  const hasCachedVersion = !!(engine.readMarker() && engine.getCurrentVersionDir());
  debugLog(`本機是否已有可離線開機的版本：hasCachedVersion=${hasCachedVersion}`);

  const online = await hasNetworkConnectivity();
  debugLog(`開機網路可用性快速檢查：online=${online}`);

  if (!online && !hasCachedVersion) {
    debugLog("目前離線，且本機沒有任何已安裝版本，無法離線開機，顯示明確錯誤後結束");
    dialog.showErrorBox(
      "無法啟動",
      "目前沒有網路連線，且本機尚未安裝過任何版本。初次安裝或重新安裝都需要連線到伺服器下載，請確認網路連線後再開啟。"
    );
    app.quit();
    return;
  }

  if (online) {
    try {
      debugLog("開始 ensureGoogleSignedIn");
      await withTimeout(ensureGoogleSignedIn(mainWindow), GOOGLE_SIGNIN_TIMEOUT_MS, "Google 登入逾時");
      debugLog("ensureGoogleSignedIn 完成");
    } catch (err) {
      debugLog(`ensureGoogleSignedIn 失敗：${err.message}`);
      if (await shouldFallbackToOfflineBoot(hasCachedVersion)) {
        // 重新確認過，此時此刻真的沒有網路，而且本機有可以離線開機的
        // 版本：不該讓整個程式打不開——記錄下來、跳過這一步，
        // shopFirebaseIdToken 維持 null，繼續走下面的離線開機路徑。
        debugLog("重新檢查後確認目前確實離線，且本機已有可離線開機的版本，改用離線模式繼續開機");
      } else {
        // 不是網路問題造成的失敗（或本機根本沒有可以退回的版本），
        // 維持原本行為：明確告知失敗原因並結束，不要悄悄跳過身分驗證。
        dialog.showErrorBox("無法啟動", `Google 登入失敗：${err.message}`);
        app.quit();
        return;
      }
    }
    if (!mainWindow) return; // 使用者在登入畫面關掉視窗

    if (shopFirebaseIdToken) {
      try {
        debugLog("開始 ensureBossPasswordConfigured");
        await withTimeout(
          ensureBossPasswordConfigured(mainWindow),
          BOSS_PASSWORD_CHECK_TIMEOUT_MS,
          "老闆密碼設定檢查逾時"
        );
        debugLog("ensureBossPasswordConfigured 完成");
      } catch (err) {
        debugLog(`ensureBossPasswordConfigured 失敗：${err.message}`);
        if (await shouldFallbackToOfflineBoot(hasCachedVersion)) {
          debugLog("重新檢查後確認目前確實離線，且本機已有可離線開機的版本，改用離線模式繼續開機");
        } else {
          dialog.showErrorBox("無法啟動", `老闆密碼初始設定失敗：${err.message}`);
          app.quit();
          return;
        }
      }
      if (!mainWindow) return; // 使用者在設定密碼畫面關掉視窗
    }
  } else {
    // hasNetworkConnectivity() 判斷目前沒有網路：既然本機已經有可以
    // 離線開機的版本（否則上面已經 quit），就完全不要跳出 Google 登入
    // 畫面——那個畫面在真的沒網路時本來就打不開／永遠等不到結果，
    // 讓使用者對著它乾等沒有意義，直接跳過，把 boot.html 的登入提示
    // 一起關掉，往下走離線開機。
    debugLog("目前離線，且本機已有可離線開機的版本，略過 Google 登入與老闆密碼檢查，直接以離線模式開機");
    if (mainWindow) {
      // 這個事件目前的 boot.html 不一定有處理（沒處理也無妨，
      // ipcRenderer 送到沒有監聽的 channel 不會報錯），保留給日後想在
      // 畫面上顯示「目前離線，以離線模式開啟」提示時使用。
      mainWindow.webContents.send("boot:offline-startup");
    }
  }

  // ------------------------------------------------------------
  // 🔑 統一金鑰來源（原本這裡沒有這段）：
  //
  // 雲端 licenseKey 原本是寫死在 config.js 裡的定值，每家分店要出貨
  // 都得各別打包一支專屬 exe。現在改成直接從 offline-license 資料夾
  // 裡簽章過的 .app 檔案讀（license.sig 本來就是每家店唯一、不可
  // 偽造的簽章值），不再吃 config.js 的定值。
  //
  // 好處：以後只要打包「一支通用 exe」發給所有分店，開新店／幫舊
  // 分店換機，只要換 .app 檔案，不用重新打包、重新出貨 exe。
  //
  // 這一步一定要放在 decideBootPlan() 之前——decideBootPlan() 裡
  // 會呼叫 engine.fetchLicenseRecord()，那個方法內部讀的是
  // engine.config.licenseKey；因為 engine 建構時存的是 config 這個
  // 物件的參照（不是複製一份），這裡直接改 config.licenseKey，
  // engine 那邊會同步看到新值，不用另外重建 engine。
  //
  // resolveLicense() 找不到／驗證失敗＝這台電腦目前沒有合法金鑰，
  // 直接視為無法開機（跟原本「沒有 licenseKey 就不能用」的精神一致，
  // 只是金鑰來源從「打包時寫死」改成「執行期間讀資料夾」）。
  // ------------------------------------------------------------
  debugLog("開始 resolveLicense（統一金鑰來源）");
  let offlineLicenseForKey;
  try {
    offlineLicenseForKey = resolveLicense();
  } catch (err) {
    debugLog(`resolveLicense 失敗：${err.message}`);
    dialog.showErrorBox(
      "無法啟動",
      `金鑰檔案無效（${err.message}），請確認 offline-license 資料夾裡的 .app 檔案是否正確。`
    );
    app.quit();
    return;
  }
  if (!offlineLicenseForKey) {
    debugLog("resolveLicense 找不到金鑰檔案");
    shell.openPath(offlineLicenseFolder());
    dialog.showErrorBox(
      "無法啟動",
      "找不到金鑰檔案，已幫你打開 offline-license 資料夾，請把授權金鑰（.app）放進去。"
    );
    app.quit();
    return;
  }
  config.licenseKey = offlineLicenseForKey.sig;
  debugLog(`licenseKey 已從 .app 檔案設定完成（店家：${offlineLicenseForKey.shop || "未填"}）`);

  debugLog("開始 decideBootPlan");
  const plan = await decideBootPlan();
  debugLog(`decideBootPlan 結果：${JSON.stringify(plan)}`);

  if (plan.kind === "error") {
    debugLog(`plan.kind === "error"：${plan.error}`);
    dialog.showErrorBox("無法啟動", plan.error);
    app.quit();
    return;
  }

  if (plan.kind === "normal") {
    debugLog(`plan.kind === "normal"，version=${plan.version}，開始 loadAppVersionIntoWindow`);
    mainWindow.close();
    mainWindow = null;
    await loadAppVersionIntoWindow(plan.version);
    debugLog("loadAppVersionIntoWindow 完成（normal）");
    reconcileVersionWithCloud();
    return;
  }

  if (plan.kind === "fresh-install") {
    debugLog("plan.kind === \"fresh-install\"，開始 fetchLatestVersion");
    const latest = await engine.fetchLatestVersion();
    debugLog(`fetchLatestVersion 完成：${latest}，開始 performFreshInstallOrUpdate`);
    await performFreshInstallOrUpdate(latest, {
      onProgress: (percent) => mainWindow && mainWindow.webContents.send("boot:progress", { percent }),
    });
    debugLog("performFreshInstallOrUpdate 完成，開始 loadAppVersionIntoWindow");
    mainWindow.close();
    mainWindow = null;
    await loadAppVersionIntoWindow(latest);
    debugLog("loadAppVersionIntoWindow 完成（fresh-install）");
    return;
  }

  if (plan.kind === "reinstall") {
    // 顯示「先前系統 / 最新系統」選擇畫面，交給 boot.html 處理，
    // boot.html 會呼叫 bootAPI.reinstallChoose(password, choice)
    const latest = await engine.fetchLatestVersion();
    mainWindow.webContents.send("boot:need-reinstall-choice", {
      previousVersion: plan.previousVersion,
      latestVersion: latest,
    });

    ipcMain.handleOnce("boot:reinstall-choose", async (event, { password, choice }) => {
      const auth = await verifyBossPassword(config.shopFirebaseConfig, password, shopFirebaseIdToken);
      if (!auth.ok) return { ok: false, error: "password_" + auth.reason };

      const version = choice === "latest" ? latest : plan.previousVersion;
      try {
        await performFreshInstallOrUpdate(version, {
          onProgress: (percent) => mainWindow && mainWindow.webContents.send("boot:progress", { percent }),
        });
        mainWindow.close();
        mainWindow = null;
        await loadAppVersionIntoWindow(version);
        return { ok: true };
      } catch (err) {
        return { ok: false, error: err.message };
      }
    });
  }
}

app.whenReady().then(() => {
  boot().catch((err) => {
    console.error("開機流程發生未預期的錯誤：", err);
    dialog.showErrorBox("無法啟動", `開機流程發生未預期的錯誤：${err.message}`);
  });
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      boot().catch((err) => {
        console.error("開機流程發生未預期的錯誤：", err);
        dialog.showErrorBox("無法啟動", `開機流程發生未預期的錯誤：${err.message}`);
      });
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
